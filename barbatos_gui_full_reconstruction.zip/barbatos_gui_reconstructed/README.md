# Barbatos GUI — полный статический вынос

Это максимально полный **GUI-only** вынос интерфейса из `barbatos.sh`, найденного на Google Drive. Архив сочетает два результата:

1. `src/` — читаемая и компилируемая реконструкция на Dear ImGui;
2. `reverse/decompiler/` — address-faithful C-like pseudocode 53 функций GUI, custom widgets, загрузчиков ресурсов и file picker, полученный Ghidra.

Оригинальный C++ нельзя восстановить побайтно: payload — оптимизированный stripped ARM64 ELF без исходных имён, типов и debug info. Поэтому pseudocode сохраняет адресную связь с бинарником, а `src/` переводит найденную логику в безопасный публичный API Dear ImGui.

## Что восстановлено

- пять страниц и точный порядок навигации: Home, Draw, Aim, Items, Settings;
- главный renderer, boot/frame helpers и update/download dialog со всеми найденными состояниями;
- группы Aim, включая `Main Aim`, четыре условные панели, segmented choices, weapon-ID actions и числовые параметры;
- группы Draw: player, non-player, other classes, health/radar/vehicle panels и long-press color-adjust equivalents;
- Items, developer tutorial, custom item row, per-class size/distance/color editor;
- Settings: Main, theme, Dynamic Island, Photo, Text/TTF, Dynamic tasks, GameData, pointer table, cloud/local file-selection branches;
- эквиваленты private widgets: toggle rows/groups, two-state row, action/timed-action row, segmented selector, value editors, custom item row, 6-column palette;
- точная палитра из **42 цветов**: имена — из relocation table `0x28C010`, RGBA — из initializer `0x14F4B4`;
- 40 PNG и 5 TTF, извлечённые из ELF без перекодирования;
- прямые и relocation-backed UTF-8/Chinese GUI strings;
- bilingual labels и условные ветки, обнаруженные декомпилятором.

GUI-код намеренно **не содержит** чтения памяти процессов, Android hooks, SurfaceComposer, сетевой авторизации, загрузки обновлений, игровых действий, Aim или ESP реализации. Все потенциальные действия представлены флагами состояния, которые может обработать хост-приложение.

## Исходный файл и хеши

```text
barbatos.sh     SHA-256 27adfdd05d6dc9704fde0007f44d232fa8f9248f525933a1dccabe1a8ac9627d
unpacked ELF    SHA-256 f48e21da34939699a183dbacf1ad046c1ed8f2c92fdaaf8c938b69f326bb0c86
```

`barbatos.sh` — `gzexe`-подобная оболочка. Payload начинается со строки 50 и был распакован статически, без выполнения:

```sh
tail -n +50 barbatos.sh | gzip -cd > barbatos.payload
```

Внутри находится Android AArch64 PIE, Dear ImGui 1.88 WIP, EGL/OpenGL ES; бинарник собран NDK r25c и stripped.

## Ключевые адреса

| ELF VA | Восстановленное назначение |
|---:|---|
| `0x151CCC` | `Gui_RenderMain`: окно, sidebar, page dispatch, update dialog |
| `0x1789AC` | `Gui_LoadEmbeddedAssets`: загрузка встроенных ресурсов |
| `0x18A0EC–0x18D71C` | custom widget/overlay region |
| `0x18BDD4` | 42-color preset palette |
| `0x1E24EC` | Aim |
| `0x1E4090` | Draw/ESP |
| `0x1E5FE8` | Home |
| `0x1E6130`, `0x1E67C4` | custom item row/core |
| `0x1E69F8` | Items |
| `0x1E8090` | Settings |
| `0x1EB214` | pointer-table panel |
| `0x1EB820`, `0x1EB9CC` | path selection/directory listing |

Полная карта — `reverse/FUNCTION_MAP.md`, индекс 53 pseudocode-файлов — `reverse/decompiler/index.tsv`.

## Содержимое

```text
src/
  barbatos_gui_reconstructed.hpp  state model and public API
  barbatos_gui_reconstructed.cpp  complete GUI-only Dear ImGui reconstruction
assets/
  png_*.png                       40 exact embedded PNGs
  font_*.ttf                      5 exact embedded TTFs
  manifest.csv                    offsets, dimensions, hashes
  contact_sheet.jpg               visual index
reverse/
  decompiler/                     53 address-named Ghidra C-like files
  FUNCTION_MAP.md                 address/function map
  GUI_CONTROL_INVENTORY.md        pages, controls and branches
  gui_utf8_catalog.tsv            direct string references in selected functions
  gui_relocated_utf8.tsv          relocation-backed labels/arrays
  relocated_utf8_strings.tsv      full printable RELATIVE-pointer catalog
  technical_report.md             methodology and limits
  *_disassembly.txt               selected AArch64 disassembly
```

## Подключение

Нужен Dear ImGui 1.88+ и backend приложения. Добавьте:

```text
src/barbatos_gui_reconstructed.cpp
src/barbatos_gui_reconstructed.hpp
imgui.cpp / imgui_draw.cpp / imgui_tables.cpp / imgui_widgets.cpp
misc/cpp/imgui_stdlib.cpp
```

После загрузки PNG заполните `TextureRegistry::images` в порядке `assets/manifest.csv`:

```cpp
barbatos_gui::GuiState state;
barbatos_gui::TextureRegistry textures;
// textures.images[...] = backend texture IDs
barbatos_gui::RenderBarbatosGui(state, textures);
```

Для GUI-only file picker хост может заполнить `font_picker.files`, `picture_picker.files` и `directories`. Запросы на exit, update, запись ID и выбор изображения выставляются как флаги в `GuiState`; библиотека сама побочных действий не выполняет.

CMake:

```sh
cmake -S . -B build -DIMGUI_DIR=/path/to/imgui
cmake --build build
```

## Проверка

Реконструкция проверена с Dear ImGui **v1.88**:

- `g++ -std=c++17 -Wall -Wextra -Wpedantic -fsyntax-only` — успешно;
- CMake static-library build — см. `reverse/build_verification.txt`.

## Граница точности

**Напрямую подтверждено бинарником:** адреса функций, page dispatch, строки, relocation arrays, наборы control labels, 42 RGBA, asset bytes, условные switch branches и вызовы custom widgets.

**Реконструировано семантически:** C++ типы/имена полей, layout на публичном Dear ImGui API, связка state flags с controls, упрощённые easing/overlay transitions. Оригинальные private widgets доступны отдельно как decompiler pseudocode, чтобы приблизительное решение не подменяло адресно точный результат.
