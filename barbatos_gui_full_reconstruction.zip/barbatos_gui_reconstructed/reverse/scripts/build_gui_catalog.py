#!/usr/bin/env python3
from pathlib import Path
root=Path('/home/user/barbatos_analysis')
funcs=set()
for line in (root/'ghidra_gui_named/index.tsv').read_text().splitlines():
    if line.strip(): funcs.add(line.split('\t')[0].lower())
rows=[]
for line in (root/'xrefs_utf8.tsv').read_text().splitlines():
    p=line.split('\t',3)
    if len(p)==4 and p[0].lower() in funcs: rows.append(p)
rows.sort(key=lambda p:(int(p[0],16),int(p[1],16),int(p[2],16)))
out=['function_va\txref_va\tstring_va\tutf8']+['\t'.join(p) for p in rows]
(root/'gui_utf8_catalog.tsv').write_text('\n'.join(out)+'\n')
print('wrote',len(rows),'direct GUI UTF-8 xrefs')
