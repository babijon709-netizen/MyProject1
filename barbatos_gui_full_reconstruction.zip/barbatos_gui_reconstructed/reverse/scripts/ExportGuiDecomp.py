# Ghidra Jython post-script: decompile selected GUI functions.
# @category Arena
from ghidra.app.decompiler import DecompInterface, DecompileOptions
from java.io import File

args = getScriptArgs()
outdir = args[0] if len(args) else "/home/user/barbatos_analysis/ghidra_decomp"
File(outdir).mkdirs()

targets = [
    0x150d00, 0x15109c, 0x151374, 0x151598, 0x151938, 0x151ccc,
    0x154648, 0x154790, 0x154964,
    0x177570, 0x177914, 0x178354, 0x17882c, 0x1789ac, 0x178ffc,
    0x179138, 0x1793b8,
    0x18a0ec, 0x18a268, 0x18a604, 0x18a9b4, 0x18ae40,
    0x18b144, 0x18b400, 0x18b60c, 0x18bdd4,
    0x18c248, 0x18c688, 0x18cac8, 0x18cea0,
    0x18d268, 0x18d3a0, 0x18d410, 0x18d4c4, 0x18d71c,
    0x1e24ec, 0x1e3b14, 0x1e3fb8, 0x1e4090, 0x1e5da4, 0x1e5fe8,
    0x1e6130, 0x1e67c4, 0x1e69f8, 0x1e7b28, 0x1e8090, 0x1eacb8,
    0x1eb170, 0x1eb214, 0x1eb57c, 0x1eb820, 0x1eb9cc, 0x1ebed0,
]

opts = DecompileOptions()
opts.setMaxPayloadMBytes(500)
iface = DecompInterface()
iface.setOptions(opts)
iface.openProgram(currentProgram)
fm = currentProgram.getFunctionManager()

index = open(outdir + "/index.tsv", "w")
image_base = currentProgram.getImageBase().getOffset()
for va in targets:
    addr = toAddr(image_base + va)
    fn = fm.getFunctionAt(addr)
    if fn is None:
        fn = fm.getFunctionContaining(addr)
    if fn is None:
        index.write("%08x\tNO_FUNCTION\n" % va)
        continue
    print("[GUI-DECOMP] %08x %s" % (va, fn.getName()))
    result = iface.decompileFunction(fn, 300, monitor)
    path = outdir + "/%08x_%s.c" % (va, fn.getName().replace("/", "_"))
    if result.decompileCompleted():
        text = result.getDecompiledFunction().getC()
        f = open(path, "w")
        f.write("/* Entry: 0x%08x; Ghidra function: %s */\n\n" % (va, fn.getName()))
        f.write(text)
        f.close()
        index.write("%08x\t%s\tOK\t%s\n" % (va, fn.getName(), path))
    else:
        err = result.getErrorMessage()
        f = open(path, "w")
        f.write("/* FAILED: %s */\n" % err)
        f.close()
        index.write("%08x\t%s\tFAILED\t%s\n" % (va, fn.getName(), err))
index.close()
iface.dispose()
