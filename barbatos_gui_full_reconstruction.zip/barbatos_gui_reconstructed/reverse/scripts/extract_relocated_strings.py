#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0,'/home/user/.pytools')
from elftools.elf.elffile import ELFFile
root=Path('/home/user/barbatos_analysis'); p=root/'barbatos.payload'
f=p.open('rb'); elf=ELFFile(f)
loads=[s for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
def bytes_at(va,n=512):
    for s in loads:
        if s['p_vaddr']<=va<s['p_vaddr']+s['p_filesz']:
            f.seek(s['p_offset']+va-s['p_vaddr']); return f.read(n)
    return b''
def cstr(va):
    b=bytes_at(va)
    b=b.split(b'\0',1)[0]
    if not b or len(b)>500:return None
    try:s=b.decode('utf-8')
    except UnicodeDecodeError:return None
    if not s or any(ord(c)<32 and c not in '\t\r\n' for c in s):return None
    return s
def esc(s):
    return s.replace('\\','\\\\').replace('\t','\\t').replace('\r','\\r').replace('\n','\\n')
rows=[]
for sec in elf.iter_sections():
    if sec.name!='.rela.dyn':continue
    for r in sec.iter_relocations():
        if r['r_info_type']!=0x403:continue
        off=int(r['r_offset']); target=int(r['r_addend']); s=cstr(target)
        if s is not None: rows.append((off,target,s))
rows.sort()
out=['table_va\tstring_va\tutf8']+[f'{a:08x}\t{b:08x}\t{esc(s)}' for a,b,s in rows]
(root/'relocated_utf8_strings.tsv').write_text('\n'.join(out)+'\n')
# Focused known GUI relocation range (nav/page labels through settings/dynamic labels).
gui=[r for r in rows if 0x28bf00<=r[0]<0x28c800]
out=['table_va\tstring_va\tutf8']+[f'{a:08x}\t{b:08x}\t{esc(s)}' for a,b,s in gui]
(root/'gui_relocated_utf8.tsv').write_text('\n'.join(out)+'\n')
print('wrote',len(rows),'all relocated strings and',len(gui),'GUI-range rows')
