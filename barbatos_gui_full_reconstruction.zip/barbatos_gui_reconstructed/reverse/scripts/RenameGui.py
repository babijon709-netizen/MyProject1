# @category Arena
from ghidra.program.model.symbol import SourceType
base=currentProgram.getImageBase().getOffset()
names={
0x150d00:'Gui_FormatBuffer',0x15109c:'Gui_SidebarTabs',0x151374:'Gui_DrawWindowBackground',0x151598:'Gui_RenderBootLayer',0x151938:'Gui_InitializeFrameState',0x151ccc:'Gui_RenderMain',
0x154648:'Gui_UpdateAction',0x154790:'Gui_UpdateWorker',0x154964:'Gui_UpdateCleanup',
0x177570:'Gui_CreateTextureFromMemory',0x177914:'Gui_DecodeImage',0x178354:'Gui_LoadExternalAsset',0x17882c:'Gui_SetExternalAsset',0x1789ac:'Gui_LoadEmbeddedAssets',0x178ffc:'Gui_LoadTextureToSlot',
0x179138:'Gui_DrawTexture',0x1793b8:'Gui_RenderImageLayer',
0x18a0ec:'Gui_CloseButton',0x18a268:'Gui_TimedActionButton',0x18a604:'Gui_ActionRow',0x18a9b4:'Gui_ToggleRowCore',0x18ae40:'Gui_ToggleRows',0x18b144:'Gui_ToggleGroup',0x18b400:'Gui_TwoStateRow',0x18b60c:'Gui_ColorPicker',0x18bdd4:'Gui_PresetColorPalette',0x18c248:'Gui_ValueEditor',0x18c688:'Gui_ValueEditorList',0x18cac8:'Gui_TaskToggleRows',0x18cea0:'Gui_ChoiceGroup',0x18d268:'Gui_HomeNotices',0x18d3a0:'Gui_TextBox',0x18d410:'Gui_OverlayStateBegin',0x18d4c4:'Gui_OverlayAnimation',0x18d71c:'Gui_OverlayStateEnd',
0x1e24ec:'Gui_RenderAimPage',0x1e3b14:'Gui_ChoiceCombo',0x1e3fb8:'Gui_FormatText',0x1e4090:'Gui_RenderDrawPage',0x1e5da4:'Gui_UpdateDragScroll',0x1e5fe8:'Gui_RenderHomePage',0x1e6130:'Gui_CustomItemRowCore',0x1e67c4:'Gui_CustomItemRow',0x1e69f8:'Gui_RenderItemsPage',0x1e7b28:'Gui_ItemsWorker',0x1e8090:'Gui_RenderSettingsPage',0x1eacb8:'Gui_LanguageChoice',0x1eb170:'Gui_FormatDiagnostic',0x1eb214:'Gui_PointerTable',0x1eb57c:'Gui_IsPictureExtension',0x1eb820:'Gui_PathSelection',0x1eb9cc:'Gui_ListDirectory',0x1ebed0:'Gui_ReportFileError',
0x191800:'ImGui_ColorConvertFloat4ToU32',0x1922ac:'ImGui_PushStyleColor',0x19232c:'ImGui_PopStyleColor',0x196b08:'ImGui_GetIO',0x196c44:'ImGui_GetBackgroundDrawList',0x19c3b8:'ImGui_Begin',0x19c38c:'ImGui_SetNextWindowSize',
0x1a2b0c:'ImGui_BeginChild',0x1a2c34:'ImGui_EndChild',0x1a445c:'ImGui_CalcTextSize',0x1a4bd0:'ImGui_GetWindowSize',0x1a4be4:'ImGui_GetWindowPos',0x1a4da8:'ImGui_GetWindowDrawList',0x1a4bf8:'ImGui_SetWindowSize',0x1a4d50:'ImGui_SetNextWindowPos',0x1a5bd0:'ImGui_GetCursorScreenPos',0x1a5be4:'ImGui_SetCursorScreenPos',0x1a5c54:'ImGui_SetCursorPos',0x1a5c98:'ImGui_SetCursorPosX',0x1a5cd8:'ImGui_SetCursorPosY',0x1a5d18:'ImGui_SetNextItemWidth',0x1a6160:'ImGui_GetScrollY',
0x1ae254:'ImDrawList_AddLine',0x1ae3e0:'ImDrawList_AddRect',0x1ae4b4:'ImDrawList_AddRectFilled',0x1af030:'ImDrawList_AddCircle',0x1af0ec:'ImDrawList_AddText',0x1afc2c:'ImDrawList_AddRectFilledMultiColor',0x1bea10:'ImGui_Button',0x1bfd88:'ImGui_Dummy',0x1c7f64:'ImGui_SliderScalar'
}
fm=currentProgram.getFunctionManager()
for va,name in names.items():
 fn=fm.getFunctionAt(toAddr(base+va))
 if fn:
  try:fn.setName(name,SourceType.USER_DEFINED)
  except Exception as e:print('rename failed',hex(va),name,e)
print('renamed',len(names))
