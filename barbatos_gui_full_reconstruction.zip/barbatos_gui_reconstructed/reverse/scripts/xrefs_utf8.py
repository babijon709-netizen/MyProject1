#!/usr/bin/env python3
import sys,re,subprocess
from collections import defaultdict
sys.path.insert(0,'/home/user/.pytools')
from capstone import *
from capstone.arm64 import *
from elftools.elf.elffile import ELFFile
P='barbatos.payload'
with open(P,'rb') as f:
 e=ELFFile(f);t=e.get_section_by_name('.text');ro=e.get_section_by_name('.rodata')
 base=t['sh_addr'];code=t.data();rbase=ro['sh_addr'];rdata=ro.data();rend=rbase+len(rdata)
fr=subprocess.check_output(['readelf','--debug-dump=frames',P],text=True,errors='replace')
starts=[base]
for line in fr.splitlines():
 m=re.search(r'\(offset: 0x([0-9a-fA-F]+)\) ->',line)
 if m:
  a=int(m.group(1),16)
  if base<=a<base+len(code):starts.append(a)
starts=sorted(set(starts))

def dec(a):
 if not rbase<=a<rend:return None
 i=a-rbase
 j=rdata.find(b'\0',i,min(len(rdata),i+512))
 if j<0 or not (2<=j-i<=300):return None
 b=rdata[i:j]
 try:s=b.decode('utf-8')
 except:return None
 if any((ord(c)<32 or ord(c)==127) and c not in '\t\r\n' for c in s):return None
 # Require primarily human text.
 if not any(c.isalpha() for c in s):
  if s not in ('##X','##Y','##Z','##W'):return None
 return s
md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.detail=True
regs={};age={};si=0;fs=starts[0];out=[]
for x in md.disasm(code,base):
 while si+1<len(starts) and x.address>=starts[si+1]:si+=1
 nfs=starts[si]
 if nfs!=fs:fs=nfs;regs={};age={}
 for r in list(age):
  age[r]+=1
  if age[r]>12:age.pop(r);regs.pop(r,None)
 o=x.operands;m=x.mnemonic
 if m in ('adr','adrp') and len(o)>=2 and o[0].type==ARM64_OP_REG and o[1].type==ARM64_OP_IMM:
  rd=x.reg_name(o[0].reg);regs[rd]=o[1].imm;age[rd]=0
  if m=='adr':
   s=dec(regs[rd]);
   if s is not None:out.append((fs,x.address,regs[rd],s))
 elif m=='add' and len(o)>=3 and o[0].type==ARM64_OP_REG and o[1].type==ARM64_OP_REG and o[2].type==ARM64_OP_IMM:
  rd=x.reg_name(o[0].reg);rn=x.reg_name(o[1].reg)
  if rn in regs:
   regs[rd]=regs[rn]+o[2].imm;age[rd]=0
   s=dec(regs[rd])
   if s is not None:out.append((fs,x.address,regs[rd],s))
  else:regs.pop(rd,None);age.pop(rd,None)
 elif o and o[0].type==ARM64_OP_REG and m not in ('cmp','cmn','tst','str','stp','cbz','cbnz','tbz','tbnz'):
  rd=x.reg_name(o[0].reg);regs.pop(rd,None);age.pop(rd,None)
with open('xrefs_utf8.tsv','w',encoding='utf-8') as f:
 for a,b,c,s in out:
  s=s.replace('\\','\\\\').replace('\t','\\t').replace('\r','\\r').replace('\n','\\n')
  f.write('%08x\t%08x\t%08x\t%s\n'%(a,b,c,s))
print('wrote',len(out))
