# GUI control and conditional-branch inventory

This inventory combines direct UTF-8 references, relocation-backed arrays and page-function pseudocode. English/Chinese labels are shown where both are present in the binary.

## Main renderer — `0x151CCC`

- Sidebar: Home, Draw, Aim, Items, Settings.
- Header/status strings: `Dome`, `DitPro`, driver and SDK 15.
- Update modal:
  - Find the new version / 发现新版本;
  - mandatory and non-mandatory branches;
  - current/new version, size, progress;
  - fetching size, download/update, confirm, use/request update, cancel;
  - completion and starting-new-instance states.

## Home — `0x1E5FE8`

Six exact notices from relocation array `0x28C518`:

1. 本系列产品无任何收费以及内部等
2. 切勿被骗，开发者也不会主动联系你
3. 本系列作品仅供学习研究
4. 使用者的任何行为与应用作者无关
5. 请在24小时内删除本应用 [下载代表同意本协议]
6. 若有侵权违法行为,请联系我删除内容

## Aim — `0x1E24EC`

### Main area

- Now To Only Draw / 当前为单透模式;
- Main Aim / 主要的瞄准:
  - Aiming / 触摸瞄准;
  - Aim Pos / 触摸位置;
- My Aim Player Place / 我的瞄准部位:
  - Head/头颅, Chest/胸腔, Pelvis/盆骨;
- Other Aim Func / 特殊的瞄准功能 selector.

### Conditional panel `2`

- Only Draw / 单透模式;
- Circle Aim / 圈内瞄准;
- Finger Interference Aim / 辅助横拉与压枪;
- Hit aim / 掉血瞄准;
- Not aim lie down / 倒地不瞄;
- Not Ai / 人机不瞄.

### Numeric values

- per-weapon Vertical Recoil Reduction;
- Follow Gun Speed;
- Aim Steadiness;
- All Vertical Recoil Reduction;
- Horizontal Range;
- Vertical Range;
- Extra parameters;
- Hip-Fire Aim Max Distance;
- All Aim Max Distance;
- Parameters that limit the distance.

### Conditional panel `11` — stop-firing scope flash

- Not Shoot Auto Aiming / 停火闪镜;
- Pos[Move to Game Aiming Button] / 位置[放开镜键];
- Shoot Bullet Count > 5 Run / 射出子弹大于五颗才触发;
- Type / 闪镜类型: Fast, Average speed, Slow, with detailed Chinese labels.

### Conditional panel `22` — continuous click

- Continuous Click Aiming / 连点瞄准;
- Pos[Move to Game Shoot Button] / 位置[放开火键];
- Aim Range Have Player To Run[Not Done] / 瞄准范围内存在目标才触发[未完成];
- Second Once;
- Speed [Second];
- Write To Weapon ID.

### Conditional panel `33` — sniper

- Sniper rifle / 狙击自瞄;
- Pos(Move the shoot button) / 触发位置(松手放开火，按下放开镜);
- English binary label `nullptr`; Chinese label says auto-fire after aiming, release-only, bug;
- Write To Weapon ID.

## Draw — `0x1E4090`

### Player Class Draw [Long Down Adjust]

Rect Box, Line, Skeleton, Name And Distance, Health, Player Weapon.

### Not Player Class Draw [Long Down Adjust]

盒子, 载具, 空投, 地铁宝箱.

### Else Class Draw [Long Down Adjust]

Radar/雷达, aimed warning/被瞄提示, back-enemy warning/背敌预警, Not Draw Ai/跳过人机, Off Color Dynamic/关闭击倒跑马灯.

### Adjustment overlays

- Size / thickness;
- Skeleton Draw Distance Max;
- Adjust;
- Draw Color;
- Draw Vehicle State and `[bug]` variant;
- Angle / diffusion ratio;
- Radar Pos and Pos | Size;
- Player Aim You Tips Size;
- Health Transparency;
- Health Type: Circular, Rect one/two, formatted, wide;
- Health Color;
- Same team Same color;
- Follow blood volume;
- More colors — exact 42-entry palette.

## Items — `0x1E69F8`

- Open Class Name;
- Dev Mode;
- My Items-Mate;
- five-line custom-item tutorial;
- All Items Size;
- All Items Distance[100 to Not bound];
- Draw Color and More colors;
- custom item rows with enable state, display/class name, color and per-entry editor.

## Settings — `0x1E8090`

### Main

- Leave Procs Run [KSU Self-contained];
- Not Screen Recording;
- Simplified Chinese / English;
- Kernel Exit;
- Exit & Save Configuration;
- Theme color branch and palette.

### Island / More

- Main | Island | Photo | Text | Dynamic;
- Island Size;
- Change Photo;
- Change Text [Use TTF Format;
- Dynamic;
- Island Dynamic Test;
- MacOS "神奇效果" / Magic effect;
- IpadOS "聚散效果" / Dispersion effect.

### Photo branch

- current/startup image path instruction;
- Restore the original picture;
- Use File Dir Switch;
- `.png` / `.jpg` directory filter;
- Back to parent;
- PhotoLook preview;
- 设置为左上角图片.

### Text/TTF branch

- Restore the original Text;
- From the cloud;
- 下列为云端字体;
- Use File Dir Switch;
- `.ttf` / `.TTF` directory filter;
- Back to parent;
- progress / 正在设置字体.

### Dynamic branch

- six `增加一个任务` rows, one through six;
- dynamic/island long text, including 岛二[超长文本啊啊啊啊啊].

### GameData branch (`0x309`)

- pid and libUE4;
- Matrix and Self;
- Arrayaddr and Count;
- automatic traversal current index;
- 官方基址链[基址链条索引的0];
- 自身结构体;
- 手动选择;
- 打开指针表;
- SelfAddr and pointer list.

## File picker helpers

- `Gui_IsPictureExtension` classifies picture paths;
- `Gui_PathSelection` displays launch-directory assets;
- `Gui_ListDirectory` enumerates filtered font/picture paths;
- separate `/storage/emulated/0` state exists for fonts and pictures;
- parent traversal and directory-vs-file decisions are explicit branches.

## Private widgets represented in source

The reconstruction provides public Dear ImGui equivalents for toggle rows/groups, action/timed buttons, two-state row, segmented choices, value-editor lists, per-item controls, 42-color palette, overlays and file lists. For original cursor math/draw-list/easing behavior, use the address-matched files under `decompiler/`.
