/* Entry: 0x0018d410; Ghidra function: Gui_OverlayStateBegin */


void Gui_OverlayStateBegin(uint param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  if ((((param_1 & 1) == 0) &&
      ((DAT_0050e630 != '\0' && DAT_0050e637 != '\0') && DAT_0050e639 != '\0')) &&
     (DAT_0050e590 != DAT_0050e640._4_4_)) {
    fVar1 = (float)ImGui_GetScrollY();
    fVar2 = DAT_0050e640._4_4_ - DAT_0050e64c;
    fVar3 = (float)NEON_fmadd(fVar2,0x3f99999a,fVar2);
    fVar2 = (float)NEON_fmadd(fVar2,0x3ff33333,fVar2);
    if (DAT_0050dbb0 <= DAT_0050dbac) {
      fVar3 = fVar2;
    }
    FUN_002a6198(fVar1 - fVar3);
    DAT_0050e590 = DAT_0050e640._4_4_;
  }
  return;
}

