/* Entry: 0x0018a9b4; Ghidra function: Gui_ToggleRowCore */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte Gui_ToggleRowCore(float param_1,float param_2,undefined8 param_3,byte *param_4,
                      undefined4 *param_5)

{
  byte bVar1;
  long lVar2;
  char cVar3;
  char cVar4;
  byte bVar5;
  int iVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  ulong uVar9;
  undefined8 *puVar10;
  long lVar11;
  undefined8 **ppuVar12;
  undefined8 **ppuVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  undefined4 uVar18;
  undefined auVar19 [16];
  float fVar20;
  undefined8 *local_c0;
  undefined8 uStack184;
  float local_a8;
  float fStack164;
  undefined8 *local_a0;
  long local_98;
  
  lVar2 = cRead_8(tpidr_el0);
  local_98 = *(long *)(lVar2 + 0x28);
  fVar17 = param_2;
  fVar14 = (float)ImGui_GetCursorScreenPos();
  fVar15 = (float)ImGui_GetWindowPos();
  uVar8 = ImGui_GetWindowDrawList();
  ImGui_SetCursorPosX(0x41a00000);
  local_c0 = (undefined8 *)CONCAT44(param_2,fVar15 + -40.0);
  uVar9 = ImGui_Button(param_3,&local_c0,0);
  if ((((uVar9 & 1) != 0) && (param_4 != (byte *)0x0)) && (DAT_0050e634 == '\0')) {
    bVar5 = *param_4;
    *param_4 = bVar5 ^ 1;
    if (param_5 != (undefined4 *)0x0) {
      *(byte *)((long)param_5 + 0xd) = bVar5 ^ 1;
    }
    __strcpy_chk(DAT_00500b40 + 0x50,param_3,0x80);
    uVar7 = 0xb385e5;
    if (*param_4 != 0) {
      uVar7 = 0x80bce5;
    }
    *(undefined4 *)(DAT_00500b40 + 0xd0) = uVar7;
    DAT_0050e504 = 0;
    DAT_0050e508 = FUN_0034a23c();
    if (*(char *)(DAT_00500b40 + 4) == '\0') {
      puVar10 = (undefined8 *)FUN_0036b114(8);
                    /* try { // try from 0028aadc to 0028aadf has its CatchHandler @ 0028ae10 */
      FUN_0036e56c();
      local_c0 = puVar10;
                    /* try { // try from 0028aae4 to 0028aaeb has its CatchHandler @ 0028ae08 */
      local_a0 = (undefined8 *)FUN_0036b114(8);
      local_c0 = (undefined8 *)0x0;
      *local_a0 = puVar10;
                    /* try { // try from 0028aafc to 0028ab0f has its CatchHandler @ 0028ae24 */
      iVar6 = pthread_create((pthread_t *)&local_a8,(pthread_attr_t *)0x0,FUN_0028dc34,local_a0);
      if (iVar6 != 0) {
                    /* try { // try from 0028ade4 to 0028adef has its CatchHandler @ 0028ae24 */
                    /* WARNING: Subroutine does not return */
        FUN_0036e0f8(iVar6,"thread constructor failed");
      }
                    /* try { // try from 0028ab14 to 0028ab1b has its CatchHandler @ 0028adf4 */
      FUN_0036e2d4(&local_a8);
      FUN_0036e264(&local_a8);
    }
    *(undefined *)(DAT_00500b40 + 4) = 1;
  }
  bVar5 = FUN_002a26dc();
  cVar4 = DAT_0050e634;
  cVar3 = DAT_0050e632;
  fVar20 = param_2 + fVar17;
  if ((param_4 == (byte *)0x0) || (*param_4 == 0)) {
    fStack164 = fVar20 + -8.0;
    local_a8 = fVar14 + fVar15 + -45.0;
    local_a0 = (undefined8 *)CONCAT44(fVar17 + 8.0,((fVar14 + fVar15) - param_1) + -45.0);
    uStack184 = 0x3f8000003f43c3c5;
    local_c0 = (undefined8 *)0x3f43c3c53f43c3c5;
    uVar7 = ImGui_ColorConvertFloat4ToU32(&local_c0);
    ppuVar12 = &local_a0;
    ppuVar13 = (undefined8 **)&local_a8;
  }
  else {
    local_c0 = (undefined8 *)CONCAT44(fVar17 + 8.0,((fVar14 + fVar15) - param_1) + -45.0);
    local_a0 = (undefined8 *)CONCAT44(fVar20 + -8.0,fVar14 + fVar15 + -45.0);
    uVar7 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4e0);
    ppuVar12 = &local_c0;
    ppuVar13 = &local_a0;
  }
  ImDrawList_AddRectFilled(0x42480000,uVar8,ppuVar12,ppuVar13,uVar7,0);
  param_2 = param_2 * 0.5;
  bVar1 = *param_4;
  uVar7 = param_5[1];
  fVar16 = 0.0;
  if (*(char *)((long)param_5 + 0xd) != '\0') {
    fVar16 = 1.0;
  }
  lVar11 = ImGui_GetIO();
  if (*(char *)(param_5 + 3) == '\0') {
    *(undefined *)(param_5 + 3) = 1;
    uVar7 = *param_5;
  }
  else {
    fVar16 = (float)NEON_fmadd(*(float *)(lVar11 + 0x10) / (float)param_5[2],
                               fVar16 - (float)param_5[1],uVar7);
    uVar18 = NEON_fmin(fVar16,0x3f800000);
    uVar7 = 0;
    if (0.0 <= fVar16) {
      uVar7 = uVar18;
    }
  }
  param_5[1] = uVar7;
  uVar18 = NEON_fmadd(param_2,0xc0000000,param_1 + 8.0);
  fVar16 = -8.0;
  if (bVar1 != 0) {
    fVar16 = 0.0;
  }
  uVar7 = NEON_fmadd(uVar7,uVar18,param_2 + fVar14 + (fVar15 - param_1) + -45.0 + fVar16);
  auVar19 = NEON_fmov(0x3f800000,4);
  local_a0 = (undefined8 *)CONCAT44(param_2 + fVar17,uVar7);
  uStack184 = SUB168(auVar19 >> 0x40,0);
  local_c0 = SUB168(auVar19,0);
  uVar7 = ImGui_ColorConvertFloat4ToU32(uVar7,local_c0,&local_c0);
  fVar15 = SUB164(auVar19,0);
  ImDrawList_AddCircle(param_2 + -8.0 + -5.0,uVar8,&local_a0,uVar7,0);
  ImGui_CalcTextSize(_DAT_004d3e84,0,param_3);
  uVar7 = _DAT_004d3e84;
  uStack184 = 0x3f8000003df0f0f2;
  local_c0 = (undefined8 *)0x3df0f0f23df0f0f2;
  local_a0 = (undefined8 *)CONCAT44(param_2 + fVar17 + fVar15 * -0.5 + -1.0,fVar14 + 45.0);
  uVar18 = ImGui_ColorConvertFloat4ToU32(&local_c0);
  ImDrawList_AddText(uVar7,uVar8,0,&local_a0,uVar18,param_3,0,0);
  local_c0 = (undefined8 *)CONCAT44(fVar20,fVar14);
  ImGui_SetCursorScreenPos(&local_c0);
  if (*(long *)(lVar2 + 0x28) != local_98) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return bVar5 & cVar3 != '\0' & cVar4 == '\0';
}

