/* Entry: 0x001e3fb8; Ghidra function: Gui_FormatText */


void Gui_FormatText(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                   undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  long lVar1;
  long lVar2;
  undefined auStack160 [8];
  undefined8 local_98;
  undefined8 uStack144;
  undefined8 local_88;
  undefined8 uStack128;
  undefined8 local_78;
  undefined *local_70;
  undefined **ppuStack104;
  undefined *puStack96;
  undefined8 uStack88;
  
  ppuStack104 = &local_70;
  puStack96 = auStack160;
  lVar1 = cRead_8(tpidr_el0);
  lVar2 = *(long *)(lVar1 + 0x28);
  uStack88 = 0xffffff80ffffffd8;
  local_98 = param_4;
  uStack144 = param_5;
  local_88 = param_6;
  uStack128 = param_7;
  local_78 = param_8;
  local_70 = (undefined *)register0x00000008;
  __vsprintf_chk(param_1,0,param_2,param_3,&local_70);
  if (*(long *)(lVar1 + 0x28) == lVar2) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

