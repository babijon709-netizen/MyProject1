/* Entry: 0x00177570; Ghidra function: Gui_CreateTextureFromMemory */


void Gui_CreateTextureFromMemory
               (undefined8 param_1,ulong param_2,uint *param_3,uint *param_4,int *param_5)

{
  uint *puVar1;
  uint *puVar2;
  long lVar3;
  int *piVar4;
  void *__ptr;
  undefined8 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined4 local_58;
  int iStack84;
  uint uStack80;
  uint uStack76;
  long local_48;
  
  lVar3 = cRead_8(tpidr_el0);
  local_48 = *(long *)(lVar3 + 0x28);
  puVar1 = &uStack80;
  if (param_3 != (uint *)0x0 && param_4 != (uint *)0x0) {
    puVar1 = param_4;
  }
  puVar2 = &uStack76;
  piVar4 = &iStack84;
  if (param_3 != (uint *)0x0 && param_4 != (uint *)0x0) {
    puVar2 = param_3;
    piVar4 = param_5;
  }
  __ptr = (void *)FUN_00277700(param_1,param_2,puVar2,puVar1,piVar4);
  if (__ptr == (void *)0x0) {
    puVar5 = (undefined8 *)FUN_003892d8(&DAT_003f24c0);
    printf("Error: %s %d %d %d %d\n",*puVar5,param_2 & 0xffffffff,(ulong)*puVar2,(ulong)*puVar1,
           piVar4);
    local_58 = 0;
  }
  else {
    glPixelStorei(0xcf5,1);
    glGenTextures(1,&local_58);
    glEnable(0xde1);
    glBindTexture(0xde1,local_58);
    glTexParameteri(0xde1,0x2802,0x812f);
    glTexParameteri(0xde1,0x2803,0x812f);
    glTexParameteri(0xde1,0x2801,0x2601);
    glTexParameteri(0xde1,0x2800,0x2601);
    if (*piVar4 == 3) {
      uVar6 = 0x1907;
      uVar7 = 0x1907;
    }
    else {
      uVar6 = 0x1908;
      uVar7 = 0x1908;
    }
    glTexImage2D(0xde1,0,uVar6,*puVar2,*puVar1,0,uVar7,0x1401,__ptr);
    free(__ptr);
  }
  if (*(long *)(lVar3 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(local_58);
  }
  return;
}

