/* Entry: 0x001e67c4; Ghidra function: Gui_CustomItemRow */


void Gui_CustomItemRow(undefined4 param_1,float param_2,long param_3,undefined8 param_4,
                      undefined8 param_5,undefined8 param_6,undefined4 param_7,undefined8 param_8,
                      long param_9,undefined8 param_10)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float local_d8;
  float fStack212;
  undefined8 local_d0;
  undefined8 uStack200;
  float local_b8;
  float fStack180;
  float local_b0;
  float local_ac;
  long local_a8;
  
  lVar1 = cRead_8(tpidr_el0);
  local_a8 = *(long *)(lVar1 + 0x28);
  fVar6 = param_2;
  uVar3 = ImGui_GetWindowDrawList();
  fVar4 = (float)ImGui_GetCursorScreenPos();
  fVar7 = fVar6;
  local_b0 = fVar4;
  local_ac = fVar6;
  fVar5 = (float)ImGui_GetWindowPos();
  fStack180 = fVar6;
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_b8 = 0.0;
    if (param_9 != 0) {
      local_b8 = 55.0;
    }
    local_b8 = local_b8 + fVar4 + 50.0;
    uStack200 = 0x3f8000003df0f0f2;
    local_d0 = 0x3df0f0f23df0f0f2;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    ImDrawList_AddText(0x421c0000,uVar3,0,&local_b8,uVar2,param_3,0,0);
    if (param_9 == 0) {
      fVar4 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar4 + 70.0,fVar7 * 0.5 + fVar6 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_9);
      fVar4 = 10.0;
    }
    local_ac = fVar6 + fVar7 + fVar4;
    ImGui_SetCursorScreenPos(&local_b0);
    fVar4 = local_b0;
    fStack180 = local_ac;
  }
  local_b8 = fVar4 + 20.0;
  local_d8 = fVar5 + fVar4 + -20.0;
  fStack212 = param_2 + fStack180;
  uStack200 = 0x3f8000003f70f0f2;
  local_d0 = 0x3f70f0f23f70f0f2;
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
  ImDrawList_AddRectFilled(0x41400000,uVar3,&local_b8,&local_d8,uVar2,0);
  Gui_CustomItemRowCore(param_1,param_4,param_5,param_6,param_7,param_8,param_10);
  local_d0 = CONCAT44(param_2 + local_ac + 20.0,local_b0);
  ImGui_SetCursorScreenPos(&local_d0);
  if (*(long *)(lVar1 + 0x28) == local_a8) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

