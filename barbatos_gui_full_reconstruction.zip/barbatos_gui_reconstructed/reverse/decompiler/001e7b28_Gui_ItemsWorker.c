/* Entry: 0x001e7b28; Ghidra function: Gui_ItemsWorker */


size_t Gui_ItemsWorker(void *param_1,long param_2,long param_3,void **param_4)

{
  void *pvVar1;
  size_t __n;
  void *pvVar2;
  
  __n = param_3 * param_2;
  pvVar1 = realloc(*param_4,(long)param_4[1] + __n + 1);
  *param_4 = pvVar1;
  if (pvVar1 == (void *)0x0) {
    fwrite(&DAT_0011a4f9,0x13,1,(FILE *)select);
    __n = 0;
  }
  else {
    pvVar2 = param_4[1];
    memcpy((void *)((long)pvVar1 + (long)pvVar2),param_1,__n);
    pvVar2 = (void *)((long)pvVar2 + __n);
    param_4[1] = pvVar2;
    *(undefined *)((long)pvVar1 + (long)pvVar2) = 0;
  }
  return __n;
}

