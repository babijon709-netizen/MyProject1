/* Entry: 0x001eb9cc; Ghidra function: Gui_ListDirectory */


void Gui_ListDirectory(char *param_1,byte **param_2,undefined8 param_3,undefined8 param_4)

{
  long lVar1;
  undefined6 uVar2;
  ushort uVar3;
  undefined2 uVar4;
  bool bVar5;
  int iVar6;
  DIR *__dirp;
  dirent *pdVar7;
  size_t sVar8;
  ulong *puVar9;
  void *pvVar10;
  undefined8 *puVar11;
  uint *puVar12;
  char *pcVar13;
  undefined8 *puVar14;
  byte *pbVar15;
  void *pvVar16;
  byte *pbVar17;
  byte *pbVar18;
  char *pcVar19;
  ulong uVar20;
  undefined local_150 [16];
  void *local_140;
  byte *local_c8;
  ulong local_c0;
  ulong uStack184;
  char *local_b0;
  undefined8 local_a0;
  undefined8 uStack152;
  byte local_90;
  undefined5 uStack143;
  undefined2 uStack138;
  undefined6 local_88;
  undefined2 uStack130;
  void *local_80;
  long local_78;
  
  lVar1 = cRead_8(tpidr_el0);
  local_78 = *(long *)(lVar1 + 0x28);
  pbVar17 = *param_2;
  pbVar18 = param_2[1];
  local_a0 = param_4;
  uStack152 = param_3;
  while (pbVar15 = pbVar18, pbVar15 != pbVar17) {
    pbVar18 = pbVar15 + -0x18;
    if ((*pbVar18 & 1) != 0) {
      free(*(void **)(pbVar15 + -8));
    }
  }
  param_2[1] = pbVar17;
  __dirp = opendir(param_1);
  if (__dirp == (DIR *)0x0) {
    perror("opendir failed");
    puVar12 = (uint *)__errno();
    pcVar13 = strerror(*puVar12);
    fprintf((FILE *)select,&DAT_00126899,pcVar13,(ulong)*puVar12);
  }
  else {
    pdVar7 = readdir(__dirp);
    if (pdVar7 != (dirent *)0x0) {
      pvVar16 = (void *)((ulong)&local_90 | 1);
      puVar14 = (undefined8 *)((ulong)&local_c0 | 2);
      do {
        pcVar13 = pdVar7->d_name;
        iVar6 = strcmp(pcVar13,".");
        if ((iVar6 != 0) && (iVar6 = strcmp(pcVar13,".."), iVar6 != 0)) {
          sVar8 = strlen(param_1);
          if (0xffffffffffffffef < sVar8) {
                    /* WARNING: Subroutine does not return */
            FUN_0036b804(&local_90);
          }
          if (sVar8 < 0x17) {
            local_90 = (byte)((int)sVar8 << 1);
            pvVar10 = pvVar16;
            if (sVar8 != 0) goto LAB_002ebb20;
          }
          else {
            uVar20 = sVar8 + 0x10 & 0xfffffffffffffff0;
            pvVar10 = (void *)FUN_0036b114(uVar20);
            local_90 = (byte)uVar20 | 1;
            local_88 = (undefined6)sVar8;
            uStack130 = (undefined2)(sVar8 >> 0x30);
            uStack143 = (undefined5)(uVar20 >> 8);
            uStack138 = (undefined2)(uVar20 >> 0x30);
            local_80 = pvVar10;
LAB_002ebb20:
            memcpy(pvVar10,param_1,sVar8);
          }
          *(undefined *)((long)pvVar10 + sVar8) = 0;
                    /* try { // try from 002ebb34 to 002ebb3f has its CatchHandler @ 002ebe98 */
          puVar9 = (ulong *)FUN_0036c1a8(&local_90,&DAT_0011925d);
          local_140 = (void *)puVar9[2];
          local_150._8_8_ = puVar9[1];
          local_150._0_8_ = (byte *)*puVar9;
          puVar9[1] = 0;
          puVar9[2] = 0;
          *puVar9 = 0;
                    /* try { // try from 002ebb58 to 002ebb63 has its CatchHandler @ 002ebe7c */
          puVar9 = (ulong *)FUN_0036c1a8(local_150,pcVar13);
          local_b0 = (char *)puVar9[2];
          uStack184 = puVar9[1];
          local_c0 = *puVar9;
          puVar9[1] = 0;
          puVar9[2] = 0;
          *puVar9 = 0;
          if (((ulong)local_150._0_8_ & 1) != 0) {
            free(local_140);
          }
          if ((local_90 & 1) != 0) {
            free(local_80);
          }
          iVar6 = strcmp(param_1,"/");
          if (iVar6 == 0) {
            sVar8 = strlen(param_1);
            if (0xffffffffffffffef < sVar8) {
                    /* try { // try from 002ebe38 to 002ebe3f has its CatchHandler @ 002ebe5c */
                    /* WARNING: Subroutine does not return */
              FUN_0036b804(local_150);
            }
            if (sVar8 < 0x17) {
              local_150._0_8_ =
                   (byte *)((ulong)local_150._0_8_ & 0xffffffffffffff00 |
                           (ulong)(byte)((int)sVar8 << 1));
              pvVar10 = (void *)((ulong)local_150 | 1);
              if (sVar8 != 0) goto LAB_002ebbfc;
            }
            else {
              uVar20 = sVar8 + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 002ebbe4 to 002ebbeb has its CatchHandler @ 002ebe48 */
              pvVar10 = (void *)FUN_0036b114(uVar20);
              local_150._0_8_ = (byte *)(uVar20 | 1);
              local_150._8_8_ = sVar8;
              local_140 = pvVar10;
LAB_002ebbfc:
              memcpy(pvVar10,param_1,sVar8);
            }
            *(undefined *)((long)pvVar10 + sVar8) = 0;
                    /* try { // try from 002ebc10 to 002ebc1b has its CatchHandler @ 002ebe64 */
            puVar11 = (undefined8 *)FUN_0036c1a8(local_150,pcVar13);
            uVar3 = *(ushort *)puVar11;
            local_90 = (byte)*(undefined8 *)((long)puVar11 + 2);
            uStack143 = (undefined5)((ulong)*(undefined8 *)((long)puVar11 + 2) >> 8);
            pcVar19 = (char *)puVar11[2];
            uStack138 = (undefined2)puVar11[1];
            local_88 = (undefined6)((ulong)puVar11[1] >> 0x10);
            puVar11[1] = 0;
            puVar11[2] = 0;
            *puVar11 = 0;
            if ((local_c0 & 1) != 0) {
              free(local_b0);
            }
            local_c0 = local_c0 & 0xffffffffffff0000 | (ulong)uVar3;
            *puVar14 = CONCAT26(uStack138,CONCAT51(uStack143,local_90));
            *(ulong *)((long)puVar14 + 6) = CONCAT62(local_88,uStack138);
            local_b0 = pcVar19;
            if (((ulong)local_150._0_8_ & 1) != 0) {
              free(local_140);
            }
          }
          local_90 = 0;
          uStack143 = 0;
          uStack138 = 0;
          local_88 = 0;
          uStack130 = 0;
          local_80 = (void *)0x0;
                    /* try { // try from 002ebc98 to 002ebca3 has its CatchHandler @ 002ebeac */
          local_150._0_8_ = &local_90;
          FUN_002ecc30(local_150,&uStack152);
                    /* try { // try from 002ebca8 to 002ebcb3 has its CatchHandler @ 002ebe94 */
          local_c8 = &local_90;
          FUN_002ecd58(&local_c8,&local_a0);
          pbVar18 = (byte *)CONCAT26(uStack138,CONCAT51(uStack143,local_90));
          pbVar17 = (byte *)CONCAT26(uStack130,local_88);
          if (pbVar18 == pbVar17) {
            bVar5 = false;
          }
          else {
            do {
              pbVar15 = *(byte **)(pbVar18 + 0x10);
              if ((*pbVar18 & 1) == 0) {
                pbVar15 = pbVar18 + 1;
              }
              pcVar19 = strstr(pcVar13,(char *)pbVar15);
              pbVar18 = pbVar18 + 0x18;
            } while (pcVar19 == (char *)0x0 && pbVar18 != pbVar17);
            bVar5 = pcVar19 != (char *)0x0;
          }
          pcVar13 = (char *)((ulong)&local_c0 | 1);
          if ((local_c0 & 1) != 0) {
            pcVar13 = local_b0;
          }
          stat(pcVar13,(stat *)local_150);
          if ((((uint)local_140 & 0xf000) == 0x4000) || (bVar5)) {
            pbVar18 = param_2[1];
            if (pbVar18 == param_2[2]) {
                    /* try { // try from 002ebd48 to 002ebd53 has its CatchHandler @ 002ebe44 */
              FUN_00270c90(param_2,&local_c0);
            }
            else {
                    /* try { // try from 002ebd30 to 002ebd3b has its CatchHandler @ 002ebe50 */
              FUN_0036b974(pbVar18,&local_c0);
              param_2[1] = pbVar18 + 0x18;
            }
          }
          uVar4 = uStack138;
          uVar2 = CONCAT51(uStack143,local_90);
          pbVar18 = (byte *)CONCAT26(uStack138,uVar2);
          if (pbVar18 != (byte *)0x0) {
            pbVar17 = (byte *)CONCAT26(uStack130,local_88);
            if (pbVar17 != pbVar18) {
              do {
                pbVar15 = pbVar17 + -0x18;
                if ((*pbVar15 & 1) != 0) {
                  free(*(void **)(pbVar17 + -8));
                }
                pbVar17 = pbVar15;
              } while (pbVar15 != pbVar18);
              pbVar18 = (byte *)CONCAT26(uStack138,CONCAT51(uStack143,local_90));
            }
            uStack130 = uVar4;
            local_88 = uVar2;
            free(pbVar18);
          }
          if ((local_c0 & 1) != 0) {
            free(local_b0);
          }
        }
        pdVar7 = readdir(__dirp);
      } while (pdVar7 != (dirent *)0x0);
    }
  }
  iVar6 = closedir(__dirp);
  if (*(long *)(lVar1 + 0x28) != local_78) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar6);
  }
  return;
}

