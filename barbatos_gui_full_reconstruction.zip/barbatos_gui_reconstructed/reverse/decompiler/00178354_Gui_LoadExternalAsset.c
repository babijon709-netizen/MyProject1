/* Entry: 0x00178354; Ghidra function: Gui_LoadExternalAsset */


void Gui_LoadExternalAsset(char *param_1)

{
  undefined4 *puVar1;
  long lVar2;
  void *pvVar3;
  void *pvVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  FILE *__stream;
  ulong uVar7;
  void *__s;
  undefined4 *puVar8;
  ulong uVar9;
  size_t sVar10;
  char local_e0;
  char cStack223;
  char cStack222;
  undefined5 uStack221;
  void *local_c8;
  void *local_c0;
  void *local_a0;
  void *local_98;
  void *local_88;
  void *local_80;
  long local_68;
  
  lVar2 = cRead_8(tpidr_el0);
  local_68 = *(long *)(lVar2 + 0x28);
  __stream = fopen(param_1,"rb");
  if (__stream == (FILE *)0x0) {
    printf(&DAT_001200d0,param_1);
    puVar5 = DAT_0050d728;
    if (DAT_0050d730 < DAT_0050d738) {
      *DAT_0050d730 = 0;
      DAT_0050d730 = DAT_0050d730 + 1;
    }
    else {
      sVar10 = (long)DAT_0050d730 - (long)DAT_0050d728;
      uVar7 = ((long)sVar10 >> 2) + 1;
      if (uVar7 >> 0x3e != 0) {
                    /* WARNING: Subroutine does not return */
        FUN_0036e680(&DAT_0050d728);
      }
      uVar9 = (long)DAT_0050d738 - (long)DAT_0050d728 >> 1;
      if (uVar7 <= uVar9) {
        uVar7 = uVar9;
      }
      if (0x7ffffffffffffffb < (ulong)((long)DAT_0050d738 - (long)DAT_0050d728)) {
        uVar7 = 0x3fffffffffffffff;
      }
      if (uVar7 == 0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        if (uVar7 >> 0x3e != 0) {
                    /* WARNING: Subroutine does not return */
          FUN_00268d80("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
        }
        puVar8 = (undefined4 *)FUN_0036b114(uVar7 << 2);
      }
      puVar1 = puVar8 + ((long)sVar10 >> 2);
      *puVar1 = 0;
      if (0 < (long)sVar10) {
        memcpy(puVar8,puVar5,sVar10);
      }
      DAT_0050d728 = puVar8;
      DAT_0050d730 = puVar1 + 1;
      DAT_0050d738 = puVar8 + uVar7;
      if (puVar5 != (undefined4 *)0x0) {
        free(puVar5);
      }
    }
  }
  else {
    fseek(__stream,0,2);
    uVar7 = ftell(__stream);
    if ((long)uVar7 < 1) {
      printf(&DAT_0011b4ff,uVar7);
      puVar5 = DAT_0050d728;
      if (DAT_0050d730 < DAT_0050d738) {
        *DAT_0050d730 = 0;
        DAT_0050d730 = DAT_0050d730 + 1;
      }
      else {
        sVar10 = (long)DAT_0050d730 - (long)DAT_0050d728;
        uVar7 = ((long)sVar10 >> 2) + 1;
        if (uVar7 >> 0x3e != 0) {
                    /* try { // try from 002787bc to 002787c7 has its CatchHandler @ 00278814 */
                    /* WARNING: Subroutine does not return */
          FUN_0036e680(&DAT_0050d728);
        }
        uVar9 = (long)DAT_0050d738 - (long)DAT_0050d728 >> 1;
        if (uVar7 <= uVar9) {
          uVar7 = uVar9;
        }
        if (0x7ffffffffffffffb < (ulong)((long)DAT_0050d738 - (long)DAT_0050d728)) {
          uVar7 = 0x3fffffffffffffff;
        }
        if (uVar7 == 0) {
          puVar8 = (undefined4 *)0x0;
        }
        else {
          if (uVar7 >> 0x3e != 0) {
                    /* try { // try from 002787e0 to 002787eb has its CatchHandler @ 00278814 */
                    /* WARNING: Subroutine does not return */
            FUN_00268d80("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
          }
                    /* try { // try from 00278600 to 00278603 has its CatchHandler @ 00278814 */
          puVar8 = (undefined4 *)FUN_0036b114(uVar7 << 2);
        }
        puVar1 = puVar8 + ((long)sVar10 >> 2);
        *puVar1 = 0;
        if (0 < (long)sVar10) {
          memcpy(puVar8,puVar5,sVar10);
        }
        DAT_0050d728 = puVar8;
        DAT_0050d730 = puVar1 + 1;
        DAT_0050d738 = puVar8 + uVar7;
        if (puVar5 != (undefined4 *)0x0) {
          free(puVar5);
        }
      }
    }
    else {
      rewind(__stream);
                    /* try { // try from 002783c0 to 002783c7 has its CatchHandler @ 00278818 */
      __s = (void *)thunk_FUN_0036b114(uVar7);
      memset(__s,0,uVar7);
      fread(__s,1,uVar7,__stream);
      rewind(__stream);
      fread(&local_e0,1,4,__stream);
      rewind(__stream);
      if (((local_e0 == 'G') && (cStack223 == 'I')) && (cStack222 == 'F')) {
                    /* try { // try from 00278434 to 00278443 has its CatchHandler @ 002787fc */
        Gui_DecodeImage(__s,uVar7 & 0xffffffff);
        Gui_SetExternalAsset(&DAT_0050d728,&local_e0);
        if (local_88 != (void *)0x0) {
          local_80 = local_88;
          free(local_88);
        }
        pvVar3 = local_a0;
        if (local_a0 != (void *)0x0) {
          while (pvVar4 = local_98, pvVar4 != pvVar3) {
            local_98 = (void *)((long)pvVar4 + -0x20);
            if ((*(byte *)((long)pvVar4 + -0x18) & 1) != 0) {
              free(*(void **)((long)pvVar4 + -8));
            }
          }
          local_98 = pvVar3;
          free(local_a0);
        }
        if (local_c8 != (void *)0x0) {
          local_c0 = local_c8;
          free(local_c8);
        }
        pvVar3 = (void *)CONCAT53(uStack221,CONCAT12(cStack222,CONCAT11(cStack223,local_e0)));
        if (pvVar3 != (void *)0x0) {
          free(pvVar3);
        }
        DAT_0050d760 = 0;
      }
      else {
        DAT_0050d730 = DAT_0050d728;
                    /* try { // try from 0027851c to 00278533 has its CatchHandler @ 00278800 */
        uVar6 = Gui_CreateTextureFromMemory(__s,uVar7 & 0xffffffff,0,0,0);
        puVar5 = DAT_0050d728;
        if (DAT_0050d730 < DAT_0050d738) {
          *DAT_0050d730 = uVar6;
          DAT_0050d730 = DAT_0050d730 + 1;
        }
        else {
          sVar10 = (long)DAT_0050d730 - (long)DAT_0050d728;
          uVar7 = ((long)sVar10 >> 2) + 1;
          if (uVar7 >> 0x3e != 0) {
                    /* try { // try from 002787d4 to 002787df has its CatchHandler @ 00278804 */
                    /* WARNING: Subroutine does not return */
            FUN_0036e680(&DAT_0050d728);
          }
          uVar9 = (long)DAT_0050d738 - (long)DAT_0050d728 >> 1;
          if (uVar7 <= uVar9) {
            uVar7 = uVar9;
          }
          if (0x7ffffffffffffffb < (ulong)((long)DAT_0050d738 - (long)DAT_0050d728)) {
            uVar7 = 0x3fffffffffffffff;
          }
          if (uVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
          }
          else {
            if (uVar7 >> 0x3e != 0) {
                    /* try { // try from 002787ec to 002787f7 has its CatchHandler @ 00278804 */
                    /* WARNING: Subroutine does not return */
              FUN_00268d80("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
            }
                    /* try { // try from 00278658 to 0027865b has its CatchHandler @ 00278804 */
            puVar8 = (undefined4 *)FUN_0036b114(uVar7 << 2);
          }
          puVar1 = puVar8 + ((long)sVar10 >> 2);
          *puVar1 = uVar6;
          if (0 < (long)sVar10) {
            memcpy(puVar8,puVar5,sVar10);
          }
          DAT_0050d728 = puVar8;
          DAT_0050d730 = puVar1 + 1;
          DAT_0050d738 = puVar8 + uVar7;
          if (puVar5 != (undefined4 *)0x0) {
            free(puVar5);
          }
        }
      }
      free(__s);
    }
    fclose(__stream);
  }
  if (*(long *)(lVar2 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

