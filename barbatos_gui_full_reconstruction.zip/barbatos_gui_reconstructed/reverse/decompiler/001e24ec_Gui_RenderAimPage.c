/* Entry: 0x001e24ec; Ghidra function: Gui_RenderAimPage */


/* WARNING: Could not reconcile some variable overlaps */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_RenderAimPage(void)

{
  undefined *puVar1;
  long lVar2;
  char *pcVar3;
  bool bVar4;
  undefined4 uVar5;
  int iVar6;
  long lVar7;
  undefined8 uVar8;
  ulong uVar9;
  char *pcVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined auVar15 [16];
  float fVar16;
  float fVar17;
  undefined8 local_378;
  char *local_370 [4];
  char *local_350;
  char *pcStack840;
  undefined *local_340;
  undefined *local_338;
  undefined8 local_330;
  undefined8 uStack808;
  undefined *puStack800;
  undefined *puStack792;
  undefined8 local_170;
  undefined8 uStack360;
  undefined *local_160;
  char *local_150 [4];
  char *local_130;
  char *pcStack296;
  undefined8 local_120;
  undefined8 uStack280;
  undefined *local_110;
  char *local_108;
  char *local_100;
  char *local_f8;
  undefined8 local_f0;
  undefined *local_e8;
  char *pcStack224;
  undefined4 *local_d8;
  undefined8 local_d0;
  undefined *local_c8;
  char **ppcStack192;
  undefined4 *local_b8;
  undefined8 local_b0;
  undefined *local_a8;
  long local_98;
  
  lVar2 = cRead_8(tpidr_el0);
  local_98 = *(long *)(lVar2 + 0x28);
  if (((DAT_0050e900 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050e900), iVar6 != 0)) {
    DAT_0050e8f8 = '\0';
    DAT_0050e8fc = 0.0;
    DAT_0050e8f4 = 0.08;
    FUN_0036eca0(&DAT_0050e900);
  }
  lVar7 = ImGui_GetIO();
  fVar12 = DAT_0050e8fc;
  fVar11 = 1000.0 / (*(float *)(lVar7 + 0x10) * 1000.0);
  uVar9 = (ulong)(uint)fVar11;
  fVar16 = 44.0;
  if (44.0 <= fVar11) {
    fVar11 = 0.0;
    if (DAT_0050e8f8 != '\0') {
      fVar11 = 1.0;
    }
    lVar7 = ImGui_GetIO();
    fVar12 = (float)NEON_fmadd(*(float *)(lVar7 + 0x10) / DAT_0050e8f4,fVar11 - DAT_0050e8fc,fVar12)
    ;
    fVar16 = (float)NEON_fmin(fVar12,0x3f800000);
    uVar9 = 0;
    if (0.0 <= fVar12) {
      uVar9 = (ulong)(uint)fVar16;
    }
    DAT_0050e8fc = (float)uVar9;
  }
  DAT_0050e8f8 = DAT_004d6f80 != -1;
  if ((DAT_0050e634 == 0) || (DAT_0050e637 == 0)) {
    if ((DAT_0050e634 | DAT_0050e637) == 0) {
      if (DAT_0050e8e4 == 0.0) {
        DAT_0050e8e8 = FUN_0034a23c();
      }
      lVar7 = FUN_0034a23c();
      fVar12 = (float)((lVar7 - DAT_0050e8e8) / 1000) / 1000.0;
      if (fVar12 == 0.0) {
        fVar12 = 1.0;
      }
      fVar16 = 1500.0;
      uVar9 = (ulong)(uint)fVar12;
      if (1500.0 <= fVar12) {
        uVar9 = 0;
      }
      DAT_0050e8e4 = (float)uVar9;
      if (1500.0 <= fVar12) {
        DAT_0050e8dc = '\0';
      }
    }
  }
  else {
    DAT_0050e8dc = '\x01';
    DAT_0050e8e4 = 0.0;
  }
  local_370[0] = (char *)0x0;
  ImGui_BeginChild("##Aimright",local_370,0,0x800008);
  FUN_00292020();
  uVar8 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar12 = fVar16;
  fVar11 = fVar14;
  ImGui_GetWindowPos();
  fVar14 = (float)uVar9;
  fVar17 = fVar14 + fVar11;
  local_120 = (char *)(uVar9 & 0xffffffff | (ulong)(uint)fVar16 << 0x20);
  auVar15 = NEON_fmov(0x3f800000,4);
  local_150[0] = (char *)CONCAT44(fVar16 + fVar12,fVar17);
  local_370[1] = SUB168(auVar15 >> 0x40,0);
  local_370[0] = SUB168(auVar15,0);
  uVar5 = ImGui_ColorConvertFloat4ToU32(local_370[0],local_370);
  ImDrawList_AddRectFilled(uVar8,&local_120,local_150,uVar5,0xa0);
  if (DAT_0050d8d8 != 0) {
    local_120 = (char *)CONCAT44(fVar16 + fVar12,fVar17);
    local_370[0] = (char *)(uVar9 & 0xffffffff | (ulong)(uint)fVar16 << 0x20);
    FUN_002791f4(local_370,&local_120,0xa0);
    FUN_002514f8(DAT_0050d8d8);
    FUN_00279398();
  }
  fVar12 = 3.0;
  if (3.0 < DAT_0050e8f0) {
    local_120 = (char *)(uVar9 & 0xffffffff | (ulong)(uint)fVar16 << 0x20);
    fVar12 = 0.9019608;
    local_370[1] = (char *)0x3f1b9b9c3f66e6e8;
    local_370[0] = (char *)0x3f66e6e83f66e6e8;
    local_150[0] = (char *)CONCAT44(fVar16 + DAT_00395104,fVar17);
    uVar5 = ImGui_ColorConvertFloat4ToU32(local_370);
    ImDrawList_AddRectFilled(uVar8,&local_120,local_150,uVar5,0x20);
  }
  fVar13 = 55.0;
  ImGui_CalcTextSize(0,(&PTR_DAT_004d6f70)[DAT_004f3d14]);
  local_120 = (char *)CONCAT44(fVar16 + 39.0 + fVar12 * -0.5,fVar14 + fVar11 * 0.5 + fVar13 * -0.5);
  local_370[1] = (char *)0x3f8000003df0f0f2;
  local_370[0] = (char *)0x3df0f0f23df0f0f2;
  uVar5 = ImGui_ColorConvertFloat4ToU32(local_370);
  fVar11 = 0.0;
  fVar14 = 0.0;
  ImDrawList_AddText(uVar8,0,&local_120,uVar5,(&PTR_DAT_004d6f70)[DAT_004f3d14],0,0);
  fVar12 = DAT_00395104;
  ImGui_SetCursorPosY();
  local_370[0] = (char *)0x0;
  uVar5 = 0x80000c;
  if (DAT_0050e8dc != '\0') {
    uVar5 = 0x840004;
  }
  ImGui_BeginChild("##centre",local_370,0,uVar5);
  ImGui_GetCursorScreenPos();
  fVar13 = fVar12;
  lVar7 = ImGui_GetWindowDrawList();
  if (DAT_004d6f80 == -1) {
    fVar14 = fVar13;
    Gui_OverlayStateBegin(DAT_0050e908);
    Gui_OverlayStateEnd(DAT_0050e908);
    Gui_OverlayAnimation(DAT_0050e908);
  }
  local_370[0] = (char *)CONCAT44(fVar11 + fVar14 + 10.0,fVar12);
  ImGui_SetCursorScreenPos(local_370);
  if (DAT_004f2080 == '\0') {
    local_370[1] = &UNK_00123393;
    local_370[0] = &UNK_0011c73f;
    if (DAT_004f3d14 != 0) {
      local_370[1] = "Aim Pos";
      local_370[0] = "Aiming";
    }
    uStack280 = SUB168(_PTR_DAT_0038c398 >> 0x40,0);
    local_120 = SUB168(_PTR_DAT_0038c398,0);
    if (((DAT_0050e948 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050e948), iVar6 != 0)) {
      DAT_0050e935 = DAT_004f2078;
      DAT_0050e928 = 0;
      if (DAT_004f2078 != '\0') {
        DAT_0050e928 = 0x3f800000;
      }
      DAT_0050e945 = DAT_004fb924;
      DAT_0050e934 = 0;
      DAT_0050e930 = 0x3da3d70a;
      DAT_0050e938 = 0;
      if (DAT_004fb924 != '\0') {
        DAT_0050e938 = 0x3f800000;
      }
      DAT_0050e944 = 0;
      DAT_0050e940 = 0x3da3d70a;
      DAT_0050e92c = DAT_0050e928;
      DAT_0050e93c = DAT_0050e938;
      FUN_0036eca0(&DAT_0050e948);
    }
    pcVar10 = &UNK_0011c74c;
    if (DAT_004f3d14 != 0) {
      pcVar10 = "Main Aim";
    }
    Gui_ToggleGroup(pcVar10,local_370,&local_120,2,&DAT_0050e928,DAT_0050d7f8);
    local_120 = (char *)CONCAT44(local_120._4_4_,2);
    local_370[0] = &UNK_00122834;
    if (DAT_004f3d14 != 0) {
      local_370[0] = "Other Aim Func";
    }
    Gui_ChoiceGroup(&DAT_004d6f80,0,local_370,&local_120,1,0);
    pcVar10 = &UNK_0012444e;
    if (DAT_004f3d14 != 0) {
      pcVar10 = "My Aim Player Place";
    }
    local_370[1] = SUB168(_PTR_DAT_0038c3a8 >> 0x40,0);
    local_370[0] = SUB168(_PTR_DAT_0038c3a8,0);
    local_370[2] = PTR_DAT_0038c3b8;
    Gui_ChoiceCombo(&DAT_004f20e8,pcVar10,local_370,3,DAT_0050d800);
    local_370[1] = &DAT_0012957f;
    if (DAT_004f3d14 != 0) {
      local_370[1] = "Click Aim";
    }
    local_370[0] = &DAT_00129ea4;
    local_370[2] = &DAT_001215d1;
    ppcStack192 = local_370;
    local_120 = (char *)0x160000000b;
    uStack280 = (undefined4 *)CONCAT44(uStack280._4_4_,0x21);
    Gui_ChoiceGroup(&DAT_004d6f80,&DAT_0011e0c9,local_370,&local_120,3,DAT_0050d808);
    pcVar10 = &UNK_0011e0df;
    if (DAT_004f3d14 != 0) {
      pcVar10 = "%d Vertical Recoil Reduction";
    }
    Gui_FormatText(local_370,0x80,pcVar10,DAT_004fb3e4);
    bVar4 = DAT_004f3d14 != 0;
    local_120 = &UNK_00124b75;
    if (bVar4) {
      local_120 = "Follow Gun Speed";
    }
    local_100 = &UNK_00129eb1;
    if (bVar4) {
      local_100 = "Aim Steadiness";
    }
    local_108 = "%.1f";
    local_f8 = (char *)&DAT_004f209c;
    local_110 = (undefined *)0x40a000003f19999a;
    pcStack224 = &UNK_0012a77f;
    if (bVar4) {
      pcStack224 = "All Vertical Recoil Reduction";
    }
    local_e8 = &DAT_0011b5ee;
    local_f0 = 0x42c8000041200000;
    local_d8 = &DAT_004f20a0;
    local_d0 = 0x40a000003f800000;
    local_c8 = &DAT_00123207;
    local_b8 = &DAT_004eee88 + DAT_004ef68c;
    local_a8 = &DAT_00123207;
    local_b0 = 0x40400000bf800000;
    pcVar10 = &UNK_00128f1b;
    if (bVar4) {
      pcVar10 = "Aim Numerical Value";
    }
    uStack280 = &DAT_004f2098;
    Gui_ValueEditorList(&DAT_0050e908,pcVar10,4,DAT_0050d810,&local_120);
    if (DAT_004f2081 == '\0') {
      local_338 = &DAT_00123207;
      local_370[0] = &UNK_0011e0ff;
      local_350 = &UNK_001256f5;
      if (DAT_004f3d14 != 0) {
        local_370[0] = "Horizontal Range";
        local_350 = "Vertical Range";
      }
      local_370[2] = (char *)0x40000000bf000000;
      local_340 = (undefined *)0x40000000bf000000;
      local_370[3] = &DAT_00123207;
      local_370[1] = (char *)&DAT_004f20a8;
      pcVar10 = &UNK_0011bf37;
      if (DAT_004f3d14 != 0) {
        pcVar10 = "Extra parameters";
      }
      pcStack840 = (char *)&DAT_004f20ac;
      uVar8 = DAT_0050d818;
    }
    else {
      local_338 = &DAT_0011b5ee;
      bVar4 = DAT_004f3d14 != 0;
      local_370[1] = (char *)&DAT_004f20b0;
      local_370[0] = &UNK_0011821c;
      if (bVar4) {
        local_370[0] = "Horizontal Range";
      }
      local_350 = &UNK_001215fc;
      if (bVar4) {
        local_350 = "Vertical Range";
      }
      local_370[2] = (char *)0x4402000042480000;
      pcStack840 = &DAT_004f20b4;
      local_370[3] = &DAT_0011b5ee;
      pcVar10 = &UNK_00129ed0;
      if (bVar4) {
        pcVar10 = "Extra parameters";
      }
      local_340 = (undefined *)0x4120000000000000;
      uVar8 = DAT_0050d820;
    }
    Gui_ValueEditorList(&DAT_0050e908,pcVar10,2,uVar8,local_370);
    bVar4 = DAT_004f3d14 != 0;
    local_370[0] = &UNK_00119d9a;
    if (bVar4) {
      local_370[0] = "Hip-Fire Aim Max Distance";
    }
    local_370[1] = (char *)&DAT_004f20b8;
    local_350 = &UNK_001285b2;
    if (bVar4) {
      local_350 = "All Aim Max Distance";
    }
    pcStack840 = (char *)0x4f20bc;
    local_370[2] = (undefined *)0x4316000041200000;
    local_370[3] = "%.0f";
    fVar14 = 10.0;
    pcVar10 = &UNK_00127d50;
    if (bVar4) {
      pcVar10 = "Parameters that limit the distance";
    }
    local_340 = (undefined *)0x43fa000041200000;
    local_338 = &DAT_0011b5ee;
    Gui_ValueEditorList(&DAT_0050e908,pcVar10,2,DAT_0050d828,local_370);
    ImGui_GetScrollY();
    DAT_0050e8f0 = fVar14;
    ImGui_EndChild();
    if ((lVar7 != 0) && (3.0 < DAT_0050e8f0)) {
      fVar14 = fVar16 + DAT_00395104 + 1.5;
      local_120 = (char *)(uVar9 & 0xffffffff | (ulong)(uint)fVar14 << 0x20);
      local_150[0] = (char *)CONCAT44(fVar14,fVar17);
      local_370[1] = (char *)0x3f8000003f20a0a1;
      local_370[0] = (char *)0x3f20a0a13f20a0a1;
      uVar5 = ImGui_ColorConvertFloat4ToU32(local_370);
      ImDrawList_AddLine(lVar7,&local_120,local_150,uVar5);
    }
    ImGui_EndChild();
    if ((DAT_0050e8f8 == '\0') || (DAT_0039516c != '\0')) {
      if (DAT_0039516c != '\0') goto LAB_002e2f24;
    }
    else {
      DAT_00395170 = Gui_RenderImageLayer
                               ("Hello ImGui",&DAT_004f8160,&DAT_004f8168,(int)DAT_00395174,4);
      _DAT_0039516c = 0x101;
LAB_002e2f24:
      local_370[0] = (char *)0x0;
      ImGui_SetCursorPos(local_370);
      local_370[0] = (char *)0x0;
      ImGui_BeginChild("##BottomBlur",local_370,0,0x800008);
      uVar8 = ImGui_GetWindowDrawList();
      local_370[0] = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                                      (float)DAT_004f8160 + (float)DAT_004f8168);
      FUN_002792b4(&DAT_004f8160,local_370,(int)(DAT_0050e8fc * 255.0) + 1,0);
      local_370[0] = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                                      (float)DAT_004f8160 + (float)DAT_004f8168);
      local_150[0] = (char *)NEON_fmov(0x3f800000,4);
      local_120 = (char *)0x0;
      ImDrawList_AddRectFilledMultiColor
                (uVar8,DAT_00395170,&DAT_004f8160,local_370,&local_120,local_150,
                 (int)(DAT_0050e8fc * 255.0) * 0x1000000 + 0x1ffffff,0);
      local_120 = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                                   (float)DAT_004f8160 + (float)DAT_004f8168);
      local_370[0] = (char *)0x3f1696973f169697;
      local_370[1] = (char *)CONCAT44((float)(int)(DAT_0050e8fc * 100.0) * 0.003921569,0x3f169697);
      uVar5 = ImGui_ColorConvertFloat4ToU32(local_370);
      ImDrawList_AddRectFilled(uVar8,&DAT_004f8160,&local_120,uVar5,0);
      ImGui_EndChild();
      if (((DAT_0050e8f8 == '\0') && (DAT_0050e8fc <= 0.02)) &&
         (_DAT_0039516c = 0, DAT_00395170 != 0)) {
        glDeleteBuffers(1,&DAT_00395170);
        DAT_00395170 = 0;
      }
    }
    if (DAT_0050e8fc <= 0.02) goto LAB_002e299c;
    uVar5 = NEON_fmsub(DAT_0050e8fc,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
    local_370[0] = (char *)CONCAT44(uVar5,0x428c0000);
    ImGui_SetCursorPos(local_370);
    local_370[1] = SUB168(_DAT_0012b3c0 >> 0x40,0);
    local_370[0] = SUB168(_DAT_0012b3c0,0);
    ImGui_PushStyleColor(3,local_370);
    local_370[0] = (char *)CONCAT44(DAT_004f8168._4_4_ + -140.0,(float)DAT_004f8168 + -140.0);
    ImGui_BeginChild("##NewAimPage1",local_370,0,0x80000c);
    if (DAT_004d6f80 != -1) {
      DAT_0050e954 = DAT_004d6f80;
    }
    ImGui_PopStyleColor(1);
    ImGui_GetWindowDrawList();
    ImGui_GetCursorScreenPos();
    ImGui_GetWindowPos();
    ImGui_GetWindowSize();
    time((time_t *)0x0);
    FUN_0036cf74();
    puVar1 = (undefined *)((ulong)local_370 | 1);
    if (((ulong)local_370[0] & 1) != 0) {
      puVar1 = local_370[2];
    }
                    /* try { // try from 002e3188 to 002e318b has its CatchHandler @ 002e3af8 */
    uVar9 = Gui_CloseButton(puVar1);
    if (((ulong)local_370[0] & 1) != 0) {
      free(local_370[2]);
    }
    if ((uVar9 & 1) != 0) {
      DAT_004d6f80 = -1;
      DAT_0050e8d8 = 0;
    }
    ImGui_SetCursorPosY();
    Gui_OverlayStateBegin(DAT_0050e950);
    switch(DAT_0050e954) {
    case 2:
      local_120 = &DAT_004f2080;
      uStack280 = (undefined4 *)&DAT_004f2081;
      local_110 = &DAT_004f2082;
      local_108 = &DAT_004f2083;
      local_f8 = &DAT_004f2085;
      pcStack840 = SUB168(_PTR_DAT_0038c3e0 >> 0x40,0);
      local_350 = SUB168(_PTR_DAT_0038c3e0,0);
      local_338 = PTR_s_Circle_Aim_0038c3f8;
      local_340 = PTR_s_Only_Draw_0038c3f0;
      uStack808 = SUB168(_PTR_s_Finger_Interference_Aim_0038c400 >> 0x40,0);
      local_330 = SUB168(_PTR_s_Finger_Interference_Aim_0038c400,0);
      puStack792 = PTR_s_Not_Ai_0038c418;
      puStack800 = PTR_s_Not_aim_lie_down_0038c410;
      local_100 = &DAT_004f2084;
      local_370[1] = SUB168(_PTR_DAT_0038c3c0 >> 0x40,0);
      local_370[0] = SUB168(_PTR_DAT_0038c3c0,0);
      local_370[3] = PTR_DAT_0038c3d8;
      local_370[2] = PTR_DAT_0038c3d0;
      if (((DAT_0050e9b8 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050e9b8), iVar6 != 0)) {
        DAT_0050e965 = DAT_004f2080;
        DAT_0050e975 = DAT_004f2081;
        DAT_0050e9b5 = DAT_004f2085;
        DAT_0050e998 = 0;
        DAT_0050e958 = DAT_0050e998;
        if (DAT_004f2080 != '\0') {
          DAT_0050e958 = 0x3f800000;
        }
        DAT_0050e985 = DAT_004f2082;
        DAT_0050e968 = DAT_0050e998;
        if (DAT_004f2081 != '\0') {
          DAT_0050e968 = 0x3f800000;
        }
        DAT_0050e995 = DAT_004f2083;
        DAT_0050e964 = 0;
        DAT_0050e960 = 0x3da3d70a;
        DAT_0050e978 = DAT_0050e998;
        if (DAT_004f2082 != '\0') {
          DAT_0050e978 = 0x3f800000;
        }
        DAT_0050e9a5 = DAT_004f2084;
        DAT_0050e974 = 0;
        DAT_0050e970 = 0x3da3d70a;
        DAT_0050e988 = DAT_0050e998;
        if (DAT_004f2083 != '\0') {
          DAT_0050e988 = 0x3f800000;
        }
        DAT_0050e984 = 0;
        DAT_0050e980 = 0x3da3d70a;
        DAT_0050e994 = 0;
        if (DAT_004f2084 != '\0') {
          DAT_0050e998 = 0x3f800000;
        }
        DAT_0050e990 = 0x3da3d70a;
        DAT_0050e9a8 = 0;
        if (DAT_004f2085 != '\0') {
          DAT_0050e9a8 = 0x3f800000;
        }
        DAT_0050e9a4 = 0;
        DAT_0050e9a0 = 0x3da3d70a;
        DAT_0050e9b4 = 0;
        DAT_0050e9b0 = 0x3da3d70a;
        DAT_0050e95c = DAT_0050e958;
        DAT_0050e96c = DAT_0050e968;
        DAT_0050e97c = DAT_0050e978;
        DAT_0050e98c = DAT_0050e988;
        DAT_0050e99c = DAT_0050e998;
        DAT_0050e9ac = DAT_0050e9a8;
        FUN_0036eca0(&DAT_0050e9b8);
      }
      Gui_ToggleGroup(0,local_370 + (long)DAT_004f3d14 * 6,&local_120,6,&DAT_0050e958,0);
      break;
    case 0xb:
      local_370[0] = &DAT_00129ea4;
      local_370[1] = &DAT_0011a498;
      local_370[2] = &DAT_0011b616;
      local_370[3] = "Not Shoot Auto Aiming";
      local_350 = "Pos[Move to Game Aiming Button]";
      pcStack840 = "Shoot Bullet Count > 5 Run";
      local_150[1] = SUB168(_PTR_DAT_0038c420 >> 0x40,0);
      local_150[0] = SUB168(_PTR_DAT_0038c420,0);
      local_150[2] = PTR_DAT_0038c430;
      if (((DAT_0050e9f0 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050e9f0), iVar6 != 0)) {
        DAT_0050e9cd = DAT_004f2079;
        DAT_0050e9c0 = 0;
        if (DAT_004f2079 != '\0') {
          DAT_0050e9c0 = 0x3f800000;
        }
        DAT_0050e9dd = DAT_004fb928;
        DAT_0050e9cc = 0;
        DAT_0050e9dc = 0;
        DAT_0050e9ed = DAT_004f208d;
        DAT_0050e9d0 = 0;
        if (DAT_004fb928 != '\0') {
          DAT_0050e9d0 = 0x3f800000;
        }
        DAT_0050e9c8 = 0x3da3d70a;
        DAT_0050e9d8 = 0x3da3d70a;
        DAT_0050e9e0 = 0;
        if (DAT_004f208d != '\0') {
          DAT_0050e9e0 = 0x3f800000;
        }
        DAT_0050e9ec = 0;
        DAT_0050e9e8 = 0x3da3d70a;
        DAT_0050e9c4 = DAT_0050e9c0;
        DAT_0050e9d4 = DAT_0050e9d0;
        DAT_0050e9e4 = DAT_0050e9e0;
        FUN_0036eca0(&DAT_0050e9f0);
      }
      pcVar10 = &DAT_00129ea4;
      if ((long)DAT_004f3d14 != 0) {
        pcVar10 = "Not Shoot Auto Aiming";
      }
      Gui_ToggleGroup(pcVar10,local_370 + (long)DAT_004f3d14 * 3,local_150,3,&DAT_0050e9c0,
                      DAT_0050d830);
      local_120 = &DAT_0011b638;
      uStack280 = (undefined4 *)&DAT_00127d66;
      puVar1 = &UNK_001233b8;
      if ((long)DAT_004f3d14 != 0) {
        puVar1 = &DAT_0011fbc1;
      }
      local_110 = &DAT_00127000;
      local_108 = "Fast";
      local_100 = "Average speed";
      local_f8 = &DAT_00120f2c;
      Gui_ChoiceCombo(&DAT_004f211c,puVar1,&local_120 + (long)DAT_004f3d14 * 3,3,0);
      break;
    case 0x16:
      local_150[0] = &DAT_0012957f;
      local_150[1] = &DAT_0012a7a3;
      local_150[2] = &DAT_0011b656;
      local_150[3] = "Continuous Click Aiming";
      local_130 = "Pos[Move to Game Shoot Button]";
      pcStack296 = "Aim Range Have Player To Run[Not Done]";
      local_160 = PTR_DAT_0038c448;
      uStack360 = SUB168(_PTR_DAT_0038c438 >> 0x40,0);
      local_170 = SUB168(_PTR_DAT_0038c438,0);
      if (((DAT_0050ea28 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050ea28), iVar6 != 0)) {
        DAT_0050ea05 = DAT_004f207a;
        DAT_0050ea15 = DAT_004fb92c;
        DAT_0050e9f8 = 0;
        if (DAT_004f207a != '\0') {
          DAT_0050e9f8 = 0x3f800000;
        }
        DAT_0050ea04 = 0;
        DAT_0050ea00 = 0x3da3d70a;
        DAT_0050ea25 = DAT_004f208e;
        DAT_0050ea08 = 0;
        if (DAT_004fb92c != '\0') {
          DAT_0050ea08 = 0x3f800000;
        }
        DAT_0050ea14 = 0;
        DAT_0050ea10 = 0x3da3d70a;
        DAT_0050ea24 = 0;
        DAT_0050ea18 = 0;
        if (DAT_004f208e != '\0') {
          DAT_0050ea18 = 0x3f800000;
        }
        DAT_0050ea20 = 0x3da3d70a;
        DAT_0050e9fc = DAT_0050e9f8;
        DAT_0050ea0c = DAT_0050ea08;
        DAT_0050ea1c = DAT_0050ea18;
        FUN_0036eca0(&DAT_0050ea28);
      }
      Gui_ToggleGroup(&DAT_0012957f,local_150 + (long)DAT_004f3d14 * 3,&local_170,3,&DAT_0050e9f8,
                      DAT_0050d838);
      pcVar10 = &UNK_00125702;
      if (DAT_004f3d14 != 0) {
        pcVar10 = "Second Once";
      }
      Gui_FormatText(&local_120,0x34,"%.2f %s",pcVar10);
      pcVar10 = &UNK_0012570c;
      if (DAT_004f3d14 != 0) {
        pcVar10 = "Speed [Second]";
      }
      Gui_ValueEditor(&DAT_0050e950,pcVar10,0x4f20ec,&DAT_001192af,&local_120,DAT_0050d898);
      if (((DAT_0050ea40 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050ea40), iVar6 != 0)) {
        DAT_0050ea30 = 0;
        DAT_0050ea34 = 0;
        DAT_0050ea38 = 0;
        DAT_0050ea38 = FUN_0034a23c();
        FUN_0036eca0(&DAT_0050ea40);
      }
      pcVar10 = &UNK_0011c779;
      if (DAT_004f3d14 != 0) {
        pcVar10 = "Write To Weapon ID";
      }
      Gui_FormatText(local_370,0x200,"%s | %d",pcVar10,DAT_004fb3e4);
      local_378 = 0x427c000042a60000;
      uVar9 = Gui_ActionRow(local_370,&local_378,&DAT_0050ea30);
      if ((uVar9 & 1) != 0) {
        FUN_0024e4c4(DAT_004fb3e4);
      }
      break;
    case 0x21:
      local_120 = &DAT_0011a4ad;
      uStack280 = (undefined4 *)&DAT_001194cc;
      local_110 = &DAT_00119dad;
      local_108 = "Sniper rifle";
      local_100 = "Pos(Move the shoot button)";
      local_f8 = "nullptr";
      local_150[2] = PTR_DAT_0038c460;
      local_150[1] = SUB168(_PTR_DAT_0038c450 >> 0x40,0);
      local_150[0] = SUB168(_PTR_DAT_0038c450,0);
      if (((DAT_0050ea78 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050ea78), iVar6 != 0)) {
        DAT_0050ea55 = DAT_004f207b;
        DAT_0050ea48 = 0;
        if (DAT_004f207b != '\0') {
          DAT_0050ea48 = 0x3f800000;
        }
        DAT_0050ea65 = DAT_004fb930;
        DAT_0050ea75 = DAT_004f208c;
        DAT_0050ea54 = 0;
        DAT_0050ea58 = 0;
        if (DAT_004fb930 != '\0') {
          DAT_0050ea58 = 0x3f800000;
        }
        DAT_0050ea50 = 0x3da3d70a;
        DAT_0050ea68 = 0;
        if (DAT_004f208c != '\0') {
          DAT_0050ea68 = 0x3f800000;
        }
        DAT_0050ea64 = 0;
        DAT_0050ea60 = 0x3da3d70a;
        DAT_0050ea74 = 0;
        DAT_0050ea70 = 0x3da3d70a;
        DAT_0050ea4c = DAT_0050ea48;
        DAT_0050ea5c = DAT_0050ea58;
        DAT_0050ea6c = DAT_0050ea68;
        FUN_0036eca0(&DAT_0050ea78);
      }
      Gui_ToggleGroup(&DAT_001215d1,&local_120 + (long)DAT_004f3d14 * 3,local_150,3,&DAT_0050ea48,
                      DAT_0050d840);
      if (((DAT_0050ea90 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050ea90), iVar6 != 0)) {
        DAT_0050ea80 = 0;
        DAT_0050ea84 = 0;
        DAT_0050ea88 = 0;
        DAT_0050ea88 = FUN_0034a23c();
        FUN_0036eca0(&DAT_0050ea90);
      }
      pcVar10 = &UNK_0011c779;
      if (DAT_004f3d14 != 0) {
        pcVar10 = "Write To Weapon ID";
      }
      Gui_FormatText(local_370,0x200,"%s | %d",pcVar10,DAT_004fb3e4);
      local_170 = 0x427c000042a60000;
      uVar9 = Gui_ActionRow(local_370,&local_170,&DAT_0050ea80);
      if ((uVar9 & 1) != 0) {
        FUN_0024eb50(DAT_004fb3e4);
      }
    }
  }
  else {
    if (((DAT_0050e920 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_0050e920), iVar6 != 0)) {
      DAT_0050e919 = DAT_004f2080;
      DAT_0050e90c = 0;
      if (DAT_004f2080 != '\0') {
        DAT_0050e90c = 0x3f800000;
      }
      DAT_0050e918 = 0;
      DAT_0050e914 = 0x3da3d70a;
      DAT_0050e910 = DAT_0050e90c;
      FUN_0036eca0(&DAT_0050e920);
    }
    pcVar10 = &DAT_00126fec;
    pcVar3 = &UNK_00129e8e;
    if (DAT_004f3d14 != 0) {
      pcVar10 = "Only Draw";
      pcVar3 = "Now To Only Draw";
    }
    Gui_TwoStateRow(pcVar3,pcVar10,&DAT_004f2080,&DAT_0050e90c,DAT_0050d7f8);
    DAT_004d6f80 = -1;
    DAT_0050e8f8 = '\0';
    DAT_0050e8fc = 0.0;
    ImGui_EndChild();
  }
  ImGui_EndChild();
LAB_002e299c:
  if (*(long *)(lVar2 + 0x28) == local_98) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

