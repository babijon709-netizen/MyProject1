/* Entry: 0x0018b144; Ghidra function: Gui_ToggleGroup */


void Gui_ToggleGroup(undefined4 param_1,float param_2,long param_3,undefined8 *param_4,
                    undefined8 *param_5,ulong param_6,long param_7,long param_8)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  int iVar4;
  ulong uVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float local_c8;
  undefined4 uStack196;
  undefined8 local_c0;
  undefined8 uStack184;
  float local_a8;
  float fStack164;
  float local_a0;
  float local_9c;
  long local_98;
  
  lVar1 = cRead_8(tpidr_el0);
  local_98 = *(long *)(lVar1 + 0x28);
  fVar9 = param_2;
  uVar3 = ImGui_GetWindowDrawList();
  fVar6 = (float)ImGui_GetCursorScreenPos();
  fVar8 = fVar9;
  local_a0 = fVar6;
  local_9c = fVar9;
  fVar7 = (float)ImGui_GetWindowPos();
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_a8 = 0.0;
    if (param_8 != 0) {
      local_a8 = 55.0;
    }
    local_a8 = local_a8 + fVar6 + 50.0;
    uStack184 = 0x3f8000003df0f0f2;
    local_c0 = 0x3df0f0f23df0f0f2;
    fStack164 = fVar9;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_c0);
    ImDrawList_AddText(0x421c0000,uVar3,0,&local_a8,uVar2,param_3,0,0);
    if (param_8 == 0) {
      fVar6 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar6 + 70.0,fVar8 * 0.5 + fVar9 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_8);
      fVar6 = 10.0;
    }
    local_9c = fVar9 + fVar8 + fVar6;
    ImGui_SetCursorScreenPos(&local_a0);
    fVar6 = local_a0;
    fVar9 = local_9c;
  }
  iVar4 = (int)(param_6 & 0xffffffff);
  local_a8 = fVar7 + fVar6 + -20.0;
  fStack164 = (float)NEON_fmadd(param_2,(float)iVar4,fVar9);
  local_c0 = CONCAT44(fVar9,fVar6 + 20.0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar3,&local_c0,&local_a8,uVar2,0);
  if ((0 < iVar4) && (Gui_ToggleRowCore(param_1,*param_4,*param_5,param_7), iVar4 != 1)) {
    param_7 = param_7 + 0x10;
    uVar5 = 1;
    do {
      local_a8 = local_a0 + 45.0;
      uStack196 = NEON_fmadd(param_2,(float)(int)uVar5,local_9c);
      local_c8 = fVar7 + local_a0 + -20.0;
      uStack184 = 0x3f8000003f028283;
      local_c0 = 0x3f0282833f028283;
      fStack164 = (float)uStack196;
      uVar2 = ImGui_ColorConvertFloat4ToU32(&local_c0);
      ImDrawList_AddLine(0x3fc00000,uVar3,&local_a8,&local_c8,uVar2);
      Gui_ToggleRowCore(param_1,param_4[uVar5],param_5[uVar5],param_7);
      uVar5 = uVar5 + 1;
      param_7 = param_7 + 0x10;
    } while ((param_6 & 0xffffffff) != uVar5);
  }
  fVar6 = (float)NEON_fmadd(param_2,(float)iVar4,local_9c);
  local_c0 = CONCAT44(fVar6 + 20.0,local_a0);
  ImGui_SetCursorScreenPos(&local_c0);
  if (*(long *)(lVar1 + 0x28) == local_98) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

