/* Entry: 0x0018bdd4; Ghidra function: Gui_PresetColorPalette */


void Gui_PresetColorPalette
               (undefined8 param_1,float param_2,long param_3,undefined8 *param_4,long param_5)

{
  void *pvVar1;
  long lVar2;
  bool bVar3;
  byte bVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  ulong uVar9;
  undefined8 *puVar10;
  undefined *puVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined8 uVar16;
  float fVar17;
  float local_e8;
  float fStack228;
  ulong local_e0;
  undefined8 uStack216;
  void *local_d0;
  float local_c0;
  float fStack188;
  float local_b8;
  float local_b4;
  long local_b0;
  
  lVar2 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar2 + 0x28);
  fVar15 = param_2;
  uVar8 = ImGui_GetWindowDrawList();
  fVar12 = (float)ImGui_GetCursorScreenPos();
  local_b8 = fVar12;
  local_b4 = fVar15;
  FUN_002a5c2c();
  fVar13 = (float)ImGui_GetWindowPos();
  fVar17 = -40.0;
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_c0 = 0.0;
    if (param_5 != 0) {
      local_c0 = 55.0;
    }
    local_c0 = local_c0 + fVar12 + 50.0;
    uStack216 = 0x3f8000003df0f0f2;
    local_e0 = 0x3df0f0f23df0f0f2;
    fStack188 = fVar15;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_e0);
    ImDrawList_AddText(0x421c0000,0,uVar8,0,&local_c0,uVar5,param_3,0,0);
    if (param_5 == 0) {
      fVar12 = 20.0;
    }
    else {
      Gui_DrawTexture(fVar12 + 70.0,fVar17 * 0.5 + fVar15 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_5);
      fVar12 = 25.0;
    }
    local_b4 = fVar15 + fVar17 + fVar12;
    ImGui_SetCursorScreenPos(&local_b8);
  }
  fVar15 = 0.0;
  fVar17 = 0.0;
  fVar12 = (fVar13 + -40.0) / 6.0;
  uVar9 = 0;
  puVar10 = (undefined8 *)&DAT_004f1584;
  do {
    local_c0 = fVar15 + fVar12 + local_b8;
    fStack188 = fVar17 + param_2 + local_b4;
    local_e0 = CONCAT44(fVar17 + local_b4,fVar15 + local_b8 + 40.0);
    uVar5 = ImGui_ColorConvertFloat4ToU32(puVar10);
    ImDrawList_AddRectFilled(0x41400000,uVar8,&local_e0,&local_c0,uVar5,0);
    fVar13 = fVar17 + local_b4;
    local_e0 = CONCAT44(fVar13,fVar15 + local_b8 + 10.0);
    ImGui_SetCursorScreenPos(&local_e0);
    FUN_0036ce38(uVar9 & 0xffffffff);
    pvVar1 = (void *)((ulong)&local_e0 | 1);
    if ((local_e0 & 1) != 0) {
      pvVar1 = local_d0;
    }
                    /* try { // try from 0028c0f4 to 0028c0ff has its CatchHandler @ 0028c22c */
    local_c0 = fVar12;
    fStack188 = param_2;
    bVar4 = ImGui_Button(pvVar1,&local_c0,0);
    if ((local_e0 & 1) != 0) {
      free(local_d0);
    }
    if ((bVar4 & DAT_0050e634 == '\0') == 1) {
      uVar16 = *puVar10;
      param_4[1] = puVar10[1];
      *param_4 = uVar16;
    }
    iVar6 = ImGui_ColorConvertFloat4ToU32(param_4);
    iVar7 = ImGui_ColorConvertFloat4ToU32(puVar10);
    if (iVar6 == iVar7) {
      fStack188 = fVar17 + local_b4 + -7.0;
      local_c0 = fVar15 + local_b8 + 40.0 + -7.0;
      local_e8 = fVar15 + fVar12 + local_b8 + 7.0;
      fStack228 = fVar17 + param_2 + local_b4 + 7.0;
      uStack216 = 0x3f8000003f7eff00;
      local_e0 = 0x3f10909100000000;
      uVar5 = ImGui_ColorConvertFloat4ToU32(&local_e0);
      fVar13 = 7.0;
      ImDrawList_AddRect(0x41580000,uVar8,&local_c0,&local_e8,uVar5,0);
    }
    puVar11 = (&PTR_DAT_0038c010)[uVar9];
    fVar14 = (float)ImGui_CalcTextSize(0x42000000,0,puVar11);
    local_c0 = fVar12 * 0.5 + fVar15 + local_b8 + 20.0 + fVar14 * -0.5;
    fStack188 = fVar17 + param_2 + local_b4 + 10.0;
    uStack216 = 0x3f8000003e20a0a1;
    local_e0 = 0x3e20a0a13e20a0a1;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_e0);
    ImDrawList_AddText(0x42000000,uVar8,0,&local_c0,uVar5,puVar11,0,0);
    uVar9 = uVar9 + 1;
    fVar14 = fVar12 + fVar15;
    puVar10 = puVar10 + 2;
    fVar15 = param_2 + fVar13 + 25.0;
    bVar3 = ((uint)uVar9 & 0xff) + (int)((uVar9 & 0xff) / 6) * -6 != 0;
    if (bVar3) {
      fVar15 = -0.0;
    }
    fVar17 = fVar17 + fVar15;
    fVar15 = 0.0;
    if (bVar3) {
      fVar15 = fVar14;
    }
  } while (uVar9 != 0x2a);
  local_e0 = 0x4270000000000000;
  ImGui_Dummy(&local_e0);
  if (*(long *)(lVar2 + 0x28) == local_b0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

