/* Entry: 0x0017882c; Ghidra function: Gui_SetExternalAsset */


void ** Gui_SetExternalAsset(void **param_1,void **param_2)

{
  undefined uVar1;
  void *pvVar2;
  void *pvVar3;
  void **ppvVar4;
  void *pvVar5;
  
  pvVar2 = *param_1;
  if (pvVar2 != (void *)0x0) {
    param_1[1] = pvVar2;
    free(pvVar2);
    *param_1 = (void *)0x0;
    param_1[1] = (void *)0x0;
    param_1[2] = (void *)0x0;
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  *param_2 = (void *)0x0;
  param_2[1] = (void *)0x0;
  param_2[2] = (void *)0x0;
  pvVar2 = param_1[3];
  if (pvVar2 != (void *)0x0) {
    param_1[4] = pvVar2;
    free(pvVar2);
    param_1[3] = (void *)0x0;
    param_1[4] = (void *)0x0;
    param_1[5] = (void *)0x0;
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_2[4] = (void *)0x0;
  param_2[5] = (void *)0x0;
  param_2[3] = (void *)0x0;
  uVar1 = *(undefined *)(param_2 + 7);
  ppvVar4 = param_1 + 8;
  pvVar2 = *ppvVar4;
  param_1[6] = param_2[6];
  *(undefined *)(param_1 + 7) = uVar1;
  if (pvVar2 != (void *)0x0) {
    pvVar5 = pvVar2;
    pvVar3 = param_1[9];
    if (param_1[9] != pvVar2) {
      do {
        pvVar5 = (void *)((long)pvVar3 + -0x20);
        if ((*(byte *)((long)pvVar3 + -0x18) & 1) != 0) {
          free(*(void **)((long)pvVar3 + -8));
        }
        pvVar3 = pvVar5;
      } while (pvVar5 != pvVar2);
      pvVar5 = *ppvVar4;
    }
    param_1[9] = pvVar2;
    free(pvVar5);
    *ppvVar4 = (void *)0x0;
    param_1[9] = (void *)0x0;
    param_1[10] = (void *)0x0;
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_2[8] = (void *)0x0;
  param_2[9] = (void *)0x0;
  param_2[10] = (void *)0x0;
  pvVar2 = param_1[0xb];
  if (pvVar2 != (void *)0x0) {
    param_1[0xc] = pvVar2;
    free(pvVar2);
    param_1[0xb] = (void *)0x0;
    param_1[0xc] = (void *)0x0;
    param_1[0xd] = (void *)0x0;
  }
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_2[0xb] = (void *)0x0;
  param_2[0xc] = (void *)0x0;
  param_2[0xd] = (void *)0x0;
  param_1[0xe] = param_2[0xe];
  return param_1;
}

