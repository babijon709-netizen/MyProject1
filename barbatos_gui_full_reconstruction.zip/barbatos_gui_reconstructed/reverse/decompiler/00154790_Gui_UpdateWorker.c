/* Entry: 0x00154790; Ghidra function: Gui_UpdateWorker */


void Gui_UpdateWorker(long param_1,uint *param_2)

{
  long lVar1;
  long lVar2;
  uint uVar3;
  undefined8 uVar4;
  
  uVar3 = *param_2;
  if (*(char *)(param_2 + 1) == '\0') {
    param_1 = param_1 + 0x570;
    *(undefined *)(param_1 + (long)(int)uVar3 * 0x170 + 4) = 0;
    *(uint *)(param_1 + (long)(int)*param_2 * 0x170) = *param_2;
    *(undefined8 *)(param_1 + (long)(int)*param_2 * 0x170 + 8) = 0xffffffffffffffff;
    *(undefined8 *)(param_1 + (long)(int)*param_2 * 0x170 + 0x158) = 0;
    *(undefined *)(param_1 + (long)(int)*param_2 * 0x170 + 0x50) = 0;
    *(undefined *)(param_1 + (long)(int)*param_2 * 0x170 + 0xd0) = 0;
    *(undefined *)(param_1 + (long)(int)*param_2 * 0x170 + 5) = 0;
    *param_2 = 0xffffffff;
    *(undefined8 *)(param_2 + 2) = 0xffffffffffffffff;
  }
  else {
    if (uVar3 == 0xffffffff) {
      uVar3 = (uint)*(byte *)(param_1 + 0x574);
      if (uVar3 != 0) {
        if (*(char *)(param_1 + 0x6e4) == '\0') {
          uVar3 = 1;
        }
        else if (*(char *)(param_1 + 0x854) == '\0') {
          uVar3 = 2;
        }
        else if (*(char *)(param_1 + 0x9c4) == '\0') {
          uVar3 = 3;
        }
        else if (*(char *)(param_1 + 0xb34) == '\0') {
          uVar3 = 4;
        }
        else {
          uVar3 = 5;
          if (*(char *)(param_1 + 0xca4) != '\0') {
            uVar3 = 0xffffffff;
          }
        }
      }
      *param_2 = uVar3;
    }
    lVar1 = param_1 + 0x570;
    *(char *)(lVar1 + (long)(int)uVar3 * 0x170 + 4) = *(char *)(param_2 + 1);
    __strcpy_chk(lVar1 + (long)(int)*param_2 * 0x170 + 0x50,param_2 + 0x14,0x80);
    __strcpy_chk(lVar1 + (long)(int)*param_2 * 0x170 + 0xd0,param_2 + 0x34,0x80);
    *(uint *)(lVar1 + (long)(int)*param_2 * 0x170) = *param_2;
    uVar4 = *(undefined8 *)(param_2 + 0x58);
    lVar2 = lVar1 + (long)(int)*param_2 * 0x170;
    *(undefined8 *)(lVar2 + 0x168) = *(undefined8 *)(param_2 + 0x5a);
    *(undefined8 *)(lVar2 + 0x160) = uVar4;
    *(undefined *)(lVar1 + (long)(int)*param_2 * 0x170 + 5) = *(undefined *)((long)param_2 + 5);
    if (*(long *)(param_2 + 0x56) != 0) {
      *(long *)(param_1 + (long)(int)*param_2 * 0x170 + 0x6c8) = *(long *)(param_2 + 0x56);
    }
    if (*(long *)(param_2 + 2) == -1) {
      time((time_t *)(param_2 + 2));
      *(undefined8 *)(param_1 + (long)(int)*param_2 * 0x170 + 0x578) = *(undefined8 *)(param_2 + 2);
    }
  }
  return;
}

