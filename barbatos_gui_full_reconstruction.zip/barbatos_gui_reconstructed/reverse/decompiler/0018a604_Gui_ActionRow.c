/* Entry: 0x0018a604; Ghidra function: Gui_ActionRow */


byte Gui_ActionRow(undefined8 param_1,float param_2,undefined8 param_3,long param_4,char *param_5)

{
  long lVar1;
  byte bVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  ulong uVar5;
  long lVar6;
  undefined8 *puVar7;
  float *pfVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  undefined8 local_90;
  undefined8 uStack136;
  float local_78;
  float fStack116;
  float local_70;
  float fStack108;
  long local_68;
  
  puVar7 = &local_90;
  lVar1 = cRead_8(tpidr_el0);
  local_68 = *(long *)(lVar1 + 0x28);
  uVar4 = ImGui_GetWindowDrawList();
  fVar9 = (float)ImGui_GetCursorScreenPos();
  fVar10 = (float)ImGui_GetWindowPos();
  if (param_5 == (char *)0x0) {
    local_70 = fVar9 + fVar10 + -20.0;
    fStack108 = param_2 + *(float *)(param_4 + 4);
    local_90 = CONCAT44(param_2,fVar9 + 20.0);
    fVar11 = fStack108;
    uVar3 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
    ImDrawList_AddRectFilled(0x41400000,uVar4,&local_90,&local_70,uVar3,0);
    ImGui_CalcTextSize(0x42180000,0,param_3);
    local_70 = fVar9 + 45.0;
    fStack108 = ((param_2 + *(float *)(param_4 + 4) * 0.5) - fVar11 * 0.5) + -1.0;
    uStack136 = 0x3f8000003df0f0f2;
    local_90 = 0x3df0f0f23df0f0f2;
    uVar3 = ImGui_ColorConvertFloat4ToU32(&local_90);
    ImDrawList_AddText(0x42180000,uVar4,0,&local_70,uVar3,param_3,0,0);
    local_90 = CONCAT44(param_2,fVar9 + 20.0);
    ImGui_SetCursorScreenPos(&local_90);
    local_90 = CONCAT44(*(undefined4 *)(param_4 + 4),fVar10 + -40.0);
    bVar2 = ImGui_Button(param_3,&local_90,0);
    bVar2 = bVar2 & DAT_0050e634 == '\0';
  }
  else {
    if (*param_5 == '\0') {
      local_70 = fVar9 + fVar10 + -20.0;
      fStack108 = param_2 + *(float *)(param_4 + 4);
      local_90 = CONCAT44(param_2,fVar9 + 20.0);
      fVar11 = fStack108;
      uVar3 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
      pfVar8 = &local_70;
    }
    else {
      local_70 = fVar9 + 20.0;
      local_78 = fVar9 + fVar10 + -20.0;
      fStack116 = param_2 + *(float *)(param_4 + 4);
      uStack136 = 0x3f8000003f52d2d4;
      local_90 = 0x3f52d2d43f52d2d4;
      fStack108 = param_2;
      fVar11 = fStack116;
      uVar3 = ImGui_ColorConvertFloat4ToU32(&local_90);
      puVar7 = (undefined8 *)&local_70;
      pfVar8 = &local_78;
    }
    ImDrawList_AddRectFilled(0x41400000,uVar4,puVar7,pfVar8,uVar3,0);
    ImGui_CalcTextSize(0x42180000,0,param_3);
    local_70 = fVar9 + 45.0;
    fStack108 = ((param_2 + *(float *)(param_4 + 4) * 0.5) - fVar11 * 0.5) + -1.0;
    uStack136 = 0x3f8000003df0f0f2;
    local_90 = 0x3df0f0f23df0f0f2;
    uVar3 = ImGui_ColorConvertFloat4ToU32(&local_90);
    ImDrawList_AddText(0x42180000,uVar4,0,&local_70,uVar3,param_3,0,0);
    local_90 = CONCAT44(param_2,fVar9 + 20.0);
    ImGui_SetCursorScreenPos(&local_90);
    local_90 = CONCAT44(*(undefined4 *)(param_4 + 4),fVar10 + -40.0);
    uVar5 = ImGui_Button(param_3,&local_90,0);
    if (((uVar5 & 1) != 0) && (DAT_0050e634 == '\0')) {
      *param_5 = '\x01';
      uVar4 = FUN_0034a23c();
      *(undefined8 *)(param_5 + 8) = uVar4;
    }
    if (*param_5 != '\0') {
      lVar6 = FUN_0034a23c();
      if (280.0 <= (double)((lVar6 - *(long *)(param_5 + 8)) / 1000) / 1000.0) {
        bVar2 = 1;
        *(undefined4 *)(param_5 + 4) = 0;
        *param_5 = '\0';
        goto LAB_0028a95c;
      }
    }
    bVar2 = 0;
  }
LAB_0028a95c:
  local_90 = CONCAT44(param_2 + *(float *)(param_4 + 4) + 20.0,fVar9);
  ImGui_SetCursorScreenPos(&local_90);
  if (*(long *)(lVar1 + 0x28) == local_68) {
    return bVar2;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

