/* Entry: 0x0018d4c4; Ghidra function: Gui_OverlayAnimation */


float Gui_OverlayAnimation(ulong param_1)

{
  byte bVar1;
  int iVar2;
  long lVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  if (((DAT_0050e5a0 & 1) == 0) && (iVar2 = FUN_0036eb48(&DAT_0050e5a0), iVar2 != 0)) {
    DAT_0050e59c = 0;
    DAT_0050e594 = 0.0;
    DAT_0050e598 = 0.12;
    FUN_0036eca0(&DAT_0050e5a0);
  }
  if ((((param_1 & 1) == 0) &&
      (((DAT_0050e5b4 & 1) != 0 ||
       ((((fVar6 = (float)ImGui_GetScrollY(), fVar6 <= 0.0 && (DAT_0050e637 != '\0')) &&
         (DAT_0050e64c < DAT_0050e640._4_4_)) && ((DAT_0050e638 != '\0' && (DAT_0050e639 != '\0'))))
       )))) || (DAT_0050e5b4 == 1)) {
    DAT_0050e5b4 = 1;
    bVar1 = 0;
    fVar6 = DAT_0050e5a8 * (ABS(DAT_0050e5b0) / 3.0);
  }
  else {
    fVar6 = 0.0;
    bVar1 = 1;
  }
  if (((param_1 & 1) == 0) && ((DAT_0050e59c & 1) == 0)) {
    if (((bool)(bVar1 | DAT_0050e630 == '\0')) ||
       (((DAT_0050e637 == '\0' || (DAT_0050e638 == '\0')) || (DAT_0050e639 == '\0'))))
    goto LAB_0028d620;
    DAT_0050e59c = 1;
    DAT_0050e5a8 = 1.0;
    DAT_0050e594 = 1.0;
    DAT_0050e5ac = DAT_0050e640._4_4_;
  }
  if (((((param_1 & 1) == 0) && (DAT_0050e59c != 0)) &&
      ((!(bool)(bVar1 | DAT_0050e630 == '\0') && ((DAT_0050e637 != '\0' && (DAT_0050e638 != '\0'))))
      )) && (DAT_0050e639 != '\0')) {
    if (DAT_0050e5ac - DAT_0050e640._4_4_ <= 0.0) {
      DAT_0050e5b0 = DAT_0050e5ac - DAT_0050e640._4_4_;
      return fVar6;
    }
    return fVar6;
  }
LAB_0028d620:
  fVar4 = DAT_0050e594;
  if (DAT_0050e630 == '\0') {
    DAT_0050e59c = 0;
    lVar3 = ImGui_GetIO();
    fVar4 = (float)NEON_fmadd(*(float *)(lVar3 + 0x10) / DAT_0050e598,0.0 - DAT_0050e594,fVar4);
    fVar5 = (float)NEON_fmin(fVar4,0x3f800000);
    DAT_0050e594 = 0.0;
    if (0.0 <= fVar4) {
      DAT_0050e594 = fVar5;
    }
    DAT_0050e5a8 = DAT_0050e594;
    if (DAT_0050e594 < 0.001) {
      DAT_0050e5b4 = 0;
    }
  }
  return fVar6;
}

