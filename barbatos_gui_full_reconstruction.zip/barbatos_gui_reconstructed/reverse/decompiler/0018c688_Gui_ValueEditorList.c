/* Entry: 0x0018c688; Ghidra function: Gui_ValueEditorList */


void Gui_ValueEditorList(undefined8 param_1,float param_2,char *param_3,long param_4,ulong param_5,
                        long param_6,long param_7)

{
  long lVar1;
  undefined8 *puVar2;
  void *pvVar3;
  long lVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  undefined8 extraout_x1;
  char *__s2;
  long lVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  ulong uVar12;
  float local_e8;
  float fStack228;
  void *local_d8;
  float local_d0;
  float fStack204;
  float local_c8;
  float fStack196;
  undefined8 local_c0;
  undefined8 uStack184;
  long local_a0;
  
  lVar4 = cRead_8(tpidr_el0);
  local_a0 = *(long *)(lVar4 + 0x28);
  uVar7 = ImGui_GetWindowDrawList();
  fVar9 = (float)ImGui_GetCursorScreenPos();
  fVar11 = param_2;
  local_c8 = fVar9;
  fStack196 = param_2;
  fVar10 = (float)ImGui_GetWindowPos();
  if (param_4 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_4);
    local_e8 = 0.0;
    if (param_6 != 0) {
      local_e8 = 55.0;
    }
    local_e8 = local_e8 + fVar9 + 50.0;
    uStack184 = 0x3f8000003df0f0f2;
    local_c0 = 0x3df0f0f23df0f0f2;
    fStack228 = param_2;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_c0);
    ImDrawList_AddText(0x421c0000,uVar7,0,&local_e8,uVar5,param_4,0,0);
    if (param_6 == 0) {
      fVar9 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar9 + 70.0,fVar11 * 0.5 + param_2 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_6);
      fVar9 = 10.0;
    }
    fStack196 = param_2 + fVar11 + fVar9;
    ImGui_SetCursorScreenPos(&local_c8);
    fVar9 = local_c8;
    param_2 = fStack196;
  }
  iVar6 = (int)(param_5 & 0xffffffff);
  local_e8 = fVar10 + fVar9 + -20.0;
  fStack228 = param_2 + (float)(iVar6 * 0x51) + (float)(iVar6 * 10) + 10.0;
  local_c0 = CONCAT44(param_2,fVar9 + 20.0);
  uVar5 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar7,&local_c0,&local_e8,uVar5,0);
  fVar9 = (float)ImGui_GetWindowPos();
  uVar12 = 0xc2a00000;
  ImGui_SetNextItemWidth(fVar9 + -80.0);
  fVar9 = (float)uVar12;
  if (0 < iVar6) {
    lVar8 = 0;
    do {
      fVar9 = (float)uVar12;
      local_c8 = (float)ImGui_GetCursorScreenPos();
      fStack196 = fVar9;
      if (lVar8 != 0) {
        fStack228 = fVar9 + 5.0;
        local_e8 = local_c8 + 40.0;
        local_d0 = fVar10 + local_c8 + -20.0;
        uStack184 = 0x3f8000003ec8c8ca;
        local_c0 = 0x3ec8c8ca3ec8c8ca;
        fStack204 = fStack228;
        uVar5 = ImGui_ColorConvertFloat4ToU32(&local_c0);
        ImDrawList_AddLine(0x40000000,uVar7,&local_e8,&local_d0,uVar5);
      }
      local_c0 = CONCAT44(fStack196 + 10.0,local_c8 + 40.0);
      ImGui_SetCursorScreenPos(&local_c0);
      puVar2 = (undefined8 *)(param_7 + lVar8);
      uVar12 = (ulong)*(uint *)((long)puVar2 + 0x14);
      ImGui_SliderScalar(*(undefined4 *)(puVar2 + 2),param_3,*puVar2,puVar2[1],puVar2[3],1);
      if ((*param_3 != '\0') &&
         ((__s2 = *(char **)(param_7 + lVar8),
          (s_Bnull_004d3e87._1_4_ ^ 0x6c6c756e | (uint)(byte)s_Bnull_004d3e87[5]) == 0 ||
          (iVar6 = strcmp(s_Bnull_004d3e87 + 1,__s2), iVar6 == 0)))) {
        __strcpy_chk(DAT_00500b38 + 0x50,__s2,0x80);
        FUN_0028c5e4((double)*(float *)puVar2[1],&local_c0,extraout_x1,puVar2[3]);
        __strcpy_chk(DAT_00500b38 + 0xd0,&local_c0,0x80);
        __strcpy_chk(s_Bnull_004d3e87 + 1,*(undefined8 *)(param_7 + lVar8),0x80);
        lVar1 = DAT_00500b38 + 0x30;
        FUN_0036d0b0(*(undefined4 *)((long)puVar2 + 0x14));
        pvVar3 = (void *)((ulong)&local_e8 | 1);
        if (((uint)local_e8 & 1) != 0) {
          pvVar3 = local_d8;
        }
        __strcpy_chk(lVar1,pvVar3,0x20);
        if (((uint)local_e8 & 1) != 0) {
          free(local_d8);
        }
        lVar1 = DAT_00500b38 + 0x10;
        FUN_0036d0b0(*(undefined4 *)(puVar2 + 2));
        pvVar3 = (void *)((ulong)&local_e8 | 1);
        if (((uint)local_e8 & 1) != 0) {
          pvVar3 = local_d8;
        }
        __strcpy_chk(lVar1,pvVar3,0x20);
        if (((uint)local_e8 & 1) != 0) {
          free(local_d8);
        }
      }
      fVar9 = (float)uVar12;
      lVar8 = lVar8 + 0x20;
    } while ((param_5 & 0xffffffff) * 0x20 - lVar8 != 0);
  }
  *(char *)(DAT_00500b38 + 4) = *param_3;
  if (*param_3 == '\0') {
    s_Bnull_004d3e87[5] = '\0';
    s_Bnull_004d3e87._1_4_ = 0x6c6c756e;
  }
  local_c8 = (float)ImGui_GetCursorScreenPos();
  local_c0 = CONCAT44(fVar9 + 30.0,local_c8);
  fStack196 = fVar9;
  ImGui_SetCursorScreenPos(&local_c0);
  if (*(long *)(lVar4 + 0x28) != local_a0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

