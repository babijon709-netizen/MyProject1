/* Entry: 0x00154964; Ghidra function: Gui_UpdateCleanup */


void Gui_UpdateCleanup(pthread_t *param_1,undefined8 param_2)

{
  long lVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 *__arg;
  long lVar4;
  
  lVar1 = cRead_8(tpidr_el0);
  lVar4 = *(long *)(lVar1 + 0x28);
  uVar3 = FUN_0036b114(8);
                    /* try { // try from 00254998 to 0025499b has its CatchHandler @ 00254a08 */
  FUN_0036e56c();
                    /* try { // try from 002549a0 to 002549a7 has its CatchHandler @ 00254a00 */
  __arg = (undefined8 *)FUN_0036b114(0x10);
  *__arg = uVar3;
  __arg[1] = param_2;
                    /* try { // try from 002549b4 to 002549fb has its CatchHandler @ 00254a1c */
  iVar2 = pthread_create(param_1,(pthread_attr_t *)0x0,FUN_00276650,__arg);
  if (iVar2 != 0) {
                    /* WARNING: Subroutine does not return */
    FUN_0036e0f8(iVar2,"thread constructor failed");
  }
  if (*(long *)(lVar1 + 0x28) == lVar4) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

