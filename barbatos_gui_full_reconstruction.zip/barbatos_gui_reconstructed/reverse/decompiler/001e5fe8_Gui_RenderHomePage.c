/* Entry: 0x001e5fe8; Ghidra function: Gui_RenderHomePage */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_RenderHomePage(undefined8 param_1,float param_2)

{
  long lVar1;
  undefined *puVar2;
  undefined *puVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined auVar7 [16];
  undefined8 *local_70;
  undefined8 *puStack104;
  undefined8 *puStack96;
  float local_58;
  float fStack84;
  float local_50;
  float fStack76;
  long local_48;
  
  lVar1 = cRead_8(tpidr_el0);
  local_48 = *(long *)(lVar1 + 0x28);
  local_70 = (undefined8 *)0x0;
  fStack76 = param_2;
  ImGui_BeginChild("##Homeright",&local_70,0,0x80000c);
  uVar6 = ImGui_GetWindowDrawList();
  local_50 = (float)ImGui_GetWindowSize();
  fStack84 = fStack76;
  local_58 = (float)ImGui_GetWindowPos();
  ImGui_GetCursorScreenPos();
  local_58 = local_50 + local_58;
  fStack84 = fStack76 + fStack84;
  auVar7 = NEON_fmov(0x3f800000,4);
  puStack104 = SUB168(auVar7 >> 0x40,0);
  local_70 = SUB168(auVar7,0);
  uVar5 = ImGui_ColorConvertFloat4ToU32(local_58,fStack84,local_70,&local_70);
  ImDrawList_AddRectFilled(DAT_00395168,uVar6,&local_50,&local_58,uVar5,0xa0);
  local_70 = (undefined8 *)FUN_0036b114(0x30);
  auVar7 = _PTR_DAT_0038c538;
  puVar4 = PTR_DAT_0038c530;
  puVar3 = PTR_DAT_0038c528;
  puVar2 = PTR_DAT_0038c518;
  puStack104 = local_70 + 6;
  local_70[1] = PTR_DAT_0038c520;
  *local_70 = puVar2;
  local_70[3] = puVar4;
  local_70[2] = puVar3;
  local_70[5] = SUB168(auVar7 >> 0x40,0);
  local_70[4] = SUB168(auVar7,0);
  puStack96 = puStack104;
                    /* try { // try from 002e60c0 to 002e60d3 has its CatchHandler @ 002e6110 */
  Gui_HomeNotices(0x42a00000,&local_70);
  ImGui_EndChild();
  if (local_70 != (undefined8 *)0x0) {
    puStack104 = local_70;
    free(local_70);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

