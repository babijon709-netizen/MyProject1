/* Entry: 0x001793b8; Ghidra function: Gui_RenderImageLayer */


/* WARNING: Could not reconcile some variable overlaps */

undefined4
Gui_RenderImageLayer
          (undefined8 param_1,float *param_2,float *param_3,int param_4,undefined4 param_5)

{
  float *pfVar1;
  uint uVar2;
  long lVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  long lVar6;
  undefined8 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  float fVar12;
  float fVar13;
  char *local_d0;
  char *local_c8;
  undefined4 local_c0;
  undefined4 local_bc;
  undefined4 local_b8;
  undefined4 local_b4;
  char *local_b0;
  undefined8 uStack168;
  undefined8 uStack160;
  undefined8 uStack152;
  undefined auStack136 [12];
  int local_7c;
  undefined4 local_78;
  undefined4 uStack116;
  undefined4 local_70;
  undefined4 uStack108;
  long local_68;
  
  lVar3 = cRead_8(tpidr_el0);
  local_68 = *(long *)(lVar3 + 0x28);
  if (((DAT_0050db30 & 1) == 0) && (iVar8 = FUN_0036eb48(&DAT_0050db30), iVar8 != 0)) {
    __cxa_atexit(FUN_00284ff4,&DAT_0050db00,&DAT_004d7920);
    FUN_0036eca0(&DAT_0050db30);
  }
  glGetIntegerv(0x8ca6,&local_b4);
  glGetIntegerv(0xba2,&local_78);
  lVar6 = FUN_002a341c(param_1);
  pfVar1 = param_2 + 1;
  if (*param_2 + param_2[1] == 0.0) {
    pfVar1 = (float *)(lVar6 + 0x14);
    param_2 = (float *)(lVar6 + 0x10);
  }
  fVar12 = *pfVar1;
  pfVar1 = param_3 + 1;
  if (*param_3 + param_3[1] == 0.0) {
    param_3 = (float *)(lVar6 + 0x18);
    pfVar1 = (float *)(lVar6 + 0x1c);
  }
  fVar13 = *param_2;
  iVar8 = (int)*pfVar1;
  iVar9 = (int)*param_3;
  glGetIntegerv(0xba2,auStack136);
  if (DAT_0050db00 == 0) {
    glGenBuffers(1,&DAT_0050db00);
  }
  uVar2 = iVar8 * iVar9 * 4;
  if (DAT_0050db04 < uVar2) {
    DAT_0050db04 = uVar2;
    glBindBuffer(0x88eb,DAT_0050db00);
    glBufferData(0x88eb,(long)(int)DAT_0050db04,0,0x88e1);
    glBindBuffer(0x88eb,0);
  }
  glBindBuffer(0x88eb,DAT_0050db00);
  glReadPixels((int)fVar13,local_7c - (iVar8 + (int)fVar12),iVar9,iVar8,0x1908,0x1401,0);
  uVar7 = glFenceSync(0x9117,0);
  glClientWaitSync(uVar7,0,0xffffffffffffffff);
  glDeleteSync(uVar7);
  glGenTextures(1,&local_b8);
  glBindTexture(0xde1,local_b8);
  glTexImage2D(0xde1,0,0x1908,iVar9,iVar8,0,0x1908,0x1401,0);
  glTexParameteri(0xde1,0x2801,0x2600);
  glTexParameteri(0xde1,0x2800,0x2600);
  glBindBuffer(0x88ec,DAT_0050db00);
  glTexSubImage2D(0xde1,0,0,0,iVar9,iVar8,0x1908,0x1401,0);
  glBindBuffer(0x88eb,0);
  glBindBuffer(0x88ec,0);
  glGenFramebuffers(1,&local_bc);
  glGenTextures(1,&local_c0);
  glBindTexture(0xde1,local_c0);
  glTexImage2D(0xde1,0,0x1908,iVar9,iVar8,0,0x1908,0x1401,0);
  glTexParameteri(0xde1,0x2801,0x2601);
  glTexParameteri(0xde1,0x2800,0x2601);
  glTexParameteri(0xde1,0x2802,0x812f);
  glTexParameteri(0xde1,0x2803,0x812f);
  if (DAT_0050db08 == 0) {
    glGenFramebuffers(1,&DAT_0050db08);
    glGenVertexArrays(1,&DAT_0050db18);
    glBindVertexArray(DAT_0050db18);
    glGenBuffers(1,&DAT_0050db1c);
    uStack168 = 0xbf8000003f800000;
    local_b0 = (char *)0xbf800000bf800000;
    uStack152 = 0x3f8000003f800000;
    uStack160 = 0x3f800000bf800000;
    glBindBuffer(0x8892,DAT_0050db1c);
    glBufferData(0x8892,0x20,&local_b0,0x88e4);
    local_d0 = 
    "\n            precision mediump float;\n            uniform sampler2D tex;\n            varying vec2 uv;\n            void main() {\n                gl_FragColor = texture2D(tex, uv);\n            }"
    ;
    local_c8 = 
    "\n            attribute vec2 position;\n            varying vec2 uv;\n            void main() {\n                gl_Position = vec4(position, 0, 1);\n                uv = vec2(position.x * 0.5 + 0.5, 1.0 - (position.y * 0.5 + 0.5));\n            }"
    ;
    uVar4 = glCreateShader(0x8b31);
    uVar5 = glCreateShader(0x8b30);
    glShaderSource(uVar4,1,&local_c8,0);
    glShaderSource(uVar5,1,&local_d0,0);
    glCompileShader(uVar4);
    glCompileShader(uVar5);
    uVar7 = glCreateProgram();
    DAT_0050db0c = (undefined4)uVar7;
    glAttachShader(uVar7,uVar4);
    glAttachShader(DAT_0050db0c,uVar5);
    glLinkProgram(DAT_0050db0c);
    glDeleteShader(uVar4);
    glDeleteShader(uVar5);
    uVar4 = glGetAttribLocation(DAT_0050db0c,"position");
    glEnableVertexAttribArray();
    glVertexAttribPointer(uVar4,2,0x1406,0,0,0);
    glBindVertexArray(0);
  }
  glBindFramebuffer(0x8d40,local_bc);
  glFramebufferTexture2D(0x8d40,0x8ce0,0xde1,local_c0,0);
  glViewport(0,0,iVar9,iVar8);
  glUseProgram(DAT_0050db0c);
  glActiveTexture(0x84c0);
  glBindTexture(0xde1,local_b8);
  uVar7 = glGetUniformLocation(DAT_0050db0c,&DAT_0011b524);
  glUniform1i(uVar7,0);
  glBindVertexArray(DAT_0050db18);
  glDrawArrays(5,0,4);
  glDeleteFramebuffers(1,&local_bc);
  glDeleteTextures(1,&local_b8);
  if (param_4 < 2) {
    iVar10 = 0;
    if (param_4 != 0) {
      iVar10 = iVar9 / param_4;
    }
    iVar11 = 0;
    if (param_4 != 0) {
      iVar11 = iVar8 / param_4;
    }
  }
  else {
    iVar10 = 0;
    if (param_4 != 0) {
      iVar10 = iVar9 / param_4;
    }
    iVar11 = 0;
    if (param_4 != 0) {
      iVar11 = iVar8 / param_4;
    }
    glGenTextures(1,&local_d0);
    glBindTexture(0xde1,(ulong)local_d0 & 0xffffffff);
    glTexImage2D(0xde1,0,0x1908,iVar10,iVar11,0,0x1908,0x1401,0);
    glTexParameteri(0xde1,0x2801,0x2601);
    glTexParameteri(0xde1,0x2800,0x2601);
    glTexParameteri(0xde1,0x2802,0x812f);
    glTexParameteri(0xde1,0x2803,0x812f);
    if (DAT_0050db14 == 0) {
      local_b0 = 
      "\n                #version 300 es\n                in vec2 position;\n                out vec2 uv;\n                void main() {\n                    gl_Position = vec4(position, 0, 1);\n                    uv = vec2(position.x * 0.5 + 0.5, position.y * 0.5 + 0.5);\n                }"
      ;
      local_c8 = 
      "\n                #version 300 es\n                precision mediump float;\n                uniform sampler2D tex;\n                uniform vec2 texSize;\n                uniform int scaleFactor;\n                in vec2 uv;\n                out vec4 fragColor;\n                \n                void main() {\n                    vec2 pixelCoord = uv * texSize;\n                    vec2 blockStart = floor(pixelCoord / float(scaleFactor)) * float(scaleFactor);\n                    vec2 stepUV = 1.0 / texSize;\n                    \n                    vec4 sum = vec4(0);\n                    for (int y = 0; y < 8; y++) {\n                        for (int x = 0; x < 8; x++) {\n                            if (y >= scaleFactor || x >= scaleFactor) break;\n                            vec2 sampleUV = (blockStart + vec2(x, y)) * stepUV;\n                            sum += texture(tex, sampleUV);\n                        }\n                    }\n                    fragColor = sum / float(scaleFactor * scaleFactor);\n                }"
      ;
      uVar4 = glCreateShader(0x8b31);
      uVar5 = glCreateShader(0x8b30);
      glShaderSource(uVar4,1,&local_b0,0);
      glShaderSource(uVar5,1,&local_c8,0);
      glCompileShader(uVar4);
      glCompileShader(uVar5);
      uVar7 = glCreateProgram();
      DAT_0050db14 = (int)uVar7;
      glAttachShader(uVar7,uVar4);
      glAttachShader(DAT_0050db14,uVar5);
      glLinkProgram(DAT_0050db14);
      glDeleteShader(uVar4);
      glDeleteShader(uVar5);
    }
    if (DAT_0050db10 == 0) {
      glGenFramebuffers(1,&DAT_0050db10);
    }
    glBindFramebuffer(0x8d40,DAT_0050db10);
    glFramebufferTexture2D(0x8d40,0x8ce0,0xde1,(ulong)local_d0 & 0xffffffff,0);
    glViewport(0,0,iVar10,iVar11);
    glUseProgram(DAT_0050db14);
    glActiveTexture(0x84c0);
    glBindTexture(0xde1,local_c0);
    uVar7 = glGetUniformLocation(DAT_0050db14,&DAT_0011b524);
    glUniform1i(uVar7,0);
    glGetUniformLocation(DAT_0050db14,"texSize");
    glUniform2f((float)iVar9,(float)iVar8);
    uVar7 = glGetUniformLocation(DAT_0050db14,"scaleFactor");
    glUniform1i(uVar7,param_4);
    glBindVertexArray(DAT_0050db18);
    glDrawArrays(5,0,4);
    glDeleteTextures(1,&local_c0);
    local_c0 = local_d0._0_4_;
  }
  uVar4 = FUN_00279b64(&DAT_0050db00,local_c0,iVar10,iVar11,param_5);
  glBindFramebuffer(0x8d40,local_b4);
  glViewport(local_78,uStack116,local_70,uStack108);
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return uVar4;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

