/* Entry: 0x001e6130; Ghidra function: Gui_CustomItemRowCore */


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Could not reconcile some variable overlaps */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte Gui_CustomItemRowCore
               (float param_1,float param_2,char *param_3,byte *param_4,int *param_5,int param_6,
               undefined4 *param_7,undefined8 param_8)

{
  long lVar1;
  char cVar2;
  char cVar3;
  byte bVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  ulong uVar7;
  long lVar8;
  size_t __n;
  ulong *puVar9;
  ulong *puVar10;
  void *pvVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined4 uVar16;
  undefined auVar17 [16];
  float fVar18;
  float fVar19;
  float fVar20;
  undefined8 local_108;
  undefined8 local_100;
  ulong local_f8;
  void *local_f0;
  ulong local_e8;
  size_t local_e0;
  void *local_d8;
  ulong local_d0;
  ulong uStack200;
  void *local_c0;
  long local_b0;
  
  lVar1 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar1 + 0x28);
  fVar15 = param_2;
  fVar12 = (float)ImGui_GetCursorScreenPos();
  fVar13 = (float)ImGui_GetWindowPos();
  uVar6 = ImGui_GetWindowDrawList();
  ImGui_SetCursorPosX(0x41a00000);
  fVar18 = fVar12 + fVar13;
  fVar20 = fVar18 + -45.0;
  local_d0 = CONCAT44(fVar15,fVar20 - param_1);
  ImGui_SetCursorScreenPos(&local_d0);
  local_d0 = CONCAT44(param_2,param_1);
  uVar7 = ImGui_Button(param_3,&local_d0,0);
  if ((((uVar7 & 1) != 0) && (param_4 != (byte *)0x0)) && (DAT_0050e634 == '\0')) {
    bVar4 = *param_4;
    *param_4 = bVar4 ^ 1;
    if (param_7 != (undefined4 *)0x0) {
      *(byte *)((long)param_7 + 0xd) = bVar4 ^ 1;
    }
  }
  fVar19 = param_2 * 0.5;
  bVar4 = FUN_002a26dc();
  cVar3 = DAT_0050e634;
  cVar2 = DAT_0050e632;
  param_2 = param_2 + fVar15;
  if ((param_4 == (byte *)0x0) || (*param_4 == 0)) {
    local_100._4_4_ = param_2 + -8.0;
    local_e8 = CONCAT44(fVar15 + 8.0,(fVar18 - param_1) + -45.0);
    uStack200 = 0x3f8000003f43c3c5;
    local_d0 = 0x3f43c3c53f43c3c5;
    local_100._0_4_ = fVar20;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    puVar9 = &local_e8;
    puVar10 = &local_100;
  }
  else {
    local_d0 = CONCAT44(fVar15 + 8.0,(fVar18 - param_1) + -45.0);
    local_e8 = CONCAT44(param_2 + -8.0,fVar20);
    uVar5 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4e0);
    puVar9 = &local_d0;
    puVar10 = &local_e8;
  }
  ImDrawList_AddRectFilled(0x42480000,uVar6,puVar9,puVar10,uVar5,0);
  uVar5 = param_7[1];
  fVar20 = -8.0;
  fVar14 = 0.0;
  if (*param_4 != 0) {
    fVar20 = 0.0;
  }
  if (*(char *)((long)param_7 + 0xd) != '\0') {
    fVar14 = 1.0;
  }
  lVar8 = ImGui_GetIO();
  if (*(char *)(param_7 + 3) == '\0') {
    *(undefined *)(param_7 + 3) = 1;
    uVar5 = *param_7;
  }
  else {
    fVar14 = (float)NEON_fmadd(*(float *)(lVar8 + 0x10) / (float)param_7[2],
                               fVar14 - (float)param_7[1],uVar5);
    uVar16 = NEON_fmin(fVar14,0x3f800000);
    uVar5 = 0;
    if (0.0 <= fVar14) {
      uVar5 = uVar16;
    }
  }
  param_7[1] = uVar5;
  uVar16 = NEON_fmadd(fVar19,0xc0000000,param_1 + 8.0);
  fVar13 = (float)NEON_fmadd(uVar5,uVar16,fVar19 + fVar12 + (fVar13 - param_1) + -45.0 + fVar20);
  fVar20 = fVar19 + fVar15;
  auVar17 = NEON_fmov(0x3f800000,4);
  local_e8 = CONCAT44(fVar20,fVar13);
  uStack200 = SUB168(auVar17 >> 0x40,0);
  local_d0 = SUB168(auVar17,0);
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_d0);
  ImDrawList_AddCircle(fVar19 + -8.0 + -5.0,uVar6,&local_e8,uVar5,0);
  if (param_6 == 0x378) {
    ImGui_CalcTextSize(_DAT_004d3e84,0,param_3);
    local_e8 = CONCAT44(fVar20 + fVar13 * -0.5 + -1.0,fVar12 + 45.0);
  }
  else {
    fVar13 = fVar12 + 45.0 + 12.0;
    local_d0 = CONCAT44(fVar20,fVar13);
    uVar5 = ImGui_ColorConvertFloat4ToU32(&DAT_004f2294 + (long)param_6 * 0x10);
    ImDrawList_AddCircle(0x4159999a,uVar6,&local_d0,uVar5,0);
    local_e8 = CONCAT44(fVar20,fVar13);
    uStack200 = 0x3f8000003eb33333;
    local_d0 = 0x3eb333333eb33333;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    fVar13 = 4.0;
    FUN_002aec5c(0x415ef369,uVar6,&local_e8,uVar5,0);
    ImGui_CalcTextSize(_DAT_004d3e84,0,param_3);
    local_e8 = CONCAT44(fVar20 + fVar13 * -0.5 + -1.0,fVar12 + 45.0 + 45.0);
  }
  uVar5 = _DAT_004d3e84;
  uStack200 = 0x3f8000003df0f0f2;
  local_d0 = 0x3df0f0f23df0f0f2;
  uVar16 = ImGui_ColorConvertFloat4ToU32(&local_d0);
  ImDrawList_AddText(uVar5,0,uVar6,0,&local_e8,uVar16,param_3,0,0);
  Gui_DrawTexture(fVar18 + -170.0,fVar15 + 31.5,0x41e00000,0x3f800000,param_8);
  local_d0 = CONCAT44(fVar15 + 31.5 + -33.0,fVar18 + -170.0 + -40.0);
  ImGui_SetCursorScreenPos(&local_d0);
  __n = strlen(param_3);
  if (0xffffffffffffffef < __n) {
                    /* WARNING: Subroutine does not return */
    FUN_0036b804(&local_e8);
  }
  if (__n < 0x17) {
    pvVar11 = (void *)((ulong)&local_e8 | 1);
    local_e8 = local_e8 & 0xffffffffffffff00 | (ulong)(byte)((int)__n << 1);
    if (__n == 0) goto LAB_002e65f0;
  }
  else {
    uVar7 = __n + 0x10 & 0xfffffffffffffff0;
    pvVar11 = (void *)FUN_0036b114(uVar7);
    local_e8 = uVar7 | 1;
    local_e0 = __n;
    local_d8 = pvVar11;
  }
  memcpy(pvVar11,param_3,__n);
LAB_002e65f0:
  *(undefined *)((long)pvVar11 + __n) = 0;
                    /* try { // try from 002e65f4 to 002e6603 has its CatchHandler @ 002e67a8 */
  FUN_0036ce38(param_6);
  uVar7 = (ulong)((byte)local_100 >> 1);
  pvVar11 = (void *)((ulong)&local_100 | 1);
  if (((uint)(float)local_100 & 1) != 0) {
    uVar7 = local_f8;
    pvVar11 = local_f0;
  }
                    /* try { // try from 002e6620 to 002e6627 has its CatchHandler @ 002e6788 */
  puVar9 = (ulong *)FUN_0036bca0(&local_e8,pvVar11,uVar7);
  local_c0 = (void *)puVar9[2];
  uStack200 = puVar9[1];
  local_d0 = *puVar9;
  puVar9[1] = 0;
  puVar9[2] = 0;
  *puVar9 = 0;
  local_108 = 0x4284000042a00000;
  pvVar11 = (void *)((ulong)&local_d0 | 1);
  if ((local_d0 & 1) != 0) {
    pvVar11 = local_c0;
  }
                    /* try { // try from 002e6664 to 002e666f has its CatchHandler @ 002e6750 */
  uVar7 = ImGui_Button(pvVar11,&local_108,0);
  if ((local_d0 & 1) != 0) {
    free(local_c0);
  }
  if (((uint)(float)local_100 & 1) != 0) {
    free(local_f0);
  }
  if ((local_e8 & 1) != 0) {
    free(local_d8);
  }
  if (((uVar7 & 1) != 0) && (*param_5 == -1)) {
    *param_5 = param_6;
  }
  local_d0 = CONCAT44(param_2,fVar12);
  ImGui_SetCursorScreenPos(&local_d0);
  if (*(long *)(lVar1 + 0x28) == local_b0) {
    return bVar4 & cVar2 != '\0' & cVar3 == '\0';
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

