/* Entry: 0x00154648; Ghidra function: Gui_UpdateAction */


uint Gui_UpdateAction(float param_1,float param_2,undefined4 param_3,undefined4 param_4,
                     undefined4 param_5,undefined4 param_6,undefined8 param_7)

{
  long lVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined8 uVar4;
  float fVar5;
  float fVar6;
  undefined auVar7 [16];
  undefined8 local_80;
  undefined8 uStack120;
  undefined8 local_70;
  float local_68;
  float fStack100;
  undefined4 local_60;
  undefined4 uStack92;
  undefined4 local_58;
  undefined4 uStack84;
  float local_50;
  float fStack76;
  long local_48;
  
  lVar1 = cRead_8(tpidr_el0);
  local_48 = *(long *)(lVar1 + 0x28);
  local_60 = param_3;
  uStack92 = param_4;
  local_58 = param_5;
  uStack84 = param_6;
  local_50 = param_1;
  fStack76 = param_2;
  fVar6 = param_2;
  uVar4 = ImGui_GetWindowDrawList();
  fVar5 = (float)ImGui_GetCursorScreenPos();
  local_68 = fVar5;
  fStack100 = fVar6;
  ImGui_GetWindowPos();
  local_80 = CONCAT44(fVar6 + param_2,fVar5 + param_1);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_60);
  fVar5 = param_2 * 0.5;
  ImDrawList_AddRectFilled(fVar5,uVar4,&local_68,&local_80,uVar2,0);
  fVar6 = (float)ImGui_CalcTextSize(0x42480000,0,param_7);
  local_70 = CONCAT44((fStack100 + fVar5) - param_2 * 0.5,(local_68 + param_1 * 0.5) - fVar6 * 0.5);
  auVar7 = NEON_fmov(0x3f800000,4);
  uStack120 = SUB168(auVar7 >> 0x40,0);
  local_80 = SUB168(auVar7,0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(local_70,local_80,&local_80);
  ImDrawList_AddText(0x42480000,uVar4,0,&local_70,uVar2,param_7,0,0);
  uVar3 = ImGui_Button(param_7,&local_50,0);
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return uVar3 & 1;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

