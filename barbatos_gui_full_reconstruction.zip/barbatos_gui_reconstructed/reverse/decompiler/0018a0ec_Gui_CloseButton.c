/* Entry: 0x0018a0ec; Ghidra function: Gui_CloseButton */


uint Gui_CloseButton(undefined8 param_1,float param_2,undefined8 param_3)

{
  long lVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined8 uVar4;
  float fVar5;
  undefined8 local_80;
  undefined8 uStack120;
  float local_70;
  float fStack108;
  float local_68;
  float fStack100;
  float local_60;
  float fStack92;
  float local_58;
  float fStack84;
  float local_50;
  float fStack76;
  long local_48;
  
  lVar1 = cRead_8(tpidr_el0);
  local_48 = *(long *)(lVar1 + 0x28);
  uVar4 = ImGui_GetWindowDrawList();
  local_50 = (float)ImGui_GetCursorScreenPos();
  fVar5 = (float)ImGui_GetWindowPos();
  fStack76 = param_2 + 55.0;
  local_50 = local_50 + fVar5 + -100.0 + 45.0;
  local_70 = local_50 + -15.0;
  fStack100 = fStack76 + -15.0;
  local_68 = local_50 + 15.0;
  fStack108 = fStack76 + 15.0;
  uStack120 = 0x3f8000003f61e1e3;
  local_80 = 0x3f61e1e33f61e1e3;
  local_60 = local_68;
  fStack92 = fStack108;
  local_58 = local_70;
  fStack84 = fStack100;
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_80);
  ImDrawList_AddCircle(0x420c0000,uVar4,&local_50,uVar2,0x20);
  ImDrawList_AddLine(0x40c00000,uVar4,&local_58,&local_60,0xff8c8c8c);
  ImDrawList_AddLine(0x40c00000,uVar4,&local_68,&local_70,0xff8c8c8c);
  local_80 = CONCAT44(fStack76 + -40.0,local_50 + -50.0);
  ImGui_SetCursorScreenPos(&local_80);
  local_80 = 0x42a0000042c80000;
  uVar3 = ImGui_Button(param_3,&local_80,0);
  uVar2 = ImGui_GetWindowSize();
  local_80 = CONCAT44(fStack76,uVar2);
  ImGui_SetCursorScreenPos(&local_80);
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return uVar3 & 1;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

