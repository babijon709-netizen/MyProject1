/* Entry: 0x00179138; Ghidra function: Gui_DrawTexture */


void Gui_DrawTexture(float param_1,float param_2,float param_3,float param_4,float param_5,
                    undefined8 param_6)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 local_78;
  undefined8 local_70;
  float local_68;
  float fStack100;
  float local_60;
  float fStack92;
  long local_58;
  
  lVar1 = cRead_8(tpidr_el0);
  local_58 = *(long *)(lVar1 + 0x28);
  uVar2 = ImGui_GetWindowDrawList();
  local_70 = 0;
  local_60 = param_1 - param_3 / param_4;
  local_68 = param_1 + param_3 / param_4;
  fStack92 = param_2 - param_3 / param_5;
  fStack100 = param_2 + param_3 / param_5;
  local_78 = NEON_fmov(0x3f800000,4);
  FUN_002af780(uVar2,param_6,&local_60,&local_68,&local_70,&local_78,0xffffffff);
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

