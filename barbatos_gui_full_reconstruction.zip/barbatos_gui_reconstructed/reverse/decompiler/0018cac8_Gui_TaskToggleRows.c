/* Entry: 0x0018cac8; Ghidra function: Gui_TaskToggleRows */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_TaskToggleRows(undefined8 param_1,float param_2,long param_3,long param_4,long param_5,
                       ulong param_6,long param_7)

{
  long lVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  ulong uVar5;
  byte *pbVar6;
  int iVar7;
  ulong uVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float local_d8;
  float fStack212;
  undefined8 local_d0;
  undefined8 uStack200;
  float local_c0;
  float fStack188;
  float local_b8;
  float local_b4;
  long local_b0;
  
  lVar1 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar1 + 0x28);
  fVar11 = param_2;
  uVar4 = ImGui_GetWindowDrawList();
  fVar9 = (float)ImGui_GetCursorScreenPos();
  fVar12 = fVar11;
  local_b8 = fVar9;
  local_b4 = fVar11;
  fVar10 = (float)ImGui_GetWindowPos();
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_c0 = 0.0;
    if (param_7 != 0) {
      local_c0 = 55.0;
    }
    local_c0 = local_c0 + fVar9 + 50.0;
    uStack200 = 0x3f8000003df0f0f2;
    local_d0 = 0x3df0f0f23df0f0f2;
    fStack188 = fVar11;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    ImDrawList_AddText(0x421c0000,uVar4,0,&local_c0,uVar2,param_3,0,0);
    if (param_7 == 0) {
      fVar9 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar9 + 70.0,fVar12 * 0.5 + fVar11,0x41c00000,0x3f800000,0x3f800000,param_7);
      fVar9 = 10.0;
    }
    local_b4 = fVar11 + fVar12 + fVar9;
    ImGui_SetCursorScreenPos(&local_b8);
    fVar9 = local_b8;
    fVar11 = local_b4;
  }
  iVar7 = (int)(param_6 & 0xffffffff);
  fVar12 = (float)iVar7;
  local_c0 = fVar10 + fVar9 + -20.0;
  fStack188 = (float)NEON_fmadd(param_2,fVar12,fVar11);
  local_d0 = CONCAT44(fVar11,fVar9 + 20.0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar4,&local_d0,&local_c0,uVar2,0);
  if (0 < iVar7) {
    uVar8 = 0;
    do {
      if (uVar8 != 0) {
        local_c0 = local_b8 + 45.0;
        fStack212 = (float)NEON_fmadd(param_2,(float)(int)uVar8,local_b4);
        local_d8 = fVar10 + local_b8 + -20.0;
        uStack200 = 0x3f8000003f028283;
        local_d0 = 0x3f0282833f028283;
        fStack188 = fStack212;
        uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
        ImDrawList_AddLine(0x3fc00000,uVar4,&local_c0,&local_d8,uVar2);
      }
      fVar11 = (float)(int)uVar8;
      fVar9 = (float)NEON_fmadd(param_2,fVar11,local_b4);
      local_d0 = CONCAT44(fVar9,local_b8 + 20.0);
      ImGui_SetCursorScreenPos(&local_d0);
      local_d0 = CONCAT44(param_2,fVar10 + -40.0);
      uVar5 = ImGui_Button(*(undefined8 *)(param_4 + uVar8 * 8),&local_d0,0);
      if (((uVar5 & 1) != 0) && (DAT_0050e634 == '\0')) {
        pbVar6 = *(byte **)(param_5 + uVar8 * 8);
        *pbVar6 = *pbVar6 ^ 1;
      }
      if (**(char **)(param_5 + uVar8 * 8) != '\0') {
        fVar9 = (float)NEON_fmadd(param_2,fVar11,param_2 * 0.5 + local_b4);
        Gui_DrawTexture(fVar10 + local_b8 + -20.0 + -45.0,fVar9,0x41c00000,0x3f866666,0x3f800000,
                        DAT_0050d8a0);
      }
      ImGui_CalcTextSize(_DAT_004d3e84,0,*(undefined8 *)(param_4 + uVar8 * 8));
      uVar2 = _DAT_004d3e84;
      fVar11 = (float)NEON_fmadd(param_2,fVar11,param_2 * 0.5 + local_b4);
      local_c0 = local_b8 + 45.0;
      fStack188 = fVar11 + fVar9 * -0.5 + -1.0;
      uStack200 = 0x3f8000003df0f0f2;
      local_d0 = 0x3df0f0f23df0f0f2;
      uVar3 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddText(uVar2,uVar4,0,&local_c0,uVar3,*(undefined8 *)(param_4 + uVar8 * 8),0,0);
      uVar8 = uVar8 + 1;
    } while ((param_6 & 0xffffffff) != uVar8);
  }
  fVar9 = (float)NEON_fmadd(param_2,fVar12,local_b4);
  local_d0 = CONCAT44(fVar9 + 20.0,local_b8);
  ImGui_SetCursorScreenPos(&local_d0);
  if (*(long *)(lVar1 + 0x28) != local_b0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

