/* Entry: 0x001ebed0; Ghidra function: Gui_ReportFileError */


void Gui_ReportFileError(undefined8 param_1)

{
  long lVar1;
  void *__ptr;
  void *__ptr_00;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined4 local_48;
  int local_44;
  int local_40;
  int local_3c;
  long local_38;
  
  lVar1 = cRead_8(tpidr_el0);
  local_38 = *(long *)(lVar1 + 0x28);
  __ptr = (void *)FUN_002d15a8(param_1,&local_3c,&local_40,&local_44,0);
  if (__ptr == (void *)0x0) {
    uVar2 = FUN_002d1598();
    printf(&DAT_0012961c,uVar2);
    local_48 = 0;
  }
  else {
    __ptr_00 = (void *)FUN_002772ac(__ptr,local_3c,local_40,local_44,10);
    free(__ptr);
    local_3c = (local_3c / 10 + (local_3c >> 0x1f)) - (int)((long)local_3c * 0x66666667 >> 0x3f);
    local_40 = (local_40 / 10 + (local_40 >> 0x1f)) - (int)((long)local_40 * 0x66666667 >> 0x3f);
    glPixelStorei(0xcf5,1);
    glGenTextures(1,&local_48);
    glEnable(0xde1);
    glBindTexture(0xde1,local_48);
    glTexParameteri(0xde1,0x2802,0x812f);
    glTexParameteri(0xde1,0x2803,0x812f);
    glTexParameteri(0xde1,0x2801,0x2601);
    glTexParameteri(0xde1,0x2800,0x2601);
    if (local_44 == 3) {
      uVar2 = 0x1907;
      uVar3 = 0x1907;
    }
    else {
      uVar2 = 0x1908;
      uVar3 = 0x1908;
    }
    glTexImage2D(0xde1,0,uVar2,local_3c,local_40,0,uVar3,0x1401,__ptr_00);
    free(__ptr_00);
  }
  if (*(long *)(lVar1 + 0x28) == local_38) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(local_48);
}

