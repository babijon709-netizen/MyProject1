/* Entry: 0x00151598; Ghidra function: Gui_RenderBootLayer */


void Gui_RenderBootLayer(void)

{
  long lVar1;
  float fVar2;
  
  if (DAT_004f8130 != '\x01') {
    return;
  }
  lVar1 = ImGui_GetIO();
  fVar2 = *(float *)(lVar1 + 0x10) / DAT_004f800c;
  if (DAT_003950f8 == '\0') {
    DAT_004f8008 = DAT_004f8008 + fVar2;
    fVar2 = 1.0;
    if (DAT_004f8008 <= 1.0) goto LAB_002515f4;
  }
  else {
    DAT_004f8008 = DAT_004f8008 - fVar2;
    fVar2 = 0.0;
    if (0.0 <= DAT_004f8008) goto LAB_002515f4;
  }
  DAT_004f8008 = fVar2;
LAB_002515f4:
  FUN_00268984(&DAT_004f7fa8);
  if (DAT_0050d798 != 0) {
    FUN_00251690(&DAT_004f7fa8);
  }
  if (DAT_003950f8 == '\0') {
    if (*DAT_004f7fb0 <= 0.998) {
      return;
    }
  }
  else if (0.002 <= *DAT_004f7fa8) {
    return;
  }
  DAT_004f8130 = 0;
  return;
}

