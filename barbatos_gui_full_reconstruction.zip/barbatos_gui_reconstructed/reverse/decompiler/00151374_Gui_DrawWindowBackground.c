/* Entry: 0x00151374; Ghidra function: Gui_DrawWindowBackground */


void Gui_DrawWindowBackground(float param_1,float param_2)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  float fVar4;
  float local_78;
  float fStack116;
  undefined8 local_70;
  undefined8 uStack104;
  long local_58;
  
  lVar1 = cRead_8(tpidr_el0);
  local_58 = *(long *)(lVar1 + 0x28);
  uVar3 = ImGui_GetWindowDrawList();
  fVar4 = param_1 + 8.0 + 70.0;
  param_2 = param_2 + 40.0;
  uStack104 = 0x3f8000003f169697;
  local_70 = 0x3f1696973f169697;
  local_78 = fVar4 + -40.0;
  fStack116 = param_2;
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_70);
  ImDrawList_AddCircle(0x41680000,uVar3,&local_78,uVar2,0xc);
  local_78 = fVar4;
  fStack116 = param_2;
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_70);
  ImDrawList_AddCircle(0x41680000,uVar3,&local_78,uVar2,0xc);
  local_78 = fVar4 + 40.0;
  fStack116 = param_2;
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_70);
  ImDrawList_AddCircle(0x41680000,uVar3,&local_78,uVar2,0xc);
  local_70 = CONCAT44(param_2,fVar4 + -40.0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_004f7f70);
  ImDrawList_AddCircle(0x41500000,uVar3,&local_70,uVar2,0xc);
  local_70 = CONCAT44(param_2,fVar4);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_004f7f80);
  ImDrawList_AddCircle(0x41500000,uVar3,&local_70,uVar2,0xc);
  local_70 = CONCAT44(param_2,fVar4 + 40.0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_004f7f90);
  ImDrawList_AddCircle(0x41500000,uVar3,&local_70,uVar2,0xc);
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

