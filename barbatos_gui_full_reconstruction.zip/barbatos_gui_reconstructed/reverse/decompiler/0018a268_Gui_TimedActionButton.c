/* Entry: 0x0018a268; Ghidra function: Gui_TimedActionButton */


undefined4
Gui_TimedActionButton
          (undefined8 param_1,float param_2,long param_3,undefined8 param_4,long param_5,
          long param_6,char *param_7)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  ulong uVar4;
  long lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float local_b8;
  float fStack180;
  undefined8 local_b0;
  undefined8 uStack168;
  float local_98;
  float fStack148;
  float local_90;
  float local_8c;
  long local_88;
  
  lVar1 = cRead_8(tpidr_el0);
  local_88 = *(long *)(lVar1 + 0x28);
  uVar3 = ImGui_GetWindowDrawList();
  fVar8 = (float)ImGui_GetCursorScreenPos();
  fVar10 = param_2;
  local_90 = fVar8;
  local_8c = param_2;
  fVar9 = (float)ImGui_GetWindowPos();
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_98 = 0.0;
    if (param_6 != 0) {
      local_98 = 55.0;
    }
    local_98 = local_98 + fVar8 + 50.0;
    uStack168 = 0x3f8000003df0f0f2;
    local_b0 = 0x3df0f0f23df0f0f2;
    fStack148 = param_2;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_b0);
    ImDrawList_AddText(0x421c0000,uVar3,0,&local_98,uVar2,param_3,0,0);
    if (param_6 == 0) {
      fVar8 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar8 + 70.0,fVar10 * 0.5 + param_2 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_6);
      fVar8 = 10.0;
    }
    local_8c = param_2 + fVar10 + fVar8;
    ImGui_SetCursorScreenPos(&local_90);
  }
  if (*param_7 == '\0') {
    local_98 = fVar9 + local_90 + -20.0;
    fStack148 = local_8c + *(float *)(param_5 + 4);
    local_b0 = CONCAT44(local_8c,local_90 + 20.0);
    fVar10 = local_98;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
    puVar6 = &local_b0;
    puVar7 = (undefined8 *)&local_98;
  }
  else {
    local_98 = local_90 + 20.0;
    local_b8 = fVar9 + local_90 + -20.0;
    fStack180 = local_8c + *(float *)(param_5 + 4);
    fStack148 = local_8c;
    uStack168 = 0x3f8000003f52d2d4;
    local_b0 = 0x3f52d2d43f52d2d4;
    fVar10 = fStack180;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_b0);
    puVar6 = (undefined8 *)&local_98;
    puVar7 = (undefined8 *)&local_b8;
  }
  ImDrawList_AddRectFilled(0x41400000,uVar3,puVar6,puVar7,uVar2,0);
  ImGui_CalcTextSize(0x42180000,0,param_4);
  local_98 = local_90 + 45.0;
  fStack148 = ((local_8c + *(float *)(param_5 + 4) * 0.5) - fVar10 * 0.5) + -1.0;
  uStack168 = 0x3f8000003df0f0f2;
  local_b0 = 0x3df0f0f23df0f0f2;
  uVar2 = ImGui_ColorConvertFloat4ToU32(&local_b0);
  ImDrawList_AddText(0x42180000,uVar3,0,&local_98,uVar2,param_4,0,0);
  local_b0 = CONCAT44(local_8c,local_90 + 20.0);
  ImGui_SetCursorScreenPos(&local_b0);
  local_b0 = CONCAT44(*(undefined4 *)(param_5 + 4),fVar9 + -40.0);
  uVar4 = ImGui_Button(param_4,&local_b0,0);
  if (((uVar4 & 1) != 0) && (DAT_0050e634 == '\0')) {
    *param_7 = '\x01';
    uVar3 = FUN_0034a23c();
    *(undefined8 *)(param_7 + 8) = uVar3;
  }
  if (*param_7 != '\0') {
    lVar5 = FUN_0034a23c();
    if (280.0 <= (double)((lVar5 - *(long *)(param_7 + 8)) / 1000) / 1000.0) {
      uVar2 = 1;
      *(undefined4 *)(param_7 + 4) = 0;
      *param_7 = '\0';
      goto LAB_0028a5a4;
    }
  }
  uVar2 = 0;
LAB_0028a5a4:
  local_b0 = CONCAT44(local_8c + *(float *)(param_5 + 4) + 20.0,local_90);
  ImGui_SetCursorScreenPos(&local_b0);
  if (*(long *)(lVar1 + 0x28) == local_88) {
    return uVar2;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

