/* Entry: 0x001e69f8; Ghidra function: Gui_RenderItemsPage */


/* WARNING: Could not reconcile some variable overlaps */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_RenderItemsPage(void)

{
  long lVar1;
  void *pvVar2;
  char *pcVar3;
  long lVar4;
  char *pcVar5;
  undefined *puVar6;
  bool bVar7;
  undefined4 uVar8;
  int iVar9;
  long lVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  ulong uVar13;
  undefined *puVar14;
  undefined *puVar15;
  undefined8 *puVar16;
  float fVar17;
  undefined8 *puVar18;
  undefined auVar19 [16];
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  undefined4 uVar24;
  undefined8 local_f8;
  undefined8 local_f0;
  undefined8 local_e8;
  undefined8 *local_e0;
  undefined8 *puStack216;
  undefined8 *local_d0;
  undefined *local_c8;
  char *pcStack192;
  undefined4 *local_b8;
  undefined8 local_b0;
  undefined *local_a8;
  long local_a0;
  
  lVar4 = cRead_8(tpidr_el0);
  local_a0 = *(long *)(lVar4 + 0x28);
  if (((DAT_0050ee08 & 1) == 0) && (iVar9 = FUN_0036eb48(&DAT_0050ee08), iVar9 != 0)) {
    DAT_0050edfc = '\0';
    DAT_0050ee00 = 0.0;
    DAT_0050edf8 = 0.08;
    FUN_0036eca0(&DAT_0050ee08);
  }
  lVar10 = ImGui_GetIO();
  fVar17 = DAT_0050ee00;
  if (44.0 <= 1000.0 / (*(float *)(lVar10 + 0x10) * 1000.0)) {
    fVar20 = 0.0;
    if (DAT_0050edfc != '\0') {
      fVar20 = 1.0;
    }
    lVar10 = ImGui_GetIO();
    fVar17 = (float)NEON_fmadd(*(float *)(lVar10 + 0x10) / DAT_0050edf8,fVar20 - DAT_0050ee00,fVar17
                              );
    fVar20 = (float)NEON_fmin(fVar17,0x3f800000);
    DAT_0050ee00 = 0.0;
    if (0.0 <= fVar17) {
      DAT_0050ee00 = fVar20;
    }
  }
  DAT_0050edfc = DAT_004d7038 != -1;
  if (((DAT_0050ee20 & 1) == 0) && (iVar9 = FUN_0036eb48(&DAT_0050ee20), iVar9 != 0)) {
    DAT_0050ee14 = '\0';
    DAT_0050ee18 = 0.0;
    DAT_0050ee10 = 0.08;
    FUN_0036eca0(&DAT_0050ee20);
  }
  lVar10 = ImGui_GetIO();
  fVar17 = DAT_0050ee18;
  fVar20 = 1000.0 / (*(float *)(lVar10 + 0x10) * 1000.0);
  fVar21 = 44.0;
  if (44.0 <= fVar20) {
    fVar20 = 0.0;
    if (DAT_0050ee14 != '\0') {
      fVar20 = 1.0;
    }
    lVar10 = ImGui_GetIO();
    fVar17 = (float)NEON_fmadd(*(float *)(lVar10 + 0x10) / DAT_0050ee10,fVar20 - DAT_0050ee18,fVar17
                              );
    fVar21 = (float)NEON_fmin(fVar17,0x3f800000);
    DAT_0050ee18 = 0.0;
    fVar20 = 0.0;
    if (0.0 <= fVar17) {
      DAT_0050ee18 = fVar21;
      fVar20 = fVar21;
    }
  }
  local_e0 = (undefined8 *)0x0;
  DAT_0050ee14 = DAT_004d7020 != -1;
  ImGui_BeginChild("##Itemsright",&local_e0,0);
  uVar11 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar17 = fVar21;
  fVar23 = fVar20;
  ImGui_GetWindowPos();
  local_e8 = CONCAT44(fVar21,fVar20);
  auVar19 = NEON_fmov(0x3f800000,4);
  local_f0 = CONCAT44(fVar21 + fVar17,fVar20 + fVar23);
  puStack216 = SUB168(auVar19 >> 0x40,0);
  local_e0 = SUB168(auVar19,0);
  fVar22 = fVar20;
  uVar8 = ImGui_ColorConvertFloat4ToU32(local_e0,&local_e0);
  ImDrawList_AddRectFilled(uVar11,&local_e8,&local_f0,uVar8,0xa0);
  if (DAT_0050d8d8 != 0) {
    local_e8 = CONCAT44(fVar21 + fVar17,fVar20 + fVar23);
    local_e0 = (undefined8 *)CONCAT44(fVar21,fVar20);
    FUN_002791f4(&local_e0,&local_e8,0xa0);
    fVar22 = fVar21;
    FUN_002514f8(DAT_0050d8d8);
    FUN_00279398();
  }
  fVar17 = 55.0;
  ImGui_CalcTextSize(0,(&PTR_DAT_004d7028)[DAT_004f3d14]);
  local_e8 = CONCAT44(fVar21 + 39.0 + fVar22 * -0.5,fVar20 + fVar23 * 0.5 + fVar17 * -0.5);
  puStack216 = (undefined8 *)0x3f8000003df0f0f2;
  local_e0 = (undefined8 *)0x3df0f0f23df0f0f2;
  uVar8 = ImGui_ColorConvertFloat4ToU32(&local_e0);
  fVar20 = 0.0;
  fVar17 = 0.0;
  ImDrawList_AddText(uVar11,0,&local_e8,uVar8,(&PTR_DAT_004d7028)[DAT_004f3d14],0,0);
  uVar8 = DAT_00395104;
  ImGui_SetCursorPosY();
  local_e0 = (undefined8 *)0x0;
  ImGui_BeginChild("##centre",&local_e0,0,0x80000c);
  ImGui_GetCursorScreenPos();
  local_e0 = (undefined8 *)CONCAT44(fVar20 + 10.0,uVar8);
  ImGui_GetWindowPos();
  ImGui_SetCursorScreenPos(&local_e0);
  if (((DAT_0050ee38 & 1) == 0) && (iVar9 = FUN_0036eb48(&DAT_0050ee38), iVar9 != 0)) {
    DAT_0050ee35 = DAT_004f2188;
    DAT_0050ee34 = 0;
    DAT_0050ee30 = 0x3da3d70a;
    DAT_0050ee28 = 0;
    if (DAT_004f2188 != '\0') {
      DAT_0050ee28 = 0x3f800000;
    }
    DAT_0050ee2c = DAT_0050ee28;
    FUN_0036eca0(&DAT_0050ee38);
  }
  pcVar3 = &UNK_00121689;
  pcVar5 = &UNK_00124bc0;
  if (DAT_004f3d14 != 0) {
    pcVar3 = "Dev Mode";
    pcVar5 = "Open Class Name";
  }
  local_e8._0_4_ = 83.0;
  local_e8._4_4_ = 63.0;
  Gui_CustomItemRow(pcVar5,pcVar3,&DAT_004f2188,&DAT_004d7038,0x378,&DAT_0050ee28,DAT_0050d848,
                    DAT_0050d858);
  uVar11 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar20 = (float)local_e8;
  ImGui_GetWindowPos();
  fVar21 = local_e8._4_4_ + 10.0;
  local_e8._4_4_ = fVar21;
  ImGui_SetCursorScreenPos(&local_e8);
  pcVar3 = &UNK_00128f82;
  if (DAT_004f3d14 != 0) {
    pcVar3 = "My Items-Mate";
  }
  ImGui_CalcTextSize(0,pcVar3);
  local_f0 = CONCAT44(local_e8._4_4_,(float)local_e8 + 50.0 + 55.0);
  puStack216 = (undefined8 *)0x3f8000003df0f0f2;
  local_e0 = (undefined8 *)0x3df0f0f23df0f0f2;
  uVar8 = ImGui_ColorConvertFloat4ToU32(&local_e0);
  pcVar3 = &UNK_00128f82;
  if (DAT_004f3d14 != 0) {
    pcVar3 = "My Items-Mate";
  }
  ImDrawList_AddText(uVar11,0,&local_f0,uVar8,pcVar3,0,0);
  Gui_DrawTexture(DAT_0050d850);
  local_e8._4_4_ = fVar21 + 10.0 + local_e8._4_4_;
  ImGui_SetCursorScreenPos(&local_e8);
  fVar23 = fVar20 + (float)local_e8 + -20.0;
  local_f0 = CONCAT44(local_e8._4_4_,(float)local_e8 + 20.0);
  puStack216 = SUB168(_DAT_0012bf10 >> 0x40,0);
  local_e0 = SUB168(_DAT_0012bf10,0);
  local_f8 = CONCAT44(local_e8._4_4_ + (float)(DAT_004f7d18 * 0x3f),fVar23);
  uVar8 = ImGui_ColorConvertFloat4ToU32(&local_e0);
  fVar21 = 12.0;
  ImDrawList_AddRectFilled(uVar11,&local_f0,&local_f8,uVar8,0);
  local_e0 = (undefined8 *)0x0;
  ImGui_BeginChild("##centreTwo",&local_e0,0,0x800004);
  uVar11 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar20 = fVar21;
  ImGui_GetWindowPos();
  if (DAT_004d7038 == -1) {
    fVar17 = fVar20;
    Gui_OverlayStateBegin(0);
    Gui_OverlayStateEnd(0);
    Gui_OverlayAnimation(0);
  }
  local_e0 = (undefined8 *)CONCAT44(fVar23 + fVar17,fVar21);
  ImGui_SetCursorScreenPos(&local_e0);
  if (((DAT_0050fe40 & 1) == 0) && (iVar9 = FUN_0036eb48(&DAT_0050fe40), iVar9 != 0)) {
    lVar10 = 0;
    do {
      lVar1 = lVar10 + 0x10;
      *(undefined2 *)((long)&DAT_0050ee4c + lVar10) = 0;
      *(undefined4 *)((long)&DAT_0050ee48 + lVar10) = 0x3da3d70a;
      *(undefined8 *)((long)&DAT_0050ee40 + lVar10) = 0;
      lVar10 = lVar1;
    } while (lVar1 != 0x1000);
    FUN_0036eca0(&DAT_0050fe40);
  }
  if (0 < DAT_004f7d18) {
    puVar15 = &DAT_004f5d18;
    Gui_CustomItemRowCore(&DAT_004f5d18,&DAT_004f2194,&DAT_004d7038,0,&DAT_0050ee40,DAT_0050d860);
    if (1 < DAT_004f7d18) {
      iVar9 = 0x3f;
      puVar16 = &DAT_0050ee50;
      auVar19 = _DAT_0012bbb0 >> 0x40;
      puVar18 = SUB168(_DAT_0012bbb0,0);
      lVar10 = 0xd;
      do {
        puVar15 = puVar15 + 0x20;
        local_e8._4_4_ = fVar17 + fVar23 + (float)iVar9;
        local_f0 = CONCAT44(local_e8._4_4_,fVar21 + fVar20 + -20.0);
        local_e0 = puVar18;
        puStack216 = (undefined8 *)SUB168(auVar19,0);
        local_e8._0_4_ = fVar21 + 45.0;
        uVar8 = ImGui_ColorConvertFloat4ToU32(&local_e0);
        ImDrawList_AddLine(uVar11,&local_e8,&local_f0,uVar8);
        Gui_CustomItemRowCore
                  (puVar15,&DAT_004f2188 + lVar10,&DAT_004d7038,(int)lVar10 + -0xc,puVar16,
                   DAT_0050d860);
        puVar14 = &DAT_fffffffffffffff5 + lVar10;
        iVar9 = iVar9 + 0x3f;
        puVar16 = puVar16 + 2;
        lVar10 = lVar10 + 1;
      } while ((long)puVar14 < (long)DAT_004f7d18);
    }
  }
  ImGui_EndChild();
  ImGui_EndChild();
  ImGui_EndChild();
  uVar11 = NEON_fmov(0x3f800000,4);
  if ((DAT_0050edfc == '\0') || (DAT_0039516c != '\0')) {
    if (DAT_0039516c != '\0') goto LAB_002e71a8;
  }
  else {
    DAT_00395170 = Gui_RenderImageLayer
                             ("Hello ImGui",&DAT_004f8160,&DAT_004f8168,(int)DAT_00395174,4);
    _DAT_0039516c = 0x101;
LAB_002e71a8:
    local_e0 = (undefined8 *)0x0;
    ImGui_SetCursorPos(&local_e0);
    local_e0 = (undefined8 *)0x0;
    ImGui_BeginChild("##BottomBlur",&local_e0,0,0x800008);
    uVar12 = ImGui_GetWindowDrawList();
    local_e0 = (undefined8 *)
               CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                        (float)DAT_004f8160 + (float)DAT_004f8168);
    local_e8 = 0;
    local_f0 = uVar11;
    ImDrawList_AddRectFilledMultiColor
              (uVar12,DAT_00395170,&DAT_004f8160,&local_e0,&local_e8,&local_f0,
               (int)(DAT_0050ee00 * 255.0) * 0x1000000 + 0x1ffffff,0);
    local_e8._0_4_ = (float)DAT_004f8160 + (float)DAT_004f8168;
    local_e8._4_4_ = (float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_;
    local_e0 = (undefined8 *)0x3f1696973f169697;
    puStack216 = (undefined8 *)CONCAT44((float)(int)(DAT_0050ee00 * 100.0) * 0.003921569,0x3f169697)
    ;
    uVar8 = ImGui_ColorConvertFloat4ToU32(&local_e0);
    ImDrawList_AddRectFilled(uVar12,&DAT_004f8160,&local_e8,uVar8,0);
    ImGui_EndChild();
    if (((DAT_0050edfc == '\0') && (DAT_0050ee00 <= 0.02)) && (_DAT_0039516c = 0, DAT_00395170 != 0)
       ) {
      glDeleteBuffers(1,&DAT_00395170);
      DAT_00395170 = 0;
    }
  }
  uVar8 = NEON_fmadd(DAT_0050ee18,0x41a00000,0x428c0000);
  uVar24 = NEON_fmsub(DAT_0050ee00,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
  uVar24 = NEON_fmsub(DAT_0050ee18,0x41a00000,uVar24);
  local_e0 = (undefined8 *)CONCAT44(uVar24,uVar8);
  ImGui_SetCursorPos(&local_e0);
  fVar17 = (float)NEON_fmadd(DAT_0050ee18,0xc1f00000,0x437f0000);
  fVar17 = fVar17 / 255.0;
  local_e0 = (undefined8 *)CONCAT44(fVar17,fVar17);
  puStack216 = (undefined8 *)CONCAT44(0x3f400000,fVar17);
  ImGui_PushStyleColor(3,&local_e0);
  uVar8 = NEON_fmadd(DAT_0050ee18,0xc2200000,(float)DAT_004f8168 + -140.0);
  local_e0 = (undefined8 *)CONCAT44(DAT_004f8168._4_4_ + -140.0,uVar8);
  ImGui_BeginChild("##Itemscentre",&local_e0,0,0x80000c);
  ImGui_PopStyleColor(1);
  if (DAT_004d7020 == -1) {
    Gui_UpdateDragScroll();
    lVar10 = DAT_0050e6f0;
    *(undefined *)(*(long *)(DAT_0050e6f0 + 0x3eb0) + 0x90) = 1;
    puVar16 = DAT_0050edf0;
    lVar10 = *(long *)(lVar10 + 0x3eb0);
    if ((lVar10 != 0) && (*(char *)((long)DAT_0050edf0 + 0x14) == '\0')) {
      *(float *)(lVar10 + 0x60) = *(float *)((long)DAT_0050edf0 + 4) + *(float *)(lVar10 + 0x60);
      fVar17 = *(float *)(lVar10 + 0x68);
      *(float *)((long)puVar16 + 4) = *(float *)(puVar16 + 1) * *(float *)((long)puVar16 + 4);
      if ((fVar17 <= *(float *)(lVar10 + 0x60)) || (*(float *)(lVar10 + 0x60) <= 0.0)) {
        *DAT_0050edf0 = 0;
      }
      if (ABS(*(float *)((long)DAT_0050edf0 + 4)) < 0.1) {
        *DAT_0050edf0 = 0;
      }
    }
  }
  ImGui_GetWindowPos();
  ImGui_GetWindowSize();
  ImGui_GetWindowDrawList();
  if (DAT_004d7038 != -1) {
    DAT_0050fe4c = DAT_004d7038;
  }
  time((time_t *)0x0);
  FUN_0036cf74();
  pvVar2 = (void *)((ulong)&local_e0 | 1);
  if (((ulong)local_e0 & 1) != 0) {
    pvVar2 = local_d0;
  }
                    /* try { // try from 002e73e8 to 002e73eb has its CatchHandler @ 002e7b0c */
  uVar13 = Gui_CloseButton(pvVar2);
  if (((ulong)local_e0 & 1) != 0) {
    free(local_d0);
  }
  if ((uVar13 & 1) != 0) {
    DAT_004d7038 = -1;
  }
  if (DAT_0050fe4c == 0x378) {
    local_e0 = (undefined8 *)FUN_0036b114(0x28);
    puVar6 = PTR_DAT_0038c568;
    puVar14 = PTR_DAT_0038c560;
    puVar15 = PTR_DAT_0038c558;
    auVar19 = _PTR_DAT_0038c548;
    puStack216 = local_e0 + 5;
    local_e0[1] = SUB168(_PTR_DAT_0038c548 >> 0x40,0);
    *local_e0 = SUB168(auVar19,0);
    local_e0[3] = puVar14;
    local_e0[2] = puVar15;
    local_e0[4] = puVar6;
                    /* try { // try from 002e7444 to 002e7457 has its CatchHandler @ 002e7af4 */
    local_d0 = puStack216;
    Gui_HomeNotices(&local_e0);
    ImGui_EndChild();
    if (local_e0 != (undefined8 *)0x0) {
      puStack216 = local_e0;
      free(local_e0);
    }
    goto LAB_002e78f0;
  }
  bVar7 = DAT_004f3d14 != 0;
  puStack216 = (undefined8 *)&DAT_004f218c;
  local_e0 = (undefined8 *)&UNK_00129f5c;
  if (bVar7) {
    local_e0 = (undefined8 *)"All Items Size";
  }
  pcStack192 = &UNK_00127058;
  if (bVar7) {
    pcStack192 = "All Items Distance[100 to Not bound]";
  }
  local_b8 = &DAT_004f2190;
  local_d0 = (undefined8 *)0x4248000041200000;
  local_c8 = &DAT_0011b5ee;
  local_b0 = 0x42c800003f800000;
  pcVar3 = &UNK_00118bb6;
  if (bVar7) {
    pcVar3 = "Adjust";
  }
  local_a8 = &DAT_0011b5ee;
  Gui_ValueEditorList(&DAT_0050fe48,pcVar3,2,DAT_0050d898,&local_e0);
  if (((DAT_0050fee0 & 1) == 0) && (iVar9 = FUN_0036eb48(&DAT_0050fee0), iVar9 != 0)) {
    DAT_0050fe58 = 0;
    DAT_0050fe5c = 0;
    DAT_0050fe68 = 0;
    DAT_0050fe6c = 0;
    DAT_0050fe78 = 0;
    DAT_0050fe50 = 0x3db851ec00000000;
    DAT_0050fe60 = 0x3db851ec00000000;
    DAT_0050fe7c = 0;
    DAT_0050fe70 = 0x3db851ec00000000;
    DAT_0050fe88 = 0;
    DAT_0050fe8c = 0;
    DAT_0050fe80 = 0x3db851ec00000000;
    DAT_0050fe98 = 0;
    DAT_0050fe9c = 0;
    DAT_0050fe90 = 0x3db851ec00000000;
    DAT_0050fea8 = 0;
    DAT_0050feac = 0;
    DAT_0050fea0 = 0x3db851ec00000000;
    DAT_0050feb8 = 0;
    DAT_0050febc = 0;
    DAT_0050feb0 = 0x3db851ec00000000;
    DAT_0050fec8 = 0;
    DAT_0050fecc = 0;
    DAT_0050fec0 = 0x3db851ec00000000;
    DAT_0050fed8 = 0;
    DAT_0050fedc = 0;
    DAT_0050fed0 = 0x3db851ec00000000;
    FUN_0036eca0(&DAT_0050fee0);
  }
  pcVar3 = &UNK_0011e11d;
  if (DAT_004f3d14 != 0) {
    pcVar3 = "Draw Color";
  }
  Gui_ColorPicker(&DAT_004f2294 + (long)DAT_0050fe4c * 0x10,pcVar3,1,&DAT_004d7020,1,&DAT_0050fe50,
                  DAT_0050d878);
  ImGui_EndChild();
  if ((DAT_0050ee14 == '\0') || (DAT_0039517c != '\0')) {
    if (DAT_0039517c != '\0') goto LAB_002e7690;
  }
  else {
    local_e0 = (undefined8 *)
               CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + 70.0,(float)DAT_004f8160 + 70.0);
    local_e8._0_4_ = (float)DAT_004f8168 + -140.0;
    local_e8._4_4_ = DAT_004f8168._4_4_ + -140.0;
    DAT_00395180 = Gui_RenderImageLayer("Hello ImGui",&local_e0,&local_e8,(int)DAT_00395174,4);
    _DAT_0039517c = 0x101;
LAB_002e7690:
    if (((DAT_0050ee14 == '\0') && (DAT_0050ee18 <= 0.02)) && (_DAT_0039517c = 0, DAT_00395180 != 0)
       ) {
      glDeleteBuffers(1,&DAT_00395180);
      DAT_00395180 = 0;
    }
  }
  if (0.01 < DAT_0050ee18) {
    uVar8 = NEON_fmsub(DAT_0050ee18,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
    local_e0 = (undefined8 *)CONCAT44(uVar8,0x428c0000);
    ImGui_SetCursorPos(&local_e0);
    fVar23 = (float)DAT_004f8168 + -140.0;
    local_e0 = (undefined8 *)CONCAT44(DAT_004f8168._4_4_ + -140.0,fVar23);
    fVar21 = (float)DAT_004f8168;
    ImGui_BeginChild("##ItemsColorAdjustPage",&local_e0,0,0x80000c);
    uVar12 = ImGui_GetWindowDrawList();
    ImGui_GetWindowPos();
    fVar17 = fVar23;
    fVar20 = fVar21;
    ImGui_GetWindowSize();
    local_e8._4_4_ = fVar20;
    local_e8._0_4_ = fVar17;
    local_f0 = 0;
    local_e0 = (undefined8 *)CONCAT44(fVar21 + local_e8._4_4_,fVar23 + (float)local_e8);
    local_f8 = uVar11;
    ImDrawList_AddRectFilledMultiColor
              (uVar12,DAT_00395180,&local_e8,&local_e0,&local_f0,&local_f8,0xffffffff,0);
    local_f0 = CONCAT44(fVar21 + local_e8._4_4_,fVar23 + (float)local_e8);
    puStack216 = (undefined8 *)0x3ec8c8ca3f800000;
    local_e0 = (undefined8 *)0x3f8000003f800000;
    uVar8 = ImGui_ColorConvertFloat4ToU32(&local_e0);
    ImDrawList_AddRectFilled(uVar12,&local_e8,&local_f0,uVar8,0);
    Gui_UpdateDragScroll();
    lVar10 = DAT_0050e6f0;
    *(undefined *)(*(long *)(DAT_0050e6f0 + 0x3eb0) + 0x90) = 1;
    puVar16 = DAT_0050edf0;
    lVar10 = *(long *)(lVar10 + 0x3eb0);
    if ((lVar10 != 0) && (*(char *)((long)DAT_0050edf0 + 0x14) == '\0')) {
      *(float *)(lVar10 + 0x60) = *(float *)((long)DAT_0050edf0 + 4) + *(float *)(lVar10 + 0x60);
      fVar17 = *(float *)(lVar10 + 0x68);
      *(float *)((long)puVar16 + 4) = *(float *)(puVar16 + 1) * *(float *)((long)puVar16 + 4);
      if ((fVar17 <= *(float *)(lVar10 + 0x60)) || (*(float *)(lVar10 + 0x60) <= 0.0)) {
        *DAT_0050edf0 = 0;
      }
      if (ABS(*(float *)((long)DAT_0050edf0 + 4)) < 0.1) {
        *DAT_0050edf0 = 0;
      }
    }
    time((time_t *)0x0);
    FUN_0036cf74();
    puVar16 = (undefined8 *)((ulong)&local_e0 | 1);
    if (((ulong)local_e0 & 1) != 0) {
      puVar16 = local_d0;
    }
                    /* try { // try from 002e7890 to 002e7893 has its CatchHandler @ 002e7af0 */
    uVar13 = Gui_CloseButton(puVar16);
    if (((ulong)local_e0 & 1) != 0) {
      free(local_d0);
    }
    if ((uVar13 & 1) != 0) {
      DAT_004d7020 = -1;
    }
    Gui_PresetColorPalette(&DAT_00128f72,&DAT_004f2294 + (long)DAT_004d7038 * 0x10,DAT_0050d890);
    ImGui_EndChild();
  }
LAB_002e78f0:
  if (*(long *)(lVar4 + 0x28) == local_a0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

