/* Entry: 0x0015109c; Ghidra function: Gui_SidebarTabs */


void Gui_SidebarTabs(undefined8 param_1,float param_2,int *param_3,long param_4,ulong param_5,
                    long param_6)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  long lVar4;
  ulong uVar5;
  ulong uVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined auVar14 [16];
  float fVar15;
  double dVar16;
  undefined8 local_d0;
  undefined8 uStack200;
  float local_b8;
  float fStack180;
  float local_b0;
  float fStack172;
  long local_a8;
  
  lVar1 = cRead_8(tpidr_el0);
  local_a8 = *(long *)(lVar1 + 0x28);
  fVar12 = param_2;
  uVar3 = ImGui_GetWindowDrawList();
  fVar8 = (float)ImGui_GetCursorScreenPos();
  fVar9 = (float)ImGui_GetWindowPos();
  fVar10 = DAT_004f7f60;
  dVar16 = (double)DAT_004f7f60;
  fVar15 = param_2 * (float)*param_3;
  lVar4 = ImGui_GetIO();
  dVar16 = (double)NEON_fmadd((double)*(float *)(lVar4 + 0x10) / 0.09,
                              (double)(fVar15 - DAT_004f7f60),dVar16);
  fVar13 = DAT_004f7f60;
  if (fVar15 <= fVar10) {
    fVar13 = fVar15;
    fVar15 = DAT_004f7f60;
  }
  fVar10 = (float)dVar16;
  if (fVar10 <= fVar15) {
    fVar15 = fVar10;
  }
  DAT_004f7f60 = fVar13;
  if (fVar13 <= fVar10) {
    DAT_004f7f60 = fVar15;
  }
  fVar15 = fVar8 + 10.0;
  fStack172 = fVar12 + DAT_004f7f60 + 5.0;
  local_b8 = fVar8 + fVar9 + -10.0;
  fStack180 = param_2 + fVar12 + DAT_004f7f60 + -5.0;
  auVar14 = NEON_fmov(0x3f800000,4);
  uStack200 = SUB168(auVar14 >> 0x40,0);
  local_d0 = SUB168(auVar14,0);
  local_b0 = fVar15;
  uVar2 = ImGui_ColorConvertFloat4ToU32(fStack180,local_d0,&local_d0);
  ImDrawList_AddRectFilled(0x41400000,uVar3,&local_b0,&local_b8,uVar2,0);
  if (0 < (int)(param_5 & 0xffffffff)) {
    uVar6 = 0;
    do {
      fVar10 = (float)(int)uVar6;
      uVar2 = NEON_fmadd(param_2,fVar10,fVar12);
      local_d0 = CONCAT44(uVar2,fVar15);
      fVar13 = fVar15;
      ImGui_SetCursorScreenPos(&local_d0);
      local_d0 = CONCAT44(param_2,fVar9 + -20.0);
      uVar5 = ImGui_Button(*(undefined8 *)(param_4 + uVar6 * 8),&local_d0,0);
      if ((uVar5 & 1) != 0) {
        *param_3 = (int)uVar6;
      }
      iVar7 = 0x27;
      if (DAT_004f3d14 != 0) {
        iVar7 = 0x28;
      }
      fVar11 = (float)ImGui_CalcTextSize((float)iVar7,0,*(undefined8 *)(param_4 + uVar6 * 8));
      fVar10 = (float)NEON_fmadd(param_2,fVar10,param_2 * 0.5 + fVar12);
      iVar7 = 0x27;
      if (DAT_004f3d14 != 0) {
        iVar7 = 0x28;
      }
      local_b0 = (fVar8 + fVar9 * 0.5) - fVar11 * 0.5;
      if (param_6 != 0) {
        local_b0 = fVar8 + 90.0;
      }
      fStack172 = (fVar10 - fVar13 * 0.5) + -1.0;
      uStack200 = 0x3f8000003df0f0f2;
      local_d0 = 0x3df0f0f23df0f0f2;
      uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddText((float)iVar7,uVar3,0,&local_b0,uVar2,*(undefined8 *)(param_4 + uVar6 * 8),0
                         ,0);
      if (param_6 != 0) {
        Gui_DrawTexture(fVar8 + 50.0,*(undefined8 *)(param_6 + uVar6 * 8));
      }
      uVar6 = uVar6 + 1;
    } while ((param_5 & 0xffffffff) != uVar6);
  }
  if (*(long *)(lVar1 + 0x28) != local_a8) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

