/* Entry: 0x0018d71c; Ghidra function: Gui_OverlayStateEnd */


void Gui_OverlayStateEnd(ulong param_1)

{
  int iVar1;
  long lVar2;
  ulong uVar3;
  float fVar4;
  float fVar5;
  undefined4 uVar6;
  float fVar7;
  
  if ((DAT_0050e5c8 & 1) == 0) {
    param_1 = param_1 & 0xffffffff;
    iVar1 = FUN_0036eb48(&DAT_0050e5c8);
    if (iVar1 != 0) {
      DAT_0050e5c0 = '\x01';
      DAT_0050e5c4 = 1.0;
      DAT_0050e5b8 = 0.12;
      DAT_0050e5bc = 1.0;
      FUN_0036eca0(&DAT_0050e5c8);
    }
  }
  if ((DAT_0050e5e0 & 1) == 0) {
    param_1 = param_1 & 0xffffffff;
    iVar1 = FUN_0036eb48(&DAT_0050e5e0);
    if (iVar1 != 0) {
      DAT_0050e5d8 = 0;
      DAT_0050e5d8 = FUN_0034a23c();
      FUN_0036eca0(&DAT_0050e5e0);
    }
  }
  if ((DAT_0050e600 & 1) == 0) {
    param_1 = param_1 & 0xffffffff;
    iVar1 = FUN_0036eb48(&DAT_0050e600);
    if (iVar1 != 0) {
      DAT_0050e5f0 = 0;
      DAT_0050e5f8 = 0;
      DAT_0050e5f8 = FUN_0034a23c();
      FUN_0036eca0(&DAT_0050e600);
    }
  }
  if ((param_1 & 1) != 0) {
    DAT_0050e5e8 = '\x01';
  }
  if ((DAT_0050e5e8 != '\0') && (DAT_0050e630 == '\0')) {
    if ((DAT_0050e5f0 & 1) == 0) {
      DAT_0050e5f8 = FUN_0034a23c();
      DAT_0050e5f0 = 1;
    }
    lVar2 = FUN_0034a23c();
    if ((double)((lVar2 - DAT_0050e5f8) / 1000) / 1000.0 <= 200.0 || DAT_0050e5f0 == 0) {
      return;
    }
    DAT_0050e5e8 = '\0';
    DAT_0050e5f0 = 0;
  }
  if ((((DAT_0050e630 == '\0') && (DAT_0050e634 != '\0')) && ((DAT_0050e5d0 & 1) == 0)) &&
     (uVar3 = FUN_0029021c(DAT_0050e650,DAT_0050e654,0x43930000,0x42a00000), (uVar3 & 1) != 0)) {
    DAT_0050e5d0 = 1;
    DAT_0050e5d4 = (DAT_0050e640._4_4_ - DAT_0050e64c) * 1.618;
    DAT_0050e5d8 = FUN_0034a23c();
  }
  if (((DAT_0050e630 == '\0') && (DAT_0050e5d0 == 1)) &&
     (lVar2 = FUN_0034a23c(), fVar5 = DAT_0050e5c4,
     (double)((lVar2 - DAT_0050e5d8) / 1000) / 1000.0 <= 1500.0)) {
    fVar4 = 1.0;
    if (DAT_0050e5c0 == '\0') {
      fVar4 = 0.0;
    }
    DAT_0050e5b8 = 0.9;
    lVar2 = ImGui_GetIO();
    if (DAT_0050e609 == '\0') {
      DAT_0050e609 = '\x01';
      fVar5 = DAT_0050e5bc;
    }
    else {
      fVar4 = (float)NEON_fmadd(*(float *)(lVar2 + 0x10) / DAT_0050e5b8,fVar4 - DAT_0050e5c4,fVar5);
      fVar7 = (float)NEON_fmin(fVar4,0x3f800000);
      fVar5 = 0.0;
      if (0.0 <= fVar4) {
        fVar5 = fVar7;
      }
    }
    if (0.7 < fVar5) {
      DAT_0050e5b8 = 1.6;
    }
    fVar4 = 1.0;
    if (DAT_0050e5c0 == '\0') {
      fVar4 = 0.0;
    }
    DAT_0050e5c4 = fVar5;
    lVar2 = ImGui_GetIO();
    if (DAT_0050e609 == '\0') {
      DAT_0050e609 = '\x01';
      fVar5 = DAT_0050e5bc;
    }
    else {
      fVar4 = (float)NEON_fmadd(*(float *)(lVar2 + 0x10) / DAT_0050e5b8,fVar4 - DAT_0050e5c4,fVar5);
      fVar7 = (float)NEON_fmin(fVar4,0x3f800000);
      fVar5 = 0.0;
      if (0.0 <= fVar4) {
        fVar5 = fVar7;
      }
    }
    if (0.35 < fVar5) {
      DAT_0050e5b8 = 3.3;
    }
    fVar4 = 1.0;
    if (DAT_0050e5c0 == '\0') {
      fVar4 = 0.0;
    }
    DAT_0050e5c4 = fVar5;
    lVar2 = ImGui_GetIO();
    if (DAT_0050e609 == '\0') {
      DAT_0050e609 = '\x01';
      DAT_0050e5c4 = DAT_0050e5bc;
    }
    else {
      fVar5 = (float)NEON_fmadd(*(float *)(lVar2 + 0x10) / DAT_0050e5b8,fVar4 - DAT_0050e5c4,fVar5);
      fVar4 = (float)NEON_fmin(fVar5,0x3f800000);
      DAT_0050e5c4 = 0.0;
      if (0.0 <= fVar5) {
        DAT_0050e5c4 = fVar4;
      }
    }
    if (DAT_0050e5c4 < 0.1) {
      DAT_0050e5b8 = 8.8;
    }
    DAT_0050e5c0 = '\0';
    uVar6 = ImGui_GetScrollY();
    fVar5 = DAT_0050e5c4;
    fVar4 = 1.0;
    if (DAT_0050e5c0 == '\0') {
      fVar4 = 0.0;
    }
    lVar2 = ImGui_GetIO();
    if (DAT_0050e609 == '\0') {
      DAT_0050e609 = '\x01';
      DAT_0050e5c4 = DAT_0050e5bc;
    }
    else {
      fVar5 = (float)NEON_fmadd(*(float *)(lVar2 + 0x10) / DAT_0050e5b8,fVar4 - DAT_0050e5c4,fVar5);
      fVar4 = (float)NEON_fmin(fVar5,0x3f800000);
      DAT_0050e5c4 = 0.0;
      if (0.0 <= fVar5) {
        DAT_0050e5c4 = fVar4;
      }
    }
    uVar6 = NEON_fmsub(DAT_0050e5c4,DAT_0050e5d4,uVar6);
    FUN_002a6198(uVar6);
  }
  if (DAT_0050e630 != '\0') {
    DAT_0050e5d0 = 0;
    DAT_0050e5c4 = 1.0;
  }
  return;
}

