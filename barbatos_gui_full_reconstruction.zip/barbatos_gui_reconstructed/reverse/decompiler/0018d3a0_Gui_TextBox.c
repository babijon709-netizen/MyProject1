/* Entry: 0x0018d3a0; Ghidra function: Gui_TextBox */


void Gui_TextBox(undefined4 param_1,undefined4 param_2,undefined8 param_3)

{
  long lVar1;
  undefined4 local_30;
  undefined4 uStack44;
  long local_28;
  
  lVar1 = cRead_8(tpidr_el0);
  local_28 = *(long *)(lVar1 + 0x28);
  local_30 = param_1;
  uStack44 = param_2;
  ImGui_BeginChild("##TextBox",&local_30,0,0x800008);
  FUN_002bdfb4(param_3);
  ImGui_EndChild();
  if (*(long *)(lVar1 + 0x28) == local_28) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

