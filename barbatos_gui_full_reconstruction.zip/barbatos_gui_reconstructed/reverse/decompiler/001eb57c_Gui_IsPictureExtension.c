/* Entry: 0x001eb57c; Ghidra function: Gui_IsPictureExtension */


void Gui_IsPictureExtension(long param_1)

{
  char *__haystack;
  long lVar1;
  uint uVar2;
  DIR *__dirp;
  dirent *pdVar3;
  char *pcVar4;
  size_t __n;
  void *pvVar5;
  ulong *puVar6;
  ulong uVar7;
  ulong local_148;
  size_t local_140;
  void *local_138;
  ulong local_130;
  ulong uStack296;
  void *local_120;
  ulong local_110;
  ulong uStack264;
  void *local_100;
  char acStack240 [128];
  long local_70;
  
  lVar1 = cRead_8(tpidr_el0);
  local_70 = *(long *)(lVar1 + 0x28);
  getcwd(acStack240,0x80);
  __dirp = opendir(acStack240);
  do {
    do {
                    /* try { // try from 002eb5e8 to 002eb5ef has its CatchHandler @ 002eb7f0 */
      pdVar3 = readdir(__dirp);
      if (pdVar3 == (dirent *)0x0) {
        if (__dirp != (DIR *)0x0) {
          uVar2 = closedir(__dirp);
          pdVar3 = (dirent *)(ulong)uVar2;
        }
        if (*(long *)(lVar1 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
          __stack_chk_fail(pdVar3);
        }
        return;
      }
      __haystack = pdVar3->d_name;
      pcVar4 = strstr(__haystack,"jpeg");
    } while (((pcVar4 == (char *)0x0) && (pcVar4 = strstr(__haystack,"jpg"), pcVar4 == (char *)0x0))
            && (pcVar4 = strstr(__haystack,"png"), pcVar4 == (char *)0x0));
    __n = strlen(acStack240);
    if (0xffffffffffffffef < __n) {
                    /* try { // try from 002eb7a4 to 002eb7ab has its CatchHandler @ 002eb7c0 */
                    /* WARNING: Subroutine does not return */
      FUN_0036b804(&local_148);
    }
    if (__n < 0x17) {
      local_148 = local_148 & 0xffffffffffffff00 | (ulong)(byte)((int)__n << 1);
      pvVar5 = (void *)((ulong)&local_148 | 1);
      if (__n != 0) goto LAB_002eb680;
    }
    else {
      uVar7 = __n + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 002eb668 to 002eb66f has its CatchHandler @ 002eb7b0 */
      pvVar5 = (void *)FUN_0036b114(uVar7);
      local_148 = uVar7 | 1;
      local_140 = __n;
      local_138 = pvVar5;
LAB_002eb680:
      memcpy(pvVar5,acStack240,__n);
    }
    *(undefined *)((long)pvVar5 + __n) = 0;
                    /* try { // try from 002eb694 to 002eb69f has its CatchHandler @ 002eb7dc */
    puVar6 = (ulong *)FUN_0036c1a8(&local_148,&DAT_0011925d);
    local_120 = (void *)puVar6[2];
    uStack296 = puVar6[1];
    local_130 = *puVar6;
    puVar6[1] = 0;
    puVar6[2] = 0;
    *puVar6 = 0;
                    /* try { // try from 002eb6b8 to 002eb6c3 has its CatchHandler @ 002eb7c4 */
    puVar6 = (ulong *)FUN_0036c1a8(&local_130,__haystack);
    local_100 = (void *)puVar6[2];
    uStack264 = puVar6[1];
    local_110 = *puVar6;
    puVar6[1] = 0;
    puVar6[2] = 0;
    *puVar6 = 0;
    if ((local_130 & 1) != 0) {
      free(local_120);
    }
    if ((local_148 & 1) != 0) {
      free(local_138);
    }
    pvVar5 = (void *)((ulong)&local_110 | 1);
    if ((local_110 & 1) != 0) {
      pvVar5 = local_100;
    }
                    /* try { // try from 002eb70c to 002eb70f has its CatchHandler @ 002eb7f8 */
    local_130 = Gui_ReportFileError(pvVar5);
    puVar6 = *(ulong **)(param_1 + 8);
    if (puVar6 < *(ulong **)(param_1 + 0x10)) {
      *puVar6 = local_130;
                    /* try { // try from 002eb728 to 002eb733 has its CatchHandler @ 002eb7b4 */
      FUN_0036b974(puVar6 + 1,&local_110);
      *(ulong **)(param_1 + 8) = puVar6 + 4;
    }
    else {
                    /* try { // try from 002eb740 to 002eb74f has its CatchHandler @ 002eb7f8 */
      FUN_002ed038(param_1,&local_130,&local_110);
    }
    if ((local_110 & 1) != 0) {
      free(local_100);
    }
  } while( true );
}

