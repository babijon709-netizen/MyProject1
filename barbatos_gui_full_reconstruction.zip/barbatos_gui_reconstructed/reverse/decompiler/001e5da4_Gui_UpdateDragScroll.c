/* Entry: 0x001e5da4; Ghidra function: Gui_UpdateDragScroll */


void Gui_UpdateDragScroll(void)

{
  long lVar1;
  int iVar2;
  long lVar3;
  undefined8 *puVar4;
  char **ppcVar5;
  float fVar6;
  float fVar7;
  
  lVar3 = ImGui_GetIO();
  lVar1 = DAT_0050e6f0;
  *(undefined *)(*(long *)(DAT_0050e6f0 + 0x3eb0) + 0x90) = 1;
  ppcVar5 = *(char ***)(lVar1 + 0x3eb0);
  if (ppcVar5 != (char **)0x0) {
    if ((s_nullptr_004d6fa0 == 0x7274706c6c756e) && (DAT_0050edf0 == (undefined8 *)0x0)) {
      puVar4 = (undefined8 *)FUN_0036b114(0x24);
      *(undefined4 *)(puVar4 + 2) = 0;
      *(undefined *)((long)puVar4 + 0x14) = 0;
      puVar4[3] = 0;
      *(undefined *)(puVar4 + 4) = 0;
      DAT_0050edf0 = puVar4;
      puVar4[1] = 0x3e99999a3f666666;
      *puVar4 = 0;
      __strcpy_chk(s_nullptr_004d6fa0,*ppcVar5,0x80);
    }
    if (((s_nullptr_004d6fa0 != 0x7274706c6c756e) &&
        (iVar2 = strcmp(s_nullptr_004d6fa0,*ppcVar5), iVar2 != 0)) &&
       (DAT_0050edf0 != (undefined8 *)0x0)) {
      free(DAT_0050edf0);
      puVar4 = (undefined8 *)FUN_0036b114(0x24);
      *(undefined4 *)(puVar4 + 2) = 0;
      *(undefined *)((long)puVar4 + 0x14) = 0;
      puVar4[3] = 0;
      *(undefined *)(puVar4 + 4) = 0;
      DAT_0050edf0 = puVar4;
      puVar4[1] = 0x3e99999a3f666666;
      *puVar4 = 0;
      __strcpy_chk(s_nullptr_004d6fa0,*ppcVar5,0x80);
    }
    puVar4 = DAT_0050edf0;
    if (DAT_00500b48 == '\0') {
      if (*(char *)((long)DAT_0050edf0 + 0x14) != '\0') {
        *(undefined *)((long)DAT_0050edf0 + 0x14) = 0;
      }
      *(undefined *)(puVar4 + 4) = 0;
    }
    else {
      if (((*(char *)(DAT_0050edf0 + 4) == '\0') && (*(float *)(ppcVar5 + 2) < DAT_0050e650)) &&
         ((DAT_0050e650 < *(float *)(ppcVar5 + 2) + *(float *)(ppcVar5 + 3) &&
          ((*(float *)((long)ppcVar5 + 0x14) < DAT_0050e654 &&
           (DAT_0050e654 < *(float *)((long)ppcVar5 + 0x14) + *(float *)((long)ppcVar5 + 0x1c)))))))
      {
        if (*(char *)((long)DAT_0050edf0 + 0x14) == '\0') {
          *(undefined *)((long)DAT_0050edf0 + 0x14) = 1;
        }
        else {
          fVar7 = (float)((ulong)DAT_00500b4c >> 0x20) - (float)((ulong)DAT_0050edf0[3] >> 0x20);
          *DAT_0050edf0 = CONCAT44(-fVar7,-((float)DAT_00500b4c - (float)DAT_0050edf0[3]));
          puVar4 = DAT_0050edf0;
          fVar7 = *(float *)(ppcVar5 + 0xc) - fVar7;
          fVar6 = 0.0;
          if ((0.0 < fVar7) &&
             (fVar6 = *(float *)(ppcVar5 + 0xd), fVar7 < *(float *)(ppcVar5 + 0xd))) {
            fVar6 = fVar7;
          }
          *(float *)(ppcVar5 + 0xc) = fVar6;
        }
        puVar4[3] = DAT_00500b4c;
        *(undefined *)(lVar3 + 200) = 1;
        return;
      }
      *(undefined *)(DAT_0050edf0 + 4) = 1;
    }
  }
  return;
}

