/* Entry: 0x00178ffc; Ghidra function: Gui_LoadTextureToSlot */


void Gui_LoadTextureToSlot(undefined8 param_1,undefined8 param_2,ulong *param_3)

{
  long lVar1;
  void *__ptr;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  uint local_48;
  int local_44;
  undefined4 uStack64;
  undefined4 local_3c;
  long local_38;
  
  lVar1 = cRead_8(tpidr_el0);
  local_38 = *(long *)(lVar1 + 0x28);
  __ptr = (void *)FUN_00277700(param_1,param_2,&local_3c,&uStack64,&local_44);
  if (__ptr == (void *)0x0) {
    puVar2 = (undefined8 *)FUN_003892d8(&DAT_003f24c0);
    printf("Error: %s\n",*puVar2);
    *param_3 = 0;
  }
  else {
    glGenTextures(1,&local_48);
    glEnable(0xde1);
    glBindTexture(0xde1,local_48);
    glTexParameteri(0xde1,0x2802,0x812f);
    glTexParameteri(0xde1,0x2803,0x812f);
    glTexParameteri(0xde1,0x2801,0x2601);
    glTexParameteri(0xde1,0x2800,0x2601);
    if (local_44 == 3) {
      uVar3 = 0x1907;
      uVar4 = 0x1907;
    }
    else {
      uVar3 = 0x1908;
      uVar4 = 0x1908;
    }
    glTexImage2D(0xde1,0,uVar3,local_3c,uStack64,0,uVar4,0x1401,__ptr);
    free(__ptr);
    *param_3 = (ulong)local_48;
  }
  if (*(long *)(lVar1 + 0x28) == local_38) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

