/* Entry: 0x001eacb8; Ghidra function: Gui_LanguageChoice */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_LanguageChoice(float param_1,float param_2,uint *param_3,long param_4,long param_5,
                       ulong param_6,long param_7)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  undefined auVar4 [16];
  undefined auVar5 [16];
  undefined4 uVar6;
  undefined8 uVar7;
  ulong uVar8;
  int iVar9;
  uint uVar10;
  ulong uVar11;
  uint uVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined4 uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined auVar19 [16];
  float fVar20;
  float fVar21;
  float local_d8;
  float fStack212;
  undefined8 local_d0;
  undefined8 uStack200;
  float local_c0;
  float fStack188;
  float local_b8;
  float local_b4;
  long local_b0;
  
  lVar2 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar2 + 0x28);
  fVar21 = param_2;
  uVar7 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar20 = fVar21;
  local_b8 = param_1;
  local_b4 = fVar21;
  fVar13 = param_1;
  ImGui_GetWindowPos();
  lVar1 = DAT_0050d8b0;
  if (param_7 != 0) {
    lVar1 = param_7;
  }
  if (param_4 != 0) {
    ImGui_CalcTextSize(0,param_4);
    local_c0 = 0.0;
    if (lVar1 != 0) {
      local_c0 = 55.0;
    }
    local_c0 = local_c0 + param_1 + 50.0;
    uStack200 = 0x3f8000003df0f0f2;
    local_d0 = 0x3df0f0f23df0f0f2;
    fStack188 = fVar21;
    uVar6 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    ImDrawList_AddText(uVar7,0,&local_c0,uVar6,param_4,0,0);
    if (lVar1 == 0) {
      fVar14 = 5.0;
    }
    else {
      Gui_DrawTexture(lVar1);
      fVar14 = 10.0;
    }
    local_b4 = fVar21 + fVar20 + fVar14;
    ImGui_SetCursorScreenPos(&local_b8);
    param_1 = local_b8;
    fVar21 = local_b4;
  }
  iVar9 = (int)(param_6 & 0xffffffff);
  fVar20 = (float)iVar9;
  fStack188 = (float)NEON_fmadd(param_2,fVar20,fVar21);
  local_c0 = fVar13 + param_1 + -20.0;
  local_d0 = CONCAT44(fVar21,param_1 + 20.0);
  uVar6 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(uVar7,&local_d0,&local_c0,uVar6,0);
  if (0 < iVar9) {
    fVar21 = param_2 * 0.5;
    uVar11 = 0;
    auVar19 = NEON_fmov(0x3f800000,4);
    auVar4 = _DAT_0012b530 >> 0x40;
    uVar17 = SUB168(_DAT_0012b530,0);
    auVar5 = _DAT_0012bbb0 >> 0x40;
    uVar18 = SUB168(_DAT_0012bbb0,0);
    do {
      uVar10 = (uint)uVar11;
      if (uVar11 == 0) {
        uVar12 = 0;
      }
      else {
        local_c0 = local_b8 + 45.0;
        fStack212 = (float)NEON_fmadd(param_2,(float)uVar10,local_b4);
        local_d8 = fVar13 + local_b8 + -20.0;
        local_d0 = uVar18;
        uStack200 = SUB168(auVar5,0);
        fStack188 = fStack212;
        uVar6 = ImGui_ColorConvertFloat4ToU32(&local_d0);
        ImDrawList_AddLine(uVar7,&local_c0,&local_d8,uVar6);
        uVar12 = uVar10;
      }
      fVar14 = (float)uVar10;
      uVar6 = NEON_fmadd(param_2,fVar14,local_b4);
      local_d0 = CONCAT44(uVar6,local_b8 + 20.0);
      ImGui_SetCursorScreenPos(&local_d0);
      local_d0 = CONCAT44(param_2,fVar13 + -40.0);
      uVar8 = ImGui_Button(*(undefined8 *)(param_5 + uVar11 * 8),&local_d0,0);
      if (((uVar8 & 1) == 0) || (DAT_0050e634 != '\0')) {
        fVar15 = (float)*param_3;
      }
      else {
        *param_3 = uVar12;
        fVar15 = fVar14;
      }
      uVar16 = 0x3f109091;
      uVar6 = 0x3f75f5f7;
      if (fVar15 != fVar14) {
        uVar6 = 0x3f800000;
        uVar16 = 0x3f800000;
      }
      local_c0 = fVar21 + -8.0 + local_b8 + 45.0;
      uVar3 = 0;
      if (fVar15 != fVar14) {
        uVar3 = 0x3f800000;
      }
      fStack188 = (float)NEON_fmadd(param_2,fVar14,fVar21 + local_b4);
      uStack200 = CONCAT44(0x3f800000,uVar6);
      local_d0 = CONCAT44(uVar16,uVar3);
      fVar15 = local_c0;
      uVar6 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddCircle(uVar7,&local_c0,uVar6,0);
      if (uVar11 == *param_3) {
        local_c0 = fVar21 + -8.0 + local_b8 + 45.0;
        fStack188 = (float)NEON_fmadd(param_2,(float)*param_3,fVar21 + local_b4);
        local_d0 = SUB168(auVar19,0);
        uStack200 = SUB168(auVar19 >> 0x40,0);
        fVar15 = fStack188;
        uVar6 = ImGui_ColorConvertFloat4ToU32(&local_d0);
        ImDrawList_AddCircle(uVar7,&local_c0,uVar6,0);
      }
      ImGui_CalcTextSize(0,*(undefined8 *)(param_5 + uVar11 * 8));
      fVar14 = (float)NEON_fmadd(param_2,fVar14,fVar21 + local_b4);
      local_c0 = local_b8 + 110.0;
      fStack188 = fVar14 + fVar15 * -0.5 + -1.0;
      local_d0 = uVar17;
      uStack200 = SUB168(auVar4,0);
      uVar6 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddText(uVar7,0,&local_c0,uVar6,*(undefined8 *)(param_5 + uVar11 * 8),0,0);
      uVar11 = uVar11 + 1;
    } while ((param_6 & 0xffffffff) != uVar11);
  }
  fVar21 = (float)NEON_fmadd(param_2,fVar20,local_b4);
  local_d0 = CONCAT44(fVar21 + 20.0,local_b8);
  ImGui_SetCursorScreenPos(&local_d0);
  if (*(long *)(lVar2 + 0x28) != local_b0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

