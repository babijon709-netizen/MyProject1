/* Entry: 0x001789ac; Ghidra function: Gui_LoadEmbeddedAssets */


void Gui_LoadEmbeddedAssets(void)

{
  long lVar1;
  void *pvVar2;
  void *pvVar3;
  FILE *__stream;
  undefined local_b0;
  undefined7 uStack175;
  void *local_98;
  void *local_90;
  void *local_70;
  void *local_68;
  void *local_58;
  void *local_50;
  long local_38;
  
  lVar1 = cRead_8(tpidr_el0);
  local_38 = *(long *)(lVar1 + 0x28);
  DAT_0050d7a0 = Gui_CreateTextureFromMemory(&PNG_0012c97a,0x4400,0,0,0);
  DAT_0050d7a8 = Gui_CreateTextureFromMemory(&PNG_00130d7a,0x5cb8,0,0,0);
  DAT_0050d7b0 = Gui_CreateTextureFromMemory(&PNG_00136a32,0x55f4,0,0,0);
  DAT_0050d7b8 = Gui_CreateTextureFromMemory(&PNG_0013c026,0x4865,0,0,0);
  DAT_0050d7c0 = Gui_CreateTextureFromMemory(&PNG_0014088b,0x47e7,0,0,0);
  DAT_0050d7c8 = Gui_CreateTextureFromMemory(&PNG_00145072,0xa120,0,0,0);
  DAT_0050d7d0 = Gui_CreateTextureFromMemory(&PNG_0014f192,0x6d6a,0,0,0);
  DAT_0050d7d8 = Gui_CreateTextureFromMemory(&PNG_00155efc,0x7410,0,0,0);
  DAT_0050d7e0 = Gui_CreateTextureFromMemory(&PNG_0015d30c,0x3d38,0,0,0);
  DAT_0050d7e0 = Gui_CreateTextureFromMemory(&PNG_00161044,0x30ad,0,0,0);
  DAT_0050d7e0 = Gui_CreateTextureFromMemory(&PNG_001640f1,0x5cf6,0,0,0);
  DAT_0050d7f8 = Gui_CreateTextureFromMemory(&PNG_00169de7,0x520e,0,0,0);
  DAT_0050d800 = Gui_CreateTextureFromMemory(&PNG_0016eff5,0x5a1c,0,0,0);
  DAT_0050d808 = Gui_CreateTextureFromMemory(&PNG_00174a11,0x4ca3,0,0,0);
  DAT_0050d810 = Gui_CreateTextureFromMemory(&PNG_001796b4,0x2854,0,0,0);
  DAT_0050d818 = Gui_CreateTextureFromMemory(&PNG_0017bf08,0x5bca,0,0,0);
  DAT_0050d820 = Gui_CreateTextureFromMemory(&PNG_00181ad2,0x7fed,0,0,0);
  DAT_0050d828 = Gui_CreateTextureFromMemory(&PNG_00189abf,0x62ed,0,0,0);
  DAT_0050d830 = Gui_CreateTextureFromMemory(&PNG_0018fdac,0xbad6,0,0,0);
  DAT_0050d838 = Gui_CreateTextureFromMemory(&PNG_0019b882,0x5cad,0,0,0);
  DAT_0050d840 = Gui_CreateTextureFromMemory(&PNG_001a152f,0x538d,0,0,0);
  DAT_0050d848 = Gui_CreateTextureFromMemory(&PNG_001a68bc,0x396b,0,0,0);
  DAT_0050d850 = Gui_CreateTextureFromMemory(&PNG_001aa227,0x4f26,0,0,0);
  DAT_0050d858 = Gui_CreateTextureFromMemory(&PNG_001af14d,0x49f8,0,0,0);
  DAT_0050d860 = Gui_CreateTextureFromMemory(&PNG_001b3b45,0x1076,0,0,0);
  DAT_0050d868 = Gui_CreateTextureFromMemory(&PNG_001b4bbb,0x92ce,0,0,0);
  DAT_0050d870 = Gui_CreateTextureFromMemory(&PNG_001bde89,0x46c2,0,0,0);
  DAT_0050d878 = Gui_CreateTextureFromMemory(&PNG_001c254b,0xb6b8,0,0,0);
  DAT_0050d880 = Gui_CreateTextureFromMemory(&PNG_001cdc03,0x4230,0,0,0);
  Gui_LoadTextureToSlot(&PNG_001d1e33,0x38c1,&DAT_0050d888);
  Gui_LoadTextureToSlot(&PNG_001d56f4,0x641b,&DAT_0050d890);
  Gui_LoadTextureToSlot(&PNG_001dbb0f,0x6b71,&DAT_0050d8b8);
  Gui_LoadTextureToSlot(&PNG_001e2680,0x3228,&DAT_0050d8c0);
  Gui_LoadTextureToSlot(&PNG_001e58a8,0x1dd8,&DAT_0050d8a0);
  Gui_LoadTextureToSlot(&PNG_001e7680,0xc483,&DAT_0050d8a8);
  Gui_LoadTextureToSlot(&PNG_001f3b03,0x6060,&DAT_0050d8b0);
  Gui_LoadTextureToSlot(&PNG_001f9b63,0x4ff5,&DAT_0050d898);
  Gui_LoadTextureToSlot(&PNG_001feb58,0x15b81,&DAT_0050d8c8);
  Gui_LoadTextureToSlot(&PNG_002146d9,0x418c,&DAT_0050d8d0);
  Gui_LoadTextureToSlot(&PNG_00218865,0x97f,&DAT_0050d8d8);
  getcwd(&DAT_0050d900,0x200);
  if ((DAT_004f3314 == 0x7274706c6c756e) ||
     (__stream = fopen((char *)&DAT_004f3314,"r"), __stream == (FILE *)0x0)) {
    Gui_DecodeImage(&GIF_0039530e,0x5d193);
    Gui_SetExternalAsset(&DAT_0050d728,&local_b0);
    if (local_58 != (void *)0x0) {
      local_50 = local_58;
      free(local_58);
    }
    pvVar3 = local_70;
    if (local_70 != (void *)0x0) {
      while (pvVar2 = local_68, pvVar2 != pvVar3) {
        local_68 = (void *)((long)pvVar2 + -0x20);
        if ((*(byte *)((long)pvVar2 + -0x18) & 1) != 0) {
          free(*(void **)((long)pvVar2 + -8));
        }
      }
      local_68 = pvVar3;
      free(local_70);
    }
    if (local_98 != (void *)0x0) {
      local_90 = local_98;
      free(local_98);
    }
    if ((void *)CONCAT71(uStack175,local_b0) != (void *)0x0) {
      free((void *)CONCAT71(uStack175,local_b0));
    }
    DAT_0050d760 = 0;
  }
  else {
    fclose(__stream);
    Gui_LoadExternalAsset(&DAT_004f3314);
  }
  DAT_0050d8e0 = &GIF_0039530e;
  DAT_0050d8f0 = 0x5d193;
  if (*(long *)(lVar1 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  DAT_0050d8e0 = &GIF_0039530e;
  DAT_0050d8f0 = 0x5d193;
  return;
}

