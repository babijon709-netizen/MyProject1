/* Entry: 0x001e3b14; Ghidra function: Gui_ChoiceCombo */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_ChoiceCombo(float param_1,float param_2,float *param_3,long param_4,long param_5,
                    ulong param_6,long param_7)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  undefined auVar4 [16];
  undefined auVar5 [16];
  bool bVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  ulong uVar9;
  int iVar10;
  ulong uVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined4 uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined auVar18 [16];
  float fVar19;
  float fVar20;
  float local_d8;
  float fStack212;
  undefined8 local_d0;
  undefined8 uStack200;
  float local_c0;
  float fStack188;
  float local_b8;
  float local_b4;
  long local_b0;
  
  lVar2 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar2 + 0x28);
  fVar20 = param_2;
  uVar8 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar19 = fVar20;
  local_b8 = param_1;
  local_b4 = fVar20;
  fVar12 = param_1;
  ImGui_GetWindowPos();
  lVar1 = DAT_0050d8b0;
  if (param_7 != 0) {
    lVar1 = param_7;
  }
  if (param_4 != 0) {
    ImGui_CalcTextSize(0,param_4);
    local_c0 = 0.0;
    if (lVar1 != 0) {
      local_c0 = 55.0;
    }
    local_c0 = local_c0 + param_1 + 50.0;
    uStack200 = 0x3f8000003df0f0f2;
    local_d0 = 0x3df0f0f23df0f0f2;
    fStack188 = fVar20;
    uVar7 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    ImDrawList_AddText(uVar8,0,&local_c0,uVar7,param_4,0,0);
    if (lVar1 == 0) {
      fVar13 = 5.0;
    }
    else {
      Gui_DrawTexture(lVar1);
      fVar13 = 10.0;
    }
    local_b4 = fVar20 + fVar19 + fVar13;
    ImGui_SetCursorScreenPos(&local_b8);
    param_1 = local_b8;
    fVar20 = local_b4;
  }
  iVar10 = (int)(param_6 & 0xffffffff);
  fVar19 = (float)iVar10;
  fStack188 = (float)NEON_fmadd(param_2,fVar19,fVar20);
  local_c0 = fVar12 + param_1 + -20.0;
  local_d0 = CONCAT44(fVar20,param_1 + 20.0);
  uVar7 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(uVar8,&local_d0,&local_c0,uVar7,0);
  if (0 < iVar10) {
    fVar20 = param_2 * 0.5;
    uVar11 = 0;
    auVar18 = NEON_fmov(0x3f800000,4);
    auVar4 = _DAT_0012b530 >> 0x40;
    uVar16 = SUB168(_DAT_0012b530,0);
    auVar5 = _DAT_0012bbb0 >> 0x40;
    uVar17 = SUB168(_DAT_0012bbb0,0);
    do {
      if (uVar11 != 0) {
        local_c0 = local_b8 + 45.0;
        fStack212 = (float)NEON_fmadd(param_2,(float)(int)uVar11,local_b4);
        local_d8 = fVar12 + local_b8 + -20.0;
        local_d0 = uVar17;
        uStack200 = SUB168(auVar5,0);
        fStack188 = fStack212;
        uVar7 = ImGui_ColorConvertFloat4ToU32(&local_d0);
        ImDrawList_AddLine(uVar8,&local_c0,&local_d8,uVar7);
      }
      fVar13 = (float)(int)uVar11;
      uVar7 = NEON_fmadd(param_2,fVar13,local_b4);
      local_d0 = CONCAT44(uVar7,local_b8 + 20.0);
      ImGui_SetCursorScreenPos(&local_d0);
      local_d0 = CONCAT44(param_2,fVar12 + -40.0);
      uVar9 = ImGui_Button(*(undefined8 *)(param_5 + uVar11 * 8),&local_d0,0);
      if (((uVar9 & 1) == 0) || (DAT_0050e634 != '\0')) {
        fVar14 = *param_3;
      }
      else {
        *param_3 = fVar13;
        fVar14 = fVar13;
      }
      bVar6 = fVar14 != fVar13;
      uVar7 = 0x3f75f5f7;
      if (bVar6) {
        uVar7 = 0x3f800000;
      }
      uVar15 = 0x3f109091;
      if (bVar6) {
        uVar15 = 0x3f800000;
      }
      local_c0 = fVar20 + -8.0 + local_b8 + 45.0;
      uVar3 = 0;
      if (bVar6) {
        uVar3 = 0x3f800000;
      }
      fStack188 = (float)NEON_fmadd(param_2,fVar13,fVar20 + local_b4);
      uStack200 = CONCAT44(0x3f800000,uVar7);
      local_d0 = CONCAT44(uVar15,uVar3);
      fVar14 = local_c0;
      uVar7 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddCircle(uVar8,&local_c0,uVar7,0);
      if (*param_3 == fVar13) {
        local_c0 = fVar20 + -8.0 + local_b8 + 45.0;
        fStack188 = (float)NEON_fmadd(param_2,*param_3,fVar20 + local_b4);
        local_d0 = SUB168(auVar18,0);
        uStack200 = SUB168(auVar18 >> 0x40,0);
        fVar14 = local_c0;
        uVar7 = ImGui_ColorConvertFloat4ToU32(&local_d0);
        ImDrawList_AddCircle(uVar8,&local_c0,uVar7,0);
      }
      ImGui_CalcTextSize(0,*(undefined8 *)(param_5 + uVar11 * 8));
      fVar13 = (float)NEON_fmadd(param_2,fVar13,fVar20 + local_b4);
      local_c0 = local_b8 + 110.0;
      fStack188 = fVar13 + fVar14 * -0.5 + -1.0;
      local_d0 = uVar16;
      uStack200 = SUB168(auVar4,0);
      uVar7 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddText(uVar8,0,&local_c0,uVar7,*(undefined8 *)(param_5 + uVar11 * 8),0,0);
      uVar11 = uVar11 + 1;
    } while ((param_6 & 0xffffffff) != uVar11);
  }
  fVar20 = (float)NEON_fmadd(param_2,fVar19,local_b4);
  local_d0 = CONCAT44(fVar20 + 20.0,local_b8);
  ImGui_SetCursorScreenPos(&local_d0);
  if (*(long *)(lVar2 + 0x28) != local_b0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

