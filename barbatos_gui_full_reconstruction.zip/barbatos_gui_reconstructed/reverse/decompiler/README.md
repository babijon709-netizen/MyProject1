# Ghidra C-like pseudocode

- 53 selected functions; all rows in `index.tsv` have status `OK`.
- Every `.c` begins with the original ELF VA and assigned Ghidra analysis name.
- The Ghidra database used image base `0x00100000`; filenames report original ELF VA.
- This output is decompiler pseudocode, not guaranteed compilable C and not claimed to be the original source.
- Descriptive names were analytically assigned; use addresses as the stable identity.
