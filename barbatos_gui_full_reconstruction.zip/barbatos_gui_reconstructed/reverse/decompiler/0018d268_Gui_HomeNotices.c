/* Entry: 0x0018d268; Ghidra function: Gui_HomeNotices */


void Gui_HomeNotices(float param_1,float param_2,undefined8 *param_3)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined8 uVar11;
  float fVar12;
  undefined8 local_90;
  undefined8 uStack136;
  float local_80;
  float fStack124;
  long local_78;
  
  lVar1 = cRead_8(tpidr_el0);
  local_78 = *(long *)(lVar1 + 0x28);
  uVar3 = ImGui_GetWindowDrawList();
  fVar7 = (float)ImGui_GetCursorScreenPos();
  fVar8 = (float)ImGui_GetWindowPos();
  puVar4 = (undefined8 *)param_3[1];
  if ((undefined8 *)*param_3 != puVar4) {
    uVar11 = 0x3f000000;
    fVar12 = 0.0;
    puVar5 = (undefined8 *)*param_3;
    do {
      fVar10 = (float)uVar11;
      fVar9 = (float)ImGui_CalcTextSize(0x42200000,0,*puVar5);
      fStack124 = param_2 + param_1 + fVar12;
      local_80 = fVar7 + fVar8 * 0.5 + fVar9 * -0.5;
      uStack136 = 0x3f8000003df0f0f2;
      local_90 = 0x3df0f0f23df0f0f2;
      uVar2 = ImGui_ColorConvertFloat4ToU32(&local_90);
      uVar11 = 0;
      puVar6 = puVar5 + 1;
      ImDrawList_AddText(0x42200000,uVar3,0,&local_80,uVar2,*puVar5,0,0);
      fVar12 = fVar12 + fVar10 + 4.0;
      puVar5 = puVar6;
    } while (puVar6 != puVar4);
  }
  if (*(long *)(lVar1 + 0x28) == local_78) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

