/* Entry: 0x0018c248; Ghidra function: Gui_ValueEditor */


void Gui_ValueEditor(undefined4 param_1,float param_2,char *param_3,char *param_4,float *param_5,
                    undefined8 param_6,long param_7,long param_8)

{
  long lVar1;
  void *pvVar2;
  long lVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  undefined8 extraout_x1;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  ulong local_c0 [2];
  void *local_b0;
  float local_a8;
  float fStack164;
  undefined8 local_a0;
  undefined8 uStack152;
  long local_78;
  
  lVar3 = cRead_8(tpidr_el0);
  local_78 = *(long *)(lVar3 + 0x28);
  fVar11 = param_2;
  uVar6 = ImGui_GetWindowDrawList();
  fVar7 = (float)ImGui_GetCursorScreenPos();
  local_a8 = fVar7;
  fStack164 = fVar11;
  fVar10 = fVar11;
  fVar8 = (float)ImGui_GetWindowPos();
  if (param_7 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_7);
    fVar9 = 0.0;
    if (param_8 != 0) {
      fVar9 = 55.0;
    }
    uStack152 = 0x3f8000003df0f0f2;
    local_a0 = 0x3df0f0f23df0f0f2;
    local_c0[0] = CONCAT44(fVar11,fVar9 + fVar7 + 50.0);
    uVar4 = ImGui_ColorConvertFloat4ToU32(&local_a0);
    ImDrawList_AddText(0x421c0000,0,uVar6,0,local_c0,uVar4,param_7,0,0);
    if (param_8 == 0) {
      fVar7 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar7 + 70.0,fVar10 * 0.5 + fVar11 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_8);
      fVar7 = 10.0;
    }
    fStack164 = fVar11 + fVar10 + fVar7;
    ImGui_SetCursorScreenPos(&local_a8);
    fVar7 = local_a8;
    fVar11 = fStack164;
  }
  local_a0 = CONCAT44(fVar11,fVar7 + 20.0);
  local_c0[0] = CONCAT44(fVar11 + 81.0 + 20.0,fVar8 + fVar7 + -20.0);
  uVar4 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar6,&local_a0,local_c0,uVar4,0);
  fVar7 = (float)ImGui_GetWindowPos();
  ImGui_SetNextItemWidth(fVar7 + -80.0);
  local_a0 = CONCAT44(fStack164 + 10.0,local_a8 + 40.0);
  ImGui_SetCursorScreenPos(&local_a0);
  ImGui_SliderScalar(param_1,param_3,param_4,param_5,param_6,1);
  local_a0 = CONCAT44(fStack164 + 100.0 + 20.0,local_a8);
  ImGui_SetCursorScreenPos(&local_a0);
  *(char *)(DAT_00500b38 + 4) = *param_3;
  if ((*param_3 != '\0') &&
     (((s_Bnull_004d3e87._1_4_ ^ 0x6c6c756e | (uint)(byte)s_Bnull_004d3e87[5]) == 0 ||
      (iVar5 = strcmp(s_Bnull_004d3e87 + 1,param_4), iVar5 == 0)))) {
    __strcpy_chk(DAT_00500b38 + 0x50,param_4,0x80);
    FUN_0028c5e4((double)*param_5,&local_a0,extraout_x1,param_6);
    __strcpy_chk(DAT_00500b38 + 0xd0,&local_a0,0x80);
    __strcpy_chk(s_Bnull_004d3e87 + 1,param_4,0x80);
    lVar1 = DAT_00500b38 + 0x30;
    FUN_0036d0b0(param_2);
    pvVar2 = (void *)((ulong)local_c0 | 1);
    if ((local_c0[0] & 1) != 0) {
      pvVar2 = local_b0;
    }
    __strcpy_chk(lVar1,pvVar2,0x20);
    if ((local_c0[0] & 1) != 0) {
      free(local_b0);
    }
    lVar1 = DAT_00500b38 + 0x10;
    FUN_0036d0b0(param_1);
    pvVar2 = (void *)((ulong)local_c0 | 1);
    if ((local_c0[0] & 1) != 0) {
      pvVar2 = local_b0;
    }
    __strcpy_chk(lVar1,pvVar2,0x20);
    if ((local_c0[0] & 1) != 0) {
      free(local_b0);
    }
  }
  if (*(long *)(lVar3 + 0x28) != local_78) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

