/* Entry: 0x00151938; Ghidra function: Gui_InitializeFrameState */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_InitializeFrameState(void)

{
  long lVar1;
  undefined4 uVar2;
  int iVar3;
  long lVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  float fVar7;
  ulong uVar8;
  float fVar9;
  undefined8 uVar10;
  undefined8 local_88;
  undefined4 local_80;
  float local_7c;
  undefined8 local_78;
  undefined8 local_70;
  undefined8 local_68;
  float local_60;
  float fStack92;
  long local_58;
  
  lVar1 = cRead_8(tpidr_el0);
  local_58 = *(long *)(lVar1 + 0x28);
  if (((DAT_004f8158 & 1) == 0) && (iVar3 = FUN_0036eb48(&DAT_004f8158), iVar3 != 0)) {
    DAT_004f8150 = 0;
    DAT_004f8148 = 0;
    DAT_004f814c = 0.0;
    _DAT_004f8140 = 0x3f8666663df5c28f;
    FUN_0036eca0(&DAT_004f8158);
  }
  DAT_004f8148 = DAT_003950f8 ^ 1;
  DAT_004f8138 = &DAT_004f814c;
  lVar4 = ImGui_GetIO();
  fVar7 = DAT_004f814c;
  if (44.0 <= 1000.0 / (*(float *)(lVar4 + 0x10) * 1000.0)) {
    fVar9 = 0.0;
    if (DAT_004f8148 != 0) {
      fVar9 = 1.0;
    }
    lVar4 = ImGui_GetIO();
    fVar7 = (float)NEON_fmadd(*(float *)(lVar4 + 0x10) / DAT_004f8140,fVar9 - DAT_004f814c,fVar7);
    fVar9 = (float)NEON_fmin(fVar7,0x3f800000);
    DAT_004f814c = 0.0;
    if (0.0 <= fVar7) {
      DAT_004f814c = fVar9;
    }
  }
  uVar8 = (ulong)(uint)(DAT_004f814c * 100.0);
  uVar10 = 0;
  uVar5 = FUN_00295488();
  fVar7 = (float)((ulong)DAT_004f8160 >> 0x20);
  fVar9 = (float)uVar8;
  local_60 = (float)DAT_004f8160 - fVar9;
  fStack92 = fVar7 - fVar9;
  local_68 = CONCAT44(fVar9 + fVar7 + (float)((ulong)DAT_004f8168 >> 0x20),
                      fVar9 + (float)DAT_004f8160 + (float)DAT_004f8168);
  if (((DAT_0050d780 != DAT_0050d788) && (0.01 < DAT_004f814c)) && (DAT_004f814c < 0.99)) {
    if (0.1 <= DAT_004f814c) {
      if (0.2 <= DAT_004f814c) {
        if (DAT_004f814c < 0.3) {
          uVar6 = DAT_0050d780[2];
        }
        else if (DAT_004f814c < 0.4) {
          uVar6 = DAT_0050d780[3];
        }
        else if (DAT_004f814c < 0.5) {
          uVar6 = DAT_0050d780[4];
        }
        else if (DAT_004f814c < 0.6) {
          uVar6 = DAT_0050d780[5];
        }
        else if (0.7 <= DAT_004f814c) {
          uVar6 = DAT_0050d780[7];
        }
        else {
          uVar6 = DAT_0050d780[6];
        }
      }
      else {
        uVar6 = DAT_0050d780[1];
      }
      local_78 = NEON_fmov(0x3f800000,4);
    }
    else {
      uVar6 = *DAT_0050d780;
      local_78 = NEON_fmov(0x3f800000,4);
    }
    local_70 = 0;
    local_80 = 0x3f800000;
    local_7c = (float)(0xff - (int)(DAT_004f814c * 255.0)) * 0.003921569;
    local_88 = local_78;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_88);
    ImDrawList_AddRectFilledMultiColor
              (DAT_00395168,uVar5,uVar6,&local_60,&local_68,&local_70,&local_78,uVar2,0,uVar8,uVar10
              );
  }
  if (*(long *)(lVar1 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

