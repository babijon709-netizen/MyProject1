/* Entry: 0x0018ae40; Ghidra function: Gui_ToggleRows */


void Gui_ToggleRows(undefined4 param_1,float param_2,long param_3,int *param_4,undefined8 *param_5,
                   undefined8 *param_6,int *param_7,ulong param_8,long param_9,long param_10)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  ulong uVar4;
  ulong uVar5;
  int iVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float local_d8;
  undefined4 uStack212;
  undefined8 local_d0;
  undefined8 uStack200;
  float local_b8;
  float fStack180;
  float local_b0;
  float local_ac;
  long local_a8;
  
  lVar1 = cRead_8(tpidr_el0);
  local_a8 = *(long *)(lVar1 + 0x28);
  fVar10 = param_2;
  uVar3 = ImGui_GetWindowDrawList();
  fVar7 = (float)ImGui_GetCursorScreenPos();
  fVar9 = fVar10;
  local_b0 = fVar7;
  local_ac = fVar10;
  fVar8 = (float)ImGui_GetWindowPos();
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_b8 = 0.0;
    if (param_10 != 0) {
      local_b8 = 55.0;
    }
    local_b8 = local_b8 + fVar7 + 50.0;
    uStack200 = 0x3f8000003df0f0f2;
    local_d0 = 0x3df0f0f23df0f0f2;
    fStack180 = fVar10;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
    ImDrawList_AddText(0x421c0000,uVar3,0,&local_b8,uVar2,param_3,0,0);
    if (param_10 == 0) {
      fVar7 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar7 + 70.0,fVar9 * 0.5 + fVar10 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_10);
      fVar7 = 10.0;
    }
    local_ac = fVar10 + fVar9 + fVar7;
    ImGui_SetCursorScreenPos(&local_b0);
    fVar7 = local_b0;
    fVar10 = local_ac;
  }
  iVar6 = (int)(param_8 & 0xffffffff);
  local_b8 = fVar8 + fVar7 + -20.0;
  fStack180 = (float)NEON_fmadd(param_2,(float)iVar6,fVar10);
  local_d0 = CONCAT44(fVar10,fVar7 + 20.0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar3,&local_d0,&local_b8,uVar2,0);
  if (0 < iVar6) {
    uVar4 = Gui_ToggleRowCore(param_1,*param_5,*param_6,param_9);
    if (((uVar4 & 1) != 0) && (*param_4 == -1)) {
      *param_4 = *param_7;
    }
    if (iVar6 != 1) {
      param_9 = param_9 + 0x10;
      uVar4 = 1;
      do {
        local_b8 = local_b0 + 45.0;
        uStack212 = NEON_fmadd(param_2,(float)(int)uVar4,local_ac);
        local_d8 = fVar8 + local_b0 + -20.0;
        uStack200 = 0x3f8000003f028283;
        local_d0 = 0x3f0282833f028283;
        fStack180 = (float)uStack212;
        uVar2 = ImGui_ColorConvertFloat4ToU32(&local_d0);
        ImDrawList_AddLine(0x3fc00000,uVar3,&local_b8,&local_d8,uVar2);
        uVar5 = Gui_ToggleRowCore(param_1,param_5[uVar4],param_6[uVar4],param_9);
        if (((uVar5 & 1) != 0) && (*param_4 == -1)) {
          *param_4 = param_7[uVar4];
        }
        uVar4 = uVar4 + 1;
        param_9 = param_9 + 0x10;
      } while ((param_8 & 0xffffffff) != uVar4);
    }
  }
  fVar7 = (float)NEON_fmadd(param_2,(float)iVar6,local_ac);
  local_d0 = CONCAT44(fVar7 + 20.0,local_b0);
  ImGui_SetCursorScreenPos(&local_d0);
  if (*(long *)(lVar1 + 0x28) == local_a8) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

