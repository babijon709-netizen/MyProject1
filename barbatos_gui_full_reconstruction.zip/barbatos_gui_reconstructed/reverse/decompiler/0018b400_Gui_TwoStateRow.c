/* Entry: 0x0018b400; Ghidra function: Gui_TwoStateRow */


void Gui_TwoStateRow(undefined4 param_1,float param_2,long param_3,undefined8 param_4,
                    undefined8 param_5,undefined8 param_6,long param_7)

{
  long lVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined8 local_b0;
  undefined8 uStack168;
  float local_98;
  float fStack148;
  float local_90;
  float local_8c;
  long local_88;
  
  lVar1 = cRead_8(tpidr_el0);
  local_88 = *(long *)(lVar1 + 0x28);
  fVar7 = param_2;
  uVar3 = ImGui_GetWindowDrawList();
  fVar4 = (float)ImGui_GetCursorScreenPos();
  fVar6 = fVar7;
  local_90 = fVar4;
  local_8c = fVar7;
  fVar5 = (float)ImGui_GetWindowPos();
  if (param_3 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_3);
    local_98 = 0.0;
    if (param_7 != 0) {
      local_98 = 55.0;
    }
    local_98 = local_98 + fVar4 + 50.0;
    uStack168 = 0x3f8000003df0f0f2;
    local_b0 = 0x3df0f0f23df0f0f2;
    fStack148 = fVar7;
    uVar2 = ImGui_ColorConvertFloat4ToU32(&local_b0);
    ImDrawList_AddText(0x421c0000,uVar3,0,&local_98,uVar2,param_3,0,0);
    if (param_7 == 0) {
      fVar4 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar4 + 70.0,fVar6 * 0.5 + fVar7 + -1.0,0x41c00000,0x3f800000,0x3f800000,
                      param_7);
      fVar4 = 10.0;
    }
    local_8c = fVar7 + fVar6 + fVar4;
    ImGui_SetCursorScreenPos(&local_90);
    fVar4 = local_90;
    fVar7 = local_8c;
  }
  local_98 = fVar5 + fVar4 + -20.0;
  fStack148 = param_2 + fVar7;
  local_b0 = CONCAT44(fVar7,fVar4 + 20.0);
  uVar2 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar3,&local_b0,&local_98,uVar2,0);
  Gui_ToggleRowCore(param_1,param_4,param_5,param_6);
  local_b0 = CONCAT44(param_2 + local_8c + 20.0,local_90);
  ImGui_SetCursorScreenPos(&local_b0);
  if (*(long *)(lVar1 + 0x28) == local_88) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

