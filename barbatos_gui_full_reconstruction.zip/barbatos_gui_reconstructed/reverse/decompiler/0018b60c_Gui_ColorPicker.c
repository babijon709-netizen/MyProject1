/* Entry: 0x0018b60c; Ghidra function: Gui_ColorPicker */


void Gui_ColorPicker(undefined8 param_1,float param_2,undefined8 *param_3,long param_4,int param_5,
                    undefined4 *param_6,undefined4 param_7,long param_8,long param_9)

{
  undefined *puVar1;
  void *pvVar2;
  char *pcVar3;
  long lVar4;
  byte bVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  long lVar8;
  float *pfVar9;
  ulong uVar10;
  int iVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  ulong local_e0;
  undefined8 uStack216;
  void *local_d0;
  undefined8 local_c0;
  float local_b8;
  float fStack180;
  long local_b0;
  
  lVar4 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar4 + 0x28);
  fVar19 = param_2;
  uVar7 = ImGui_GetWindowDrawList();
  fVar12 = (float)ImGui_GetCursorScreenPos();
  fVar16 = fVar19;
  local_b8 = fVar12;
  fStack180 = fVar19;
  fVar13 = (float)ImGui_GetWindowPos();
  if (param_4 != 0) {
    ImGui_CalcTextSize(0x421c0000,0,param_4);
    fVar20 = 0.0;
    if (param_9 != 0) {
      fVar20 = 55.0;
    }
    uStack216 = 0x3f8000003df0f0f2;
    local_e0 = 0x3df0f0f23df0f0f2;
    local_c0 = CONCAT44(fVar19,fVar20 + fVar12 + 50.0);
    uVar6 = ImGui_ColorConvertFloat4ToU32(&local_e0);
    ImDrawList_AddText(0x421c0000,uVar7,0,&local_c0,uVar6,param_4,0,0);
    if (param_9 == 0) {
      fVar12 = 5.0;
    }
    else {
      Gui_DrawTexture(fVar12 + 70.0,param_9);
      fVar12 = 10.0;
    }
    fStack180 = fVar19 + fVar16 + fVar12;
    ImGui_SetCursorScreenPos(&local_b8);
    fVar12 = local_b8;
    fVar19 = fStack180;
  }
  fVar16 = fVar13 + fVar12;
  fVar17 = (float)param_5;
  fVar18 = fVar16 + -20.0;
  fVar20 = (float)NEON_fmadd(param_2,fVar17,fVar19);
  local_e0 = CONCAT44(fVar19,fVar12 + 20.0);
  ImGui_CalcTextSize(0x42140000,0,&DAT_0011b5a3);
  fVar20 = fVar20 + fVar16;
  local_c0 = CONCAT44(fVar20 + 27.0,fVar18);
  uVar6 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e4f0);
  ImDrawList_AddRectFilled(0x41400000,uVar7,&local_e0,&local_c0,uVar6,0);
  pcVar3 = &UNK_00129d15;
  if (DAT_004f3d14 != 0) {
    pcVar3 = "My Color";
  }
  ImGui_CalcTextSize(0x42180000,0,pcVar3);
  fVar12 = param_2 * 0.5;
  local_c0 = CONCAT44(((fVar12 + fStack180) - fVar20 * 0.5) + -1.0,local_b8 + 45.0);
  uStack216 = 0x3f8000003df0f0f2;
  local_e0 = 0x3df0f0f23df0f0f2;
  uVar6 = ImGui_ColorConvertFloat4ToU32(&local_e0);
  ImDrawList_AddText(0x42180000,0,uVar7,0,&local_c0,uVar6,pcVar3,0,0);
  iVar11 = 0;
  uVar10 = 0;
  pfVar9 = (float *)(param_8 + 0xc);
  uVar14 = NEON_fmov(0x40a00000,4);
  do {
    fVar16 = *pfVar9;
    fVar19 = 0.0;
    if (*(char *)(pfVar9 + -1) != '\0') {
      fVar19 = 1.0;
    }
    lVar8 = ImGui_GetIO();
    if (DAT_0050e608 == '\0') {
      DAT_0050e608 = '\x01';
      fVar19 = pfVar9[-3];
    }
    else {
      fVar16 = (float)NEON_fmadd(*(float *)(lVar8 + 0x10) / pfVar9[-2],fVar19 - *pfVar9,fVar16);
      fVar20 = (float)NEON_fmin(fVar16,0x3f800000);
      fVar19 = 0.0;
      if (0.0 <= fVar16) {
        fVar19 = fVar20;
      }
    }
    *pfVar9 = fVar19;
    if (0.8 < fVar19) {
      *(undefined *)(pfVar9 + -1) = 0;
    }
    fVar19 = 22.0 - fVar19 * 7.0;
    if (uVar10 == 0) {
      Gui_DrawTexture(fVar13 + local_b8 + -67.0,fVar12 + fStack180,0x41b00000,0x3f800000,0x3f800000,
                      DAT_0050d890);
      puVar1 = &DAT_0011b5a3;
      if (DAT_004f3d14 != 0) {
        puVar1 = &DAT_0011ee3e;
      }
      fVar16 = (float)ImGui_CalcTextSize(0x42140000,0,puVar1);
      local_c0 = CONCAT44(fVar12 + fStack180 + 22.0 + (float)((ulong)uVar14 >> 0x20),
                          (fVar13 + local_b8 + -67.0) - fVar16 * 0.5);
      uStack216 = 0x3f8000003ea0a0a1;
      local_e0 = 0x3ea0a0a13ea0a0a1;
      uVar6 = ImGui_ColorConvertFloat4ToU32(&local_e0);
      fVar16 = 0.0;
      ImDrawList_AddText(0x42140000,uVar7,0,&local_c0,uVar6,puVar1,0,0);
    }
    else {
      fVar16 = (float)iVar11;
      local_e0 = CONCAT44(fVar12 + fStack180,(fVar13 + local_b8 + -67.0) - fVar16);
      uVar6 = ImGui_ColorConvertFloat4ToU32(&DAT_0050e510 + (ulong)((int)uVar10 - 1) * 0x10);
      ImDrawList_AddCircle(fVar19,uVar7,&local_e0,uVar6,0);
    }
    local_c0 = CONCAT44(fVar12 + fStack180,(fVar13 + local_b8 + -67.0) - fVar16);
    uStack216 = 0x3f8000003eb33333;
    local_e0 = 0x3eb333333eb33333;
    uVar6 = ImGui_ColorConvertFloat4ToU32(&local_e0);
    FUN_002aec5c(fVar19,uVar7,&local_c0,uVar6,0);
    fVar19 = fStack180 + 8.0;
    local_e0 = CONCAT44(fVar19,((fVar13 + local_b8 + -67.0) - fVar16) + -26.0);
    ImGui_SetCursorScreenPos(&local_e0);
    FUN_0036ce38(uVar10 & 0xffffffff);
    local_c0 = 0x4240000042500000;
    pvVar2 = (void *)((ulong)&local_e0 | 1);
    if ((local_e0 & 1) != 0) {
      pvVar2 = local_d0;
    }
                    /* try { // try from 0028bb8c to 0028bb97 has its CatchHandler @ 0028bdb8 */
    bVar5 = ImGui_Button(pvVar2,&local_c0,0);
    if ((local_e0 & 1) != 0) {
      free(local_d0);
    }
    if ((bVar5 & DAT_0050e634 == '\0') == 1) {
      if (uVar10 == 0) {
        *param_6 = param_7;
      }
      else {
        lVar8 = (ulong)((int)uVar10 - 1) * 0x10;
        uVar15 = *(undefined8 *)(&DAT_0050e510 + lVar8);
        param_3[1] = *(undefined8 *)(lVar8 + 0x50e518);
        *param_3 = uVar15;
      }
      *(undefined *)(pfVar9 + -1) = 1;
    }
    uVar10 = uVar10 + 1;
    iVar11 = iVar11 + 0x37;
    pfVar9 = pfVar9 + 4;
  } while (uVar10 != 9);
  pcVar3 = &UNK_00122061;
  if (DAT_004f3d14 != 0) {
    pcVar3 = "Now Settings Color";
  }
  fVar16 = (float)ImGui_CalcTextSize(0x42180000,0,pcVar3);
  local_c0 = CONCAT44(param_2 + fVar12 + fStack180 + fVar19 * -0.5 + -1.0,local_b8 + 45.0);
  uStack216 = 0x3f8000003df0f0f2;
  local_e0 = 0x3df0f0f23df0f0f2;
  uVar6 = ImGui_ColorConvertFloat4ToU32(&local_e0);
  ImDrawList_AddText(0x42180000,uVar7,0,&local_c0,uVar6,pcVar3,0,0);
  local_e0 = CONCAT44(param_2 + fVar12 + fStack180,fVar16 + local_b8 + 35.0 + 55.0);
  uVar6 = ImGui_ColorConvertFloat4ToU32(param_3);
  ImDrawList_AddCircle(0x41b00000,uVar7,&local_e0,uVar6,0);
  local_c0 = CONCAT44(param_2 + fVar12 + fStack180,fVar16 + local_b8 + 35.0 + 55.0);
  uStack216 = 0x3f8000003eb33333;
  local_e0 = 0x3eb333333eb33333;
  uVar6 = ImGui_ColorConvertFloat4ToU32(&local_e0);
  FUN_002aec5c(0x41b00000,uVar7,&local_c0,uVar6,0);
  fVar12 = local_b8;
  fVar19 = (float)NEON_fmadd(param_2,fVar17,fStack180);
  ImGui_CalcTextSize(0x42140000,0,&DAT_0011b5a3);
  local_e0 = CONCAT44(fVar19 + fVar17 + 27.0 + 20.0,fVar12);
  ImGui_SetCursorScreenPos(&local_e0);
  if (*(long *)(lVar4 + 0x28) != local_b0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

