/* Entry: 0x001eb820; Ghidra function: Gui_PathSelection */


void Gui_PathSelection(int *param_1,ulong **param_2)

{
  long lVar1;
  ulong uVar2;
  ulong *puVar3;
  ulong *puVar4;
  int iVar5;
  undefined auVar6 [16];
  undefined8 uVar7;
  undefined8 local_c0;
  undefined8 uStack184;
  ulong local_b0;
  undefined8 uStack168;
  undefined8 local_a0;
  undefined8 local_98;
  undefined8 local_90;
  long local_88;
  
  lVar1 = cRead_8(tpidr_el0);
  local_88 = *(long *)(lVar1 + 0x28);
  ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  ImGui_GetWindowPos();
  puVar3 = *param_2;
  puVar4 = param_2[1];
  if (puVar3 != puVar4) {
    auVar6 = NEON_fmov(0x3f800000,4);
    uVar7 = NEON_fmov(0x3f800000,4);
    iVar5 = 0;
    do {
      ImGui_GetCursorScreenPos();
      local_90 = 0x4348000043480000;
      local_98 = 0;
      local_b0 = 0;
      uStack168 = 0;
      local_c0 = SUB168(auVar6,0);
      uStack184 = SUB168(auVar6 >> 0x40,0);
      local_a0 = uVar7;
      uVar2 = FUN_002bf678(*puVar3,&local_90,&local_98,&local_a0,0xffffffff,&local_b0,&local_c0);
      if ((uVar2 & 1) != 0) {
        *param_1 = iVar5;
        DAT_0050d760 = 1;
        local_b0 = local_b0 & 0xffffffff00000000 | *puVar3 & 0xffffffff;
        FUN_002ec420(&DAT_0050d728,DAT_0050d728,&local_b0);
        uVar2 = (long)puVar3 + 9;
        if ((*(byte *)(puVar3 + 1) & 1) != 0) {
          uVar2 = puVar3[3];
        }
        __strcpy_chk(&DAT_004f3314,uVar2,0x100);
      }
      if (iVar5 == *param_1) {
        Gui_DrawTexture(DAT_0050d8a0);
      }
      iVar5 = iVar5 + 1;
      puVar3 = puVar3 + 4;
    } while (puVar3 != puVar4);
  }
  if (*(long *)(lVar1 + 0x28) == local_88) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

