/* Entry: 0x001e8090; Ghidra function: Gui_RenderSettingsPage */


/* WARNING: Could not reconcile some variable overlaps */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_RenderSettingsPage(void)

{
  byte *pbVar1;
  char *pcVar2;
  long lVar3;
  void *pvVar4;
  bool bVar5;
  undefined2 uVar6;
  undefined2 uVar7;
  void *pvVar8;
  undefined4 uVar9;
  uint uVar10;
  int iVar11;
  long lVar12;
  undefined8 uVar13;
  ulong uVar14;
  ulong uVar15;
  undefined *puVar16;
  size_t sVar17;
  char *pcVar18;
  undefined8 *puVar19;
  long lVar20;
  byte *pbVar21;
  byte *pbVar22;
  byte *pbVar23;
  ulong uVar24;
  long lVar25;
  undefined *puVar26;
  undefined8 *puVar27;
  undefined8 *puVar28;
  byte *pbVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  char *pcVar33;
  undefined8 uVar34;
  undefined auVar35 [16];
  float fVar36;
  float fVar37;
  undefined4 uVar38;
  float fVar39;
  float fVar40;
  undefined *puVar41;
  undefined8 local_398;
  float local_390;
  float fStack908;
  float local_388;
  float fStack900;
  undefined8 local_380;
  undefined8 uStack888;
  float local_368;
  float fStack868;
  char *local_360;
  float fStack856;
  undefined2 uStack852;
  undefined2 uStack850;
  undefined6 uStack848;
  undefined2 uStack842;
  undefined *puStack840;
  undefined *local_340;
  undefined *local_338;
  undefined8 local_330;
  undefined8 uStack808;
  undefined8 uStack800;
  undefined8 uStack792;
  undefined8 local_310;
  undefined8 uStack776;
  undefined8 local_300;
  undefined8 uStack760;
  undefined8 uStack752;
  undefined8 uStack744;
  undefined8 local_2e0;
  undefined8 uStack728;
  undefined8 uStack720;
  undefined8 uStack712;
  undefined8 local_2c0;
  undefined8 uStack696;
  undefined8 uStack688;
  undefined8 uStack680;
  undefined8 local_2a0;
  undefined8 uStack664;
  undefined8 uStack656;
  undefined8 uStack648;
  undefined8 local_280;
  undefined8 uStack632;
  undefined8 uStack624;
  undefined8 uStack616;
  undefined *local_160;
  undefined8 *puStack344;
  undefined *local_150;
  undefined8 local_140;
  float *pfStack312;
  float *local_130;
  undefined *local_128;
  undefined *local_120;
  undefined *puStack280;
  void *local_100;
  void *local_f8;
  void *local_e8;
  void *local_e0;
  long local_b8;
  
  lVar3 = cRead_8(tpidr_el0);
  local_b8 = *(long *)(lVar3 + 0x28);
  if (((DAT_0050ff00 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ff00), iVar11 != 0)) {
    DAT_0050fef4 = '\0';
    DAT_0050fef8 = 0.0;
    DAT_0050fef0 = 0.08;
    FUN_0036eca0(&DAT_0050ff00);
  }
  lVar12 = ImGui_GetIO();
  fVar30 = DAT_0050fef8;
  if (44.0 <= 1000.0 / (*(float *)(lVar12 + 0x10) * 1000.0)) {
    fVar36 = 0.0;
    if (DAT_0050fef4 != '\0') {
      fVar36 = 1.0;
    }
    lVar12 = ImGui_GetIO();
    fVar30 = (float)NEON_fmadd(*(float *)(lVar12 + 0x10) / DAT_0050fef0,fVar36 - DAT_0050fef8,fVar30
                              );
    fVar36 = (float)NEON_fmin(fVar30,0x3f800000);
    DAT_0050fef8 = 0.0;
    if (0.0 <= fVar30) {
      DAT_0050fef8 = fVar36;
    }
  }
  if (((DAT_0050ff18 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ff18), iVar11 != 0)) {
    DAT_0050ff10 = 0.0;
    DAT_0050ff0c = '\0';
    DAT_0050ff08 = 0.08;
    FUN_0036eca0(&DAT_0050ff18);
  }
  lVar12 = ImGui_GetIO();
  fVar30 = DAT_0050ff10;
  if (44.0 <= 1000.0 / (*(float *)(lVar12 + 0x10) * 1000.0)) {
    fVar36 = 1.0;
    if (DAT_0050ff0c == '\0') {
      fVar36 = 0.0;
    }
    lVar12 = ImGui_GetIO();
    fVar30 = (float)NEON_fmadd(*(float *)(lVar12 + 0x10) / DAT_0050ff08,fVar36 - DAT_0050ff10,fVar30
                              );
    fVar36 = (float)NEON_fmin(fVar30,0x3f800000);
    DAT_0050ff10 = 0.0;
    if (0.0 <= fVar30) {
      DAT_0050ff10 = fVar36;
    }
  }
  if (((DAT_0050ff30 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ff30), iVar11 != 0)) {
    DAT_0050ff24 = '\0';
    DAT_0050ff28 = 0.0;
    DAT_0050ff20 = 0.08;
    FUN_0036eca0(&DAT_0050ff30);
  }
  lVar12 = ImGui_GetIO();
  fVar30 = DAT_0050ff28;
  fVar36 = 1000.0 / (*(float *)(lVar12 + 0x10) * 1000.0);
  uVar15 = (ulong)(uint)fVar36;
  fVar37 = 44.0;
  if (44.0 <= fVar36) {
    fVar36 = 1.0;
    if (DAT_0050ff24 == '\0') {
      fVar36 = 0.0;
    }
    lVar12 = ImGui_GetIO();
    fVar30 = (float)NEON_fmadd(*(float *)(lVar12 + 0x10) / DAT_0050ff20,fVar36 - DAT_0050ff28,fVar30
                              );
    fVar37 = (float)NEON_fmin(fVar30,0x3f800000);
    uVar15 = 0;
    if (0.0 <= fVar30) {
      uVar15 = (ulong)(uint)fVar37;
    }
    DAT_0050ff28 = (float)uVar15;
  }
  local_360 = (char *)0x0;
  DAT_0050fef4 = DAT_004d7040 != -1;
  ImGui_BeginChild("##Settingright",&local_360,0,0x800008);
  FUN_00292020();
  uVar13 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar36 = fVar37;
  fVar39 = fVar31;
  ImGui_GetWindowPos();
  fVar31 = (float)uVar15;
  fVar40 = fVar31 + fVar39;
  local_140 = (undefined8 *)(uVar15 & 0xffffffff | (ulong)(uint)fVar37 << 0x20);
  auVar35 = NEON_fmov(0x3f800000,4);
  local_160 = (undefined *)CONCAT44(fVar37 + fVar36,fVar40);
  pcVar33 = SUB168(auVar35,0);
  fStack856 = SUB164(auVar35 >> 0x40,0);
  fVar30 = fStack856;
  uStack852 = SUB162(auVar35 >> 0x60,0);
  uVar6 = uStack852;
  uStack850 = SUB162(auVar35 >> 0x70,0);
  uVar7 = uStack850;
  local_360 = pcVar33;
  uVar9 = ImGui_ColorConvertFloat4ToU32(pcVar33,&local_360);
  ImDrawList_AddRectFilled(uVar13,&local_140,&local_160,uVar9,0xa0);
  if (DAT_0050d8d8 != 0) {
    local_140 = (undefined8 *)CONCAT44(fVar37 + fVar36,fVar40);
    local_360 = (char *)(uVar15 & 0xffffffff | (ulong)(uint)fVar37 << 0x20);
    FUN_002791f4(&local_360,&local_140,0xa0);
    FUN_002514f8(DAT_0050d8d8);
    FUN_00279398();
  }
  fVar36 = 3.0;
  if (3.0 < DAT_0050feec) {
    local_140 = (undefined8 *)(uVar15 & 0xffffffff | (ulong)(uint)fVar37 << 0x20);
    fVar36 = 0.9019608;
    fStack856 = 0.9019608;
    uStack852 = 0x9b9c;
    uStack850 = 0x3f1b;
    local_360 = (char *)0x3f66e6e83f66e6e8;
    local_160 = (undefined *)CONCAT44(fVar37 + DAT_00395104,fVar40);
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
    ImDrawList_AddRectFilled(uVar13,&local_140,&local_160,uVar9,0x20);
  }
  pcVar18 = &UNK_0012084a;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "Settings";
  }
  fVar32 = 55.0;
  ImGui_CalcTextSize(0,pcVar18);
  local_140 = (undefined8 *)
              CONCAT44(fVar37 + 39.0 + fVar36 * -0.5,fVar31 + fVar39 * 0.5 + fVar32 * -0.5);
  fStack856 = 0.1176471;
  uStack852 = 0;
  uStack850 = 0x3f80;
  local_360 = (char *)0x3df0f0f23df0f0f2;
  uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
  fVar31 = 0.0;
  pcVar18 = &UNK_0012084a;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "Settings";
  }
  fVar36 = 0.0;
  ImDrawList_AddText(uVar13,0,&local_140,uVar9,pcVar18,0,0);
  fVar32 = DAT_00395104;
  ImGui_SetCursorPosY();
  local_360 = (char *)0x0;
  ImGui_BeginChild("##Settingcentre",&local_360,0,0x80000c);
  ImGui_GetCursorScreenPos();
  fVar39 = fVar32;
  lVar12 = ImGui_GetWindowDrawList();
  if (DAT_004d7040 == -1) {
    fVar36 = fVar39;
    Gui_OverlayStateBegin(0);
    Gui_OverlayStateEnd(0);
    Gui_OverlayAnimation(0);
  }
  local_360 = (char *)CONCAT44(fVar31 + fVar36 + 10.0,fVar32);
  ImGui_SetCursorScreenPos(&local_360);
  local_360 = &UNK_0012707c;
  fStack856 = (float)0x120f8c;
  if (DAT_004f3d14 != 0) {
    local_360 = "Leave Procs Run [KSU Self-contained]";
    fStack856 = (float)0x129607;
  }
  uStack852 = 0;
  uStack850 = 0;
  pfStack312 = SUB168(_PTR_DAT_0038c570 >> 0x40,0);
  local_140 = SUB168(_PTR_DAT_0038c570,0);
  if (((DAT_0050ff58 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ff58), iVar11 != 0)) {
    DAT_0050ff45 = DAT_004f32d8;
    DAT_0050ff44 = 0;
    DAT_0050ff55 = DAT_004f32d9;
    DAT_0050ff40 = 0x3da3d70a;
    DAT_0050ff50 = 0x3da3d70a;
    DAT_0050ff54 = 0;
    DAT_0050ff38 = 0;
    if (DAT_004f32d8 != '\0') {
      DAT_0050ff38 = 0x3f800000;
    }
    DAT_0050ff48 = 0;
    if (DAT_004f32d9 != '\0') {
      DAT_0050ff48 = 0x3f800000;
    }
    DAT_0050ff3c = DAT_0050ff38;
    DAT_0050ff4c = DAT_0050ff48;
    FUN_0036eca0(&DAT_0050ff58);
  }
  pcVar18 = &UNK_00129f6f;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "Main Settings";
  }
  Gui_ToggleGroup(pcVar18,&local_360,&local_140,2,&DAT_0050ff38,DAT_0050d868);
  pcVar18 = &UNK_0012a820;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "Language Mode";
  }
  fStack856 = SUB164(_PTR_DAT_0038c580 >> 0x40,0);
  uStack852 = SUB162(_PTR_DAT_0038c580 >> 0x60,0);
  uStack850 = SUB162(_PTR_DAT_0038c580 >> 0x70,0);
  local_360 = SUB168(_PTR_DAT_0038c580,0);
  Gui_LanguageChoice(&DAT_004f3d14,pcVar18,&local_360,2,DAT_0050d870);
  local_360 = &UNK_0012860c;
  if (DAT_004f3d14 != 0) {
    local_360 = "More";
  }
  pcVar18 = &UNK_001233d8;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "Main | Island | Photo | Text | Dynamic";
  }
  local_140._0_4_ = 0x378;
  Gui_ChoiceGroup(&DAT_004d7040,pcVar18,&local_360,&local_140,1,DAT_0050d878);
  local_360 = &UNK_00119508;
  if (DAT_004f3d14 != 0) {
    local_360 = "Look Data";
  }
  fVar31 = 83.0;
  pcVar18 = &UNK_0012685f;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "GameData";
  }
  local_140 = (undefined8 *)CONCAT44(local_140._4_4_,0x309);
  Gui_ChoiceGroup(&DAT_004d7040,pcVar18,&local_360,&local_140,1,DAT_0050d7c0);
  if (((DAT_0050ff70 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ff70), iVar11 != 0)) {
    DAT_0050ff60 = 0;
    DAT_0050ff64 = 0;
    DAT_0050ff68 = 0;
    DAT_0050ff68 = FUN_0034a23c();
    FUN_0036eca0(&DAT_0050ff70);
  }
  pcVar18 = &UNK_00126015;
  pcVar2 = &UNK_0011d995;
  if (DAT_004f3d14 != 0) {
    pcVar18 = "Exit & Save Configuration";
    pcVar2 = "Kernel Exit";
  }
  local_360 = (char *)0x427c000042a60000;
  uVar14 = Gui_TimedActionButton(pcVar2,pcVar18,&local_360,DAT_0050d7c0,&DAT_0050ff60);
  if ((uVar14 & 1) != 0) {
    DAT_003950f4 = 0;
  }
  ImGui_GetScrollY();
  DAT_0050feec = fVar31;
  ImGui_EndChild();
  if ((lVar12 != 0) && (3.0 < DAT_0050feec)) {
    fVar31 = fVar37 + DAT_00395104 + 1.5;
    local_140 = (undefined8 *)(uVar15 & 0xffffffff | (ulong)(uint)fVar31 << 0x20);
    local_160 = (undefined *)CONCAT44(fVar31,fVar40);
    fStack856 = 0.627451;
    uStack852 = 0;
    uStack850 = 0x3f80;
    local_360 = (char *)0x3f20a0a13f20a0a1;
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
    ImDrawList_AddLine(lVar12,&local_140,&local_160,uVar9);
  }
  ImGui_EndChild();
  puVar41 = (undefined *)NEON_fmov(0x3f800000,4);
  if ((DAT_0050fef4 == '\0') || (DAT_0039516c != '\0')) {
    if (DAT_0039516c != '\0') goto LAB_002e8800;
  }
  else {
    DAT_00395170 = Gui_RenderImageLayer
                             ("Hello ImGui",&DAT_004f8160,&DAT_004f8168,(int)DAT_00395174,4);
    _DAT_0039516c = 0x101;
LAB_002e8800:
    local_360 = (char *)0x0;
    ImGui_SetCursorPos(&local_360);
    local_360 = (char *)0x0;
    ImGui_BeginChild("##BottomBlur",&local_360,0,0x800008);
    uVar13 = ImGui_GetWindowDrawList();
    local_140 = (undefined8 *)0x0;
    local_360 = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                                 (float)DAT_004f8160 + (float)DAT_004f8168);
    local_160 = puVar41;
    ImDrawList_AddRectFilledMultiColor
              (uVar13,DAT_00395170,&DAT_004f8160,&local_360,&local_140,&local_160,
               (int)(DAT_0050fef8 * 255.0) * 0x1000000 + 0x1ffffff,0);
    fStack856 = 0.5882353;
    local_140 = (undefined8 *)
                CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                         (float)DAT_004f8160 + (float)DAT_004f8168);
    local_360 = (char *)0x3f1696973f169697;
    fVar31 = (float)(int)(DAT_0050fef8 * 100.0) * 0.003921569;
    uStack852 = SUB42(fVar31,0);
    uStack850 = (undefined2)((uint)fVar31 >> 0x10);
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
    ImDrawList_AddRectFilled(uVar13,&DAT_004f8160,&local_140,uVar9,0);
    ImGui_EndChild();
    if (((DAT_0050fef4 == '\0') && (DAT_0050fef8 <= 0.02)) && (_DAT_0039516c = 0, DAT_00395170 != 0)
       ) {
      glDeleteBuffers(1,&DAT_00395170);
      DAT_00395170 = 0;
    }
  }
  if (DAT_0050fef8 <= 0.02) goto LAB_002ea7f0;
  uVar38 = NEON_fmadd(DAT_0050ff10,0x41a00000,0x428c0000);
  uVar9 = NEON_fmsub(DAT_0050fef8,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
  uVar9 = NEON_fmsub(DAT_0050ff10,0x41a00000,uVar9);
  local_360 = (char *)CONCAT44(uVar9,uVar38);
  ImGui_SetCursorPos(&local_360);
  fStack856 = (float)NEON_fmadd(DAT_0050ff10,0xc1f00000,0x437f0000);
  uStack852 = 0;
  uStack850 = 0x3f40;
  fStack856 = fStack856 / 255.0;
  local_360 = (char *)CONCAT44(fStack856,fStack856);
  ImGui_PushStyleColor(3,&local_360);
  fVar31 = DAT_004f8168._4_4_ + -140.0;
  fVar36 = (float)NEON_fmadd(DAT_0050ff10,0xc2200000,(float)DAT_004f8168 + -140.0);
  local_360 = (char *)CONCAT44(fVar31,fVar36);
  ImGui_BeginChild("##NewSetPage1",&local_360,0,0x80000c);
  ImGui_PopStyleColor(1);
  uVar13 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  ImGui_GetWindowPos();
  if (DAT_004d7040 != -1) {
    DAT_004d7044 = DAT_004d7040;
  }
  time((time_t *)0x0);
  FUN_0036cf74();
  uVar15 = (ulong)&local_360 | 1;
  if (((ulong)local_360 & 1) != 0) {
    uVar15 = CONCAT26(uStack842,uStack848);
  }
                    /* try { // try from 002e8a68 to 002e8a6b has its CatchHandler @ 002eac9c */
  uVar15 = Gui_CloseButton(uVar15);
  if (((ulong)local_360 & 1) != 0) {
    free((void *)CONCAT26(uStack842,uStack848));
  }
  if ((uVar15 & 1) != 0) {
    DAT_004d7040 = -1;
  }
  if (DAT_004d7044 == 0x378) {
    pcVar18 = &UNK_00128619;
    if (DAT_004f3d14 != 0) {
      pcVar18 = "Island Size";
    }
    pcVar2 = &UNK_00118bb6;
    if (DAT_004f3d14 != 0) {
      pcVar2 = "Adjust";
    }
    Gui_ValueEditor(&DAT_0050ff78,pcVar18,&DAT_004f32ec,&DAT_00123207,pcVar2,DAT_0050d898);
    if (((DAT_0050ff90 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ff90), iVar11 != 0)) {
      DAT_0050ff80 = 0;
      DAT_0050ff84 = 0;
      DAT_0050ff88 = 0;
      DAT_0050ff88 = FUN_0034a23c();
      FUN_0036eca0(&DAT_0050ff90);
    }
    pcVar18 = &UNK_00120fb8;
    if (DAT_004f3d14 != 0) {
      pcVar18 = "Change Photo";
    }
    local_360 = (char *)0x427c000042a60000;
    uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_0050ff80);
    if ((uVar15 & 1) != 0) {
      DAT_0050ff0c = '\x01';
      DAT_004d7048 = 1;
    }
    if (((DAT_0050ffa8 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ffa8), iVar11 != 0)) {
      DAT_0050ff98 = 0;
      DAT_0050ff9c = 0;
      DAT_0050ffa0 = 0;
      DAT_0050ffa0 = FUN_0034a23c();
      FUN_0036eca0(&DAT_0050ffa8);
    }
    pcVar18 = &UNK_00118285;
    if (DAT_004f3d14 != 0) {
      pcVar18 = "Change Text [Use TTF Format";
    }
    local_360 = (char *)0x427c000042a60000;
    uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_0050ff98);
    if ((uVar15 & 1) != 0) {
      DAT_0050ff0c = '\x01';
      DAT_004d7048 = 3;
    }
    if (((DAT_0050ffc0 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ffc0), iVar11 != 0)) {
      DAT_0050ffb0 = 0;
      DAT_0050ffb4 = 0;
      DAT_0050ffb8 = 0;
      DAT_0050ffb8 = FUN_0034a23c();
      FUN_0036eca0(&DAT_0050ffc0);
    }
    pcVar18 = &UNK_0011fbed;
    if (DAT_004f3d14 != 0) {
      pcVar18 = "Dynamic";
    }
    local_360 = (char *)0x427c000042a60000;
    uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_0050ffb0);
    if ((uVar15 & 1) != 0) {
      DAT_0050ff0c = '\x01';
      DAT_004d7048 = 4;
    }
    if (((DAT_0050ffd8 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050ffd8), iVar11 != 0)) {
      DAT_0050ffc8 = 0;
      DAT_0050ffcc = 0;
      DAT_0050ffd0 = 0;
      DAT_0050ffd0 = FUN_0034a23c();
      FUN_0036eca0(&DAT_0050ffd8);
    }
    pcVar18 = &UNK_001216a5;
    if (DAT_004f3d14 != 0) {
      pcVar18 = "Island Dynamic Test";
    }
    local_360 = (char *)0x427c000042a60000;
    uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_0050ffc8);
    if ((uVar15 & 1) != 0) {
      DAT_0050ff0c = '\x01';
      DAT_004d7048 = 5;
    }
  }
  else if (DAT_004d7044 == 0x309) {
    Gui_FormatDiagnostic(&local_360,0x80,"pid: %d  libUE4: %p",DAT_00500ae0,DAT_00500ae8);
    fVar37 = fVar31 + 20.0;
    local_160 = (undefined *)CONCAT44(fVar36 + 0.0 + 5.0,fVar37);
    pfStack312 = (float *)0x3f8000003df0f0f2;
    local_140 = (undefined8 *)0x3df0f0f23df0f0f2;
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_140);
    ImDrawList_AddText(uVar13,0,&local_160,uVar9,&local_360,0,0);
    Gui_FormatDiagnostic(&local_360,0x80,"Matrix: %p  Self: %p",DAT_00500af0,DAT_00500b08);
    local_160 = (undefined *)CONCAT44(fVar36 + 40.0 + 5.0,fVar37);
    pfStack312 = (float *)0x3f8000003df0f0f2;
    local_140 = (undefined8 *)0x3df0f0f23df0f0f2;
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_140);
    ImDrawList_AddText(uVar13,0,&local_160,uVar9,&local_360,0,0);
    Gui_FormatDiagnostic(&local_360,0x80,"Arrayaddr: %p  Count: %d",DAT_00500af8,DAT_00500b00);
    local_160 = (undefined *)CONCAT44(fVar36 + 80.0 + 5.0,fVar37);
    pfStack312 = (float *)0x3f8000003df0f0f2;
    local_140 = (undefined8 *)0x3df0f0f23df0f0f2;
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_140);
    ImDrawList_AddText(uVar13,0,&local_160,uVar9,&local_360,0,0);
    puStack344 = &local_140;
    local_140 = (undefined8 *)CONCAT44(fVar36 + 120.0 + 20.0,fVar31);
    ImGui_SetCursorScreenPos(&local_140);
    Gui_FormatDiagnostic(&local_140,0x80,&DAT_00120fe4,DAT_00500b28);
    local_160 = &DAT_0011a50d;
    fVar36 = 63.0;
    local_150 = &DAT_0011c7d9;
    fVar31 = 83.0;
    Gui_LanguageChoice(&DAT_00500b2c,&DAT_0011b70a,&local_160,3,DAT_0050d7c0);
    if (DAT_00500b2c != 0) {
      if (((DAT_0050fff0 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_0050fff0), iVar11 != 0)) {
        DAT_0050ffe0 = 0;
        DAT_0050ffe4 = 0;
        DAT_0050ffe8 = 0;
        DAT_0050ffe8 = FUN_0034a23c();
        FUN_0036eca0(&DAT_0050fff0);
      }
      local_380 = 0x427c000042a60000;
      uVar15 = Gui_ActionRow(&DAT_0011bfd9,&local_380,&DAT_0050ffe0);
      if ((uVar15 & 1) != 0) {
        DAT_0050ff0c = '\x01';
        DAT_004d7048 = 2;
      }
    }
    ImGui_GetCursorScreenPos();
    Gui_FormatDiagnostic(&local_360,0x80,"SelfAddr: %p",DAT_00500b08);
    fStack868 = fVar36 + 10.0;
    uStack888 = 0x3f8000003df0f0f2;
    local_380 = 0x3df0f0f23df0f0f2;
    local_368 = fVar31 + 20.0;
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_380);
    fVar37 = 0.0;
    ImDrawList_AddText(uVar13,0,&local_368,uVar9,&local_360,0,0);
    puVar19 = (undefined8 *)(DAT_00500b10 + (long)DAT_00500b28 * 0x18);
    puVar27 = (undefined8 *)*puVar19;
    puVar19 = (undefined8 *)puVar19[1];
    if (puVar27 != puVar19) {
      do {
        puVar28 = puVar27 + 1;
        Gui_FormatDiagnostic(&local_360,0x80,&DAT_001244a6,*puVar27);
        local_368 = fVar31 + 20.0 + fVar37;
        fStack868 = fVar36 + 40.0 + 15.0 + fVar37;
        uStack888 = 0x3f8000003df0f0f2;
        local_380 = 0x3df0f0f23df0f0f2;
        uVar9 = ImGui_ColorConvertFloat4ToU32(&local_380);
        ImDrawList_AddText(uVar13,0,&local_368,uVar9,&local_360,0,0);
        fVar37 = fVar37 + 35.0;
        puVar27 = puVar28;
      } while (puVar28 != puVar19);
    }
  }
  else if (DAT_004d7044 == 1) {
    lVar12 = FUN_00292020();
    fVar31 = 8.0;
    *(undefined8 *)(lVar12 + 0x3c) = 0x4100000041000000;
    ImGui_GetWindowPos();
    fVar36 = fVar31 * 0.5 + 65.0;
    ImGui_SetNextItemWidth();
    ImGui_GetWindowPos();
    fVar31 = fVar36;
    ImGui_GetWindowPos();
    local_360 = (char *)CONCAT44(0x43160000,(fVar36 - (fVar31 * 0.5 + 65.0)) * 0.5);
    ImGui_SetCursorPos(&local_360);
    FUN_002cd454(&DAT_00120fac,&DAT_0050e4e0,0x60,0);
  }
  ImGui_EndChild();
  if ((DAT_0050ff0c == '\x01') && (DAT_0039517c == '\0')) {
    local_360 = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + 70.0,
                                 (float)DAT_004f8160 + 70.0);
    local_140 = (undefined8 *)CONCAT44(DAT_004f8168._4_4_ + -140.0,(float)DAT_004f8168 + -140.0);
    DAT_00395180 = Gui_RenderImageLayer("Hello ImGui",&local_360,&local_140,(int)DAT_00395174,4);
    _DAT_0039517c = 0x101;
LAB_002e90e4:
    if (((DAT_0050ff0c == '\0') && (DAT_0050ff10 <= 0.02)) && (_DAT_0039517c = 0, DAT_00395180 != 0)
       ) {
      glDeleteBuffers(1,&DAT_00395180);
      DAT_00395180 = 0;
    }
  }
  else if (DAT_0039517c != '\0') goto LAB_002e90e4;
  if (0.01 < DAT_0050ff10) {
    uVar9 = NEON_fmsub(DAT_0050ff10,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
    local_360 = (char *)CONCAT44(uVar9,0x428c0000);
    ImGui_SetCursorPos(&local_360);
    fVar32 = (float)DAT_004f8168 + -140.0;
    local_360 = (char *)CONCAT44(DAT_004f8168._4_4_ + -140.0,fVar32);
    fVar40 = (float)DAT_004f8168;
    ImGui_BeginChild("##gameData",&local_360,0,0x80000c);
    ImGui_GetWindowDrawList();
    ImGui_GetCursorScreenPos();
    fVar37 = fVar40;
    fVar39 = fVar32;
    ImGui_GetWindowPos();
    uVar13 = ImGui_GetWindowDrawList();
    ImGui_GetWindowPos();
    fVar31 = fVar39;
    fVar36 = fVar37;
    ImGui_GetWindowSize();
    local_380 = CONCAT44(fVar36,fVar31);
    local_140 = (undefined8 *)0x0;
    local_360 = (char *)CONCAT44(fVar37 + fVar36,fVar39 + fVar31);
    local_160 = puVar41;
    ImDrawList_AddRectFilledMultiColor
              (uVar13,DAT_00395180,&local_380,&local_360,&local_140,&local_160,0xffffffff,0);
    local_140 = (undefined8 *)
                CONCAT44(fVar37 + (float)((ulong)local_380 >> 0x20),fVar39 + (float)local_380);
    fStack856 = 1.0;
    uStack852 = 0xc8ca;
    uStack850 = 0x3ec8;
    local_360 = (char *)0x3f8000003f800000;
    uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
    ImDrawList_AddRectFilled(uVar13,&local_380,&local_140,uVar9,0);
    if (DAT_004d704c == -1) {
      Gui_UpdateDragScroll();
      lVar12 = DAT_0050e6f0;
      *(undefined *)(*(long *)(DAT_0050e6f0 + 0x3eb0) + 0x90) = 1;
      puVar27 = DAT_0050edf0;
      lVar12 = *(long *)(lVar12 + 0x3eb0);
      if ((lVar12 != 0) && (*(char *)((long)DAT_0050edf0 + 0x14) == '\0')) {
        *(float *)(lVar12 + 0x60) = *(float *)((long)DAT_0050edf0 + 4) + *(float *)(lVar12 + 0x60);
        fVar31 = *(float *)(lVar12 + 0x68);
        *(float *)((long)puVar27 + 4) = *(float *)(puVar27 + 1) * *(float *)((long)puVar27 + 4);
        if ((fVar31 <= *(float *)(lVar12 + 0x60)) || (*(float *)(lVar12 + 0x60) <= 0.0)) {
          *DAT_0050edf0 = 0;
        }
        if (ABS(*(float *)((long)DAT_0050edf0 + 4)) < 0.1) {
          *DAT_0050edf0 = 0;
        }
      }
    }
    time((time_t *)0x0);
    FUN_0036cf74();
    uVar15 = (ulong)&local_360 | 1;
    if (((ulong)local_360 & 1) != 0) {
      uVar15 = CONCAT26(uStack842,uStack848);
    }
                    /* try { // try from 002e9274 to 002e9277 has its CatchHandler @ 002eac98 */
    uVar15 = Gui_CloseButton(uVar15);
    if (((ulong)local_360 & 1) != 0) {
      free((void *)CONCAT26(uStack842,uStack848));
    }
    if ((uVar15 & 1) != 0) {
      DAT_0050ff0c = '\0';
    }
    local_360 = (char *)CONCAT44(fVar40 + 100.0,fVar32);
    ImGui_SetCursorScreenPos(&local_360);
    switch(DAT_004d7048) {
    case 2:
      local_360 = (char *)0x427c000042a60000;
      Gui_PointerTable(&DAT_00500b30,&DAT_00500b10,&local_360);
      break;
    case 3:
      if (((DAT_00510008 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_00510008), iVar11 != 0)) {
        DAT_0050fff8 = 0;
        DAT_0050fffc = 0;
        DAT_00510000 = 0;
        DAT_00510000 = FUN_0034a23c();
        FUN_0036eca0(&DAT_00510008);
      }
      pcVar18 = &UNK_0011c7e6;
      if (DAT_004f3d14 != 0) {
        pcVar18 = "Restore the original Text";
      }
      local_360 = (char *)0x427c000042a60000;
      uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_0050fff8);
      if ((uVar15 & 1) != 0) {
        DAT_004d703c = 0;
        DAT_0050fee8 = 1;
        DAT_004f3414 = 0x7274706c6c756e;
      }
      if (((DAT_00510020 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_00510020), iVar11 != 0)) {
        DAT_00510010 = 0;
        DAT_00510014 = 0;
        DAT_00510018 = 0;
        DAT_00510018 = FUN_0034a23c();
        FUN_0036eca0(&DAT_00510020);
      }
      pcVar18 = &UNK_0011bfe9;
      if (DAT_004f3d14 != 0) {
        pcVar18 = "From the cloud";
      }
      local_360 = (char *)0x427c000042a60000;
      uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_00510010);
      if ((uVar15 & 1) != 0) {
        DAT_004d704c = 8;
        DAT_0050ff24 = '\x01';
      }
      if (((DAT_00510038 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_00510038), iVar11 != 0)) {
        DAT_00510028 = 0;
        DAT_0051002c = 0;
        DAT_00510030 = 0;
        DAT_00510030 = FUN_0034a23c();
        FUN_0036eca0(&DAT_00510038);
      }
      pcVar18 = &UNK_00129f8b;
      if (DAT_004f3d14 != 0) {
        pcVar18 = "Use File Dir Switch";
      }
      local_360 = (char *)0x427c000042a60000;
      uVar15 = Gui_ActionRow(pcVar18,&local_360,&DAT_00510028);
      if ((uVar15 & 1) != 0) {
        DAT_004d704c = 6;
        DAT_0050ff24 = '\x01';
      }
      break;
    case 4:
      pcVar18 = &UNK_00118bf3;
      if (DAT_004f3d14 != 0) {
        pcVar18 = "Dynamic";
      }
      fStack856 = SUB164(_PTR_DAT_0038c590 >> 0x40,0);
      uStack852 = SUB162(_PTR_DAT_0038c590 >> 0x60,0);
      uStack850 = SUB162(_PTR_DAT_0038c590 >> 0x70,0);
      local_360 = SUB168(_PTR_DAT_0038c590,0);
      Gui_ChoiceCombo(&DAT_004f32f4,pcVar18,&local_360,2,DAT_0050d870);
      break;
    case 5:
      local_360 = &DAT_004f960c;
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004f9608);
      fStack856 = 7.309347e-39;
      uStack852 = 0;
      uStack850 = 0;
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004f9778);
      uStack848 = 0x4f98ec;
      uStack842 = 0;
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004f98e8);
      puStack840 = &DAT_004f9a5c;
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004f9a58);
      local_340 = &DAT_004f9bcc;
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004f9bc8);
      local_338 = &DAT_004f9d3c;
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004f9d38);
      local_140 = (undefined8 *)&DAT_00128fa2;
      pfStack312 = (float *)&DAT_0011e164;
      local_130 = (float *)&DAT_00123c94;
      local_128 = &DAT_00128fba;
      local_120 = &DAT_0011e17c;
      puStack280 = &DAT_00125762;
      Gui_TaskToggleRows(&DAT_0021db38 + *(int *)(&DAT_0021db38 + (long)DAT_004f3d14 * 4),&local_140
                         ,&local_360,6,DAT_0050d7f0);
      ram0x004f96dc = ram0x004f96dc & 0xff000000 | 0x80b8;
      ram0x004f965c = ram0x004f965c & 0xff000000 | 0x80b8;
      _DAT_004f9658 = 0xe49bb2e5;
      _DAT_004f96d8 = 0xe49bb2e5;
      DAT_004f97e8 = 0x5d8a95;
      uRam00000000004f97d0 = SUB168(_DAT_0011e194 >> 0x40,0);
      _DAT_004f97c8 = SUB168(_DAT_0011e194,0);
      uRam00000000004f97e0 = 0xe58a95e58a95e58a;
      _DAT_004f97d8 = 0x95e58a95e5ac9ce6;
      DAT_004f9868 = 0x5d8a95;
      uRam00000000004f9860 = 0xe58a95e58a95e58a;
      _DAT_004f9858 = 0x95e58a95e5ac9ce6;
      _DAT_004f9848 = _DAT_004f97c8;
      uRam00000000004f9850 = uRam00000000004f97d0;
      time((time_t *)0x0);
      FUN_0036cf74();
      puVar16 = (undefined *)((ulong)&local_160 | 1);
      if (((ulong)local_160 & 1) != 0) {
        puVar16 = local_150;
      }
      __strcpy_chk(&DAT_004f9938,puVar16,0x80);
      if (((ulong)local_160 & 1) != 0) {
        free(local_150);
      }
      time((time_t *)0x0);
      FUN_0036cf74();
      puVar16 = (undefined *)((ulong)&local_160 | 1);
      if (((ulong)local_160 & 1) != 0) {
        puVar16 = local_150;
      }
      __strcpy_chk(&DAT_004f99b8,puVar16,0x80);
      if (((ulong)local_160 & 1) != 0) {
        free(local_150);
      }
      break;
    default:
      if ((DAT_00510040 & 1) == 0) {
        Gui_IsPictureExtension(&DAT_0050d768);
        DAT_00510040 = 1;
      }
      getcwd((char *)&local_360,0x200);
      FUN_002bdc7c(&DAT_00127dd6,&local_360);
      FUN_002bdc7c(&DAT_0011c7f9);
      local_140 = (undefined8 *)0x41a0000000000000;
      ImGui_Dummy(&local_140);
      if (((DAT_00510058 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_00510058), iVar11 != 0)) {
        DAT_00510048 = 0;
        DAT_0051004c = 0;
        DAT_00510050 = 0;
        DAT_00510050 = FUN_0034a23c();
        FUN_0036eca0(&DAT_00510058);
      }
      pcVar18 = &UNK_0011d089;
      if (DAT_004f3d14 != 0) {
        pcVar18 = "Restore the original picture";
      }
      local_140 = (undefined8 *)0x427c000042a60000;
      uVar15 = Gui_ActionRow(pcVar18,&local_140,&DAT_00510048);
      lVar20 = DAT_0050d730;
      lVar12 = DAT_0050d728;
      if ((uVar15 & 1) != 0) {
        for (; lVar12 != lVar20; lVar12 = lVar12 + 4) {
          glDeleteBuffers(1,lVar12);
        }
        DAT_0050d730 = DAT_0050d728;
        Gui_DecodeImage(DAT_0050d8e0,(undefined4)DAT_0050d8f0);
        Gui_SetExternalAsset(&DAT_0050d728,&local_140);
        if (local_e8 != (void *)0x0) {
          local_e0 = local_e8;
          free(local_e8);
        }
        pvVar8 = local_100;
        if (local_100 != (void *)0x0) {
          while (pvVar4 = local_f8, pvVar4 != pvVar8) {
            local_f8 = (void *)((long)pvVar4 + -0x20);
            if ((*(byte *)((long)pvVar4 + -0x18) & 1) != 0) {
              free(*(void **)((long)pvVar4 + -8));
            }
          }
          local_f8 = pvVar8;
          free(local_100);
        }
        if (local_128 != (undefined *)0x0) {
          local_120 = local_128;
          free(local_128);
        }
        if (local_140 != (undefined8 *)0x0) {
          pfStack312 = (float *)local_140;
          free(local_140);
        }
        DAT_0050d760 = 0;
        DAT_004f3314 = 0x7274706c6c756e;
      }
      if (((DAT_00510070 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_00510070), iVar11 != 0)) {
        DAT_00510060 = 0;
        DAT_00510064 = 0;
        DAT_00510068 = 0;
        DAT_00510068 = FUN_0034a23c();
        FUN_0036eca0(&DAT_00510070);
      }
      pcVar18 = &UNK_00129f8b;
      if (DAT_004f3d14 != 0) {
        pcVar18 = "Use File Dir Switch";
      }
      local_140 = (undefined8 *)0x427c000042a60000;
      uVar15 = Gui_ActionRow(pcVar18,&local_140,&DAT_00510060);
      if ((uVar15 & 1) != 0) {
        DAT_004d704c = 7;
        DAT_0050ff24 = '\x01';
      }
      Gui_PathSelection(&DAT_004d7050,&DAT_0050d768);
    }
    ImGui_EndChild();
    if (0.01 < DAT_0050ff28) {
      uVar9 = NEON_fmsub(DAT_0050ff28,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 50.0);
      local_360 = (char *)CONCAT44(uVar9,0x42480000);
      ImGui_SetCursorPos(&local_360);
      fStack856 = SUB164(_DAT_0012b960 >> 0x40,0);
      uStack852 = SUB162(_DAT_0012b960 >> 0x60,0);
      uStack850 = SUB162(_DAT_0012b960 >> 0x70,0);
      local_360 = SUB168(_DAT_0012b960,0);
      ImGui_PushStyleColor(3,&local_360);
      fStack908 = -100.0;
      fVar31 = (float)DAT_004f8168 + -100.0;
      local_360 = (char *)(ulong)(uint)fVar31;
      ImGui_BeginChild("##NewPage3",&local_360,0,0x80000c);
      ImGui_PopStyleColor(1);
      local_380 = ImGui_GetWindowDrawList();
      ImGui_GetWindowSize();
      local_368 = fVar31;
      fStack868 = fStack908;
      local_388 = local_368;
      ImGui_GetCursorScreenPos();
      fStack900 = fStack908;
      local_390 = local_388;
      ImGui_GetWindowPos();
      Gui_UpdateDragScroll();
      lVar12 = DAT_0050e6f0;
      *(undefined *)(*(long *)(DAT_0050e6f0 + 0x3eb0) + 0x90) = 1;
      puVar27 = DAT_0050edf0;
      lVar12 = *(long *)(lVar12 + 0x3eb0);
      if ((lVar12 != 0) && (*(char *)((long)DAT_0050edf0 + 0x14) == '\0')) {
        *(float *)(lVar12 + 0x60) = *(float *)((long)DAT_0050edf0 + 4) + *(float *)(lVar12 + 0x60);
        fVar31 = *(float *)(lVar12 + 0x68);
        *(float *)((long)puVar27 + 4) = *(float *)(puVar27 + 1) * *(float *)((long)puVar27 + 4);
        if ((fVar31 <= *(float *)(lVar12 + 0x60)) || (*(float *)(lVar12 + 0x60) <= 0.0)) {
          *DAT_0050edf0 = 0;
        }
        if (ABS(*(float *)((long)DAT_0050edf0 + 4)) < 0.1) {
          *DAT_0050edf0 = 0;
        }
      }
      time((time_t *)0x0);
      FUN_0036cf74();
      uVar15 = (ulong)&local_360 | 1;
      if (((ulong)local_360 & 1) != 0) {
        uVar15 = CONCAT26(uStack842,uStack848);
      }
                    /* try { // try from 002e9ab0 to 002e9ab3 has its CatchHandler @ 002eac94 */
      uVar15 = Gui_CloseButton(uVar15);
      if (((ulong)local_360 & 1) != 0) {
        free((void *)CONCAT26(uStack842,uStack848));
      }
      uVar13 = local_380;
      if ((uVar15 & 1) == 0) {
        if (DAT_004d704c == 8) {
          pfStack312 = &local_388;
          local_130 = &local_390;
          local_140 = &local_380;
          fStack856 = 0.1176471;
          uStack852 = 0;
          uStack850 = 0x3f80;
          local_360 = (char *)0x3df0f0f23df0f0f2;
          local_160 = (undefined *)CONCAT44(fStack900 + 20.0,local_388 + 40.0);
          uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
          ImDrawList_AddText(uVar13,0,&local_160,uVar9,&DAT_0011d9a8,0,0);
          local_360 = (char *)CONCAT44(fStack900 + 100.0,local_388);
          ImGui_SetCursorScreenPos(&local_360);
          FUN_002ec060(&local_140);
          lVar12 = DAT_0050db90;
          if (DAT_0050db88 != DAT_0050db90) {
            lVar20 = DAT_0050db88;
            if ((undefined *)0x27 < &DAT_ffffffffffffffd8 + (DAT_0050db90 - DAT_0050db88)) {
              uVar15 = (ulong)(&DAT_ffffffffffffffd8 + (DAT_0050db90 - DAT_0050db88)) / 0x28 + 1;
              uVar24 = uVar15 & 0xffffffffffffffe;
              lVar20 = DAT_0050db88 + uVar24 * 0x28;
              pcVar18 = (char *)(DAT_0050db88 + 0x38);
              uVar14 = uVar24;
              do {
                if (pcVar18[-0x28] != '\0') {
                  DAT_005101d9 = 1;
                  pcVar18[-0x28] = '\0';
                }
                if (*pcVar18 != '\0') {
                  DAT_005101d9 = 1;
                  *pcVar18 = '\0';
                }
                pcVar18 = pcVar18 + 0x50;
                uVar14 = uVar14 - 2;
              } while (uVar14 != 0);
              if (uVar15 == uVar24) goto LAB_002ea290;
            }
            do {
              if (*(char *)(lVar20 + 0x10) != '\0') {
                DAT_005101d9 = 1;
                *(undefined *)(lVar20 + 0x10) = 0;
              }
              lVar20 = lVar20 + 0x28;
            } while (lVar20 != lVar12);
          }
LAB_002ea290:
          if ((DAT_005101d9 & 1) != 0) {
            if ((DAT_005101da & 1) == 0) {
              if (DAT_005101dc != 0) {
                glDeleteTextures(1,&DAT_005101dc);
              }
              DAT_005101dc = Gui_RenderImageLayer
                                       ("Hello ImGui",&DAT_004f8160,&DAT_004f8168,(int)DAT_00395174,
                                        4);
              DAT_005101da = 1;
            }
            if (DAT_005101dc != 0) {
              local_160 = (undefined *)0x0;
              pcVar18 = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                                         (float)DAT_004f8160 + (float)DAT_004f8168);
              local_398 = puVar41;
              local_360 = pcVar18;
              ImDrawList_AddRectFilledMultiColor
                        (local_380,DAT_005101dc,&DAT_004f8160,&local_360,&local_160,&local_398,
                         0xffffffff,0);
              fVar31 = SUB84(pcVar18,0);
              if (DAT_004d7370 <= 0.0) {
                __strcpy_chk(&local_360,&DAT_004d7270,0x80);
              }
              else {
                Gui_FormatDiagnostic(&local_360,0x80,"%s %.2f%%",&DAT_004d7270);
              }
              if (DAT_004d7374 != '\0') {
                fStack856 = SUB164(_DAT_001244a9 >> 0x40,0);
                uStack852 = SUB162(_DAT_001244a9 >> 0x60,0);
                local_360 = SUB168(_DAT_001244a9,0);
                uStack850 = 0xe497;
                uStack848 = 0x2e2e2e93bd;
              }
              fVar36 = 60.0;
              ImGui_CalcTextSize(0,&local_360);
              uVar13 = local_380;
              local_398 = (undefined *)
                          CONCAT44(((fStack900 + fStack908 * 0.5) - fVar31 * 0.5) + -1.0,
                                   (local_388 + local_390 * 0.5) - fVar36 * 0.5);
              puStack344 = (undefined8 *)0x3f8000003df0f0f2;
              local_160 = (undefined *)0x3df0f0f23df0f0f2;
              uVar9 = ImGui_ColorConvertFloat4ToU32(&local_160);
              ImDrawList_AddText(uVar13,0,&local_398,uVar9,&local_360,0,0);
              if (DAT_004d7374 != '\0') {
                DAT_005101d9 = 0;
                DAT_0050fee8 = 1;
                __strcpy_chk(&DAT_004f3414,s_nullptr_004d7375,0x100);
                DAT_004d703c = 1;
              }
            }
          }
        }
        else if (DAT_004d704c == 7) {
          if (((DAT_005101d0 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_005101d0), iVar11 != 0)) {
            DAT_005101b8 = (byte *)0x0;
            DAT_005101c0 = (byte *)0x0;
            DAT_005101c8 = 0;
            __cxa_atexit(FUN_00264dd0,&DAT_005101b8,&DAT_004d7920);
            FUN_0036eca0(&DAT_005101d0);
          }
          uVar13 = local_380;
          local_360 = (char *)0x3df0f0f23df0f0f2;
          uVar34 = NEON_fmov(0x41a00000,4);
          fStack856 = 0.1176471;
          uStack852 = 0;
          uStack850 = 0x3f80;
          local_140 = (undefined8 *)
                      CONCAT44(fStack900 + (float)((ulong)uVar34 >> 0x20),local_388 + (float)uVar34)
          ;
          uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
          ImDrawList_AddText(uVar13,0,&local_140,uVar9,s__storage_emulated_0_004d7154,0,0);
          local_360 = (char *)CONCAT44(fStack900 + 100.0,local_388);
          ImGui_SetCursorScreenPos(&local_360);
          if ((DAT_005101d8 & 1) == 0) {
            Gui_ListDirectory(s__storage_emulated_0_004d7154,&DAT_005101b8,&DAT_00118bfa,
                              &DAT_0012577a);
          }
          if (DAT_00510080 == (undefined *)0x0) {
            pbVar21 = DAT_005101c0;
            if ((DAT_005101b8 != DAT_005101c0) || (pbVar21 = DAT_005101b8, (DAT_005101d8 & 1) == 0))
            goto LAB_002ea068;
          }
          else if ((DAT_005101d8 & 1) == 0) {
            free(DAT_00510080);
            pbVar21 = DAT_005101c0;
LAB_002ea068:
            lVar25 = (long)pbVar21 - (long)DAT_005101b8;
            lVar20 = lVar25 >> 3;
            lVar12 = lVar20 * -0x5555555555555550;
            if ((ulong)(lVar20 * -0x5555555555555555) >> 0x3c != 0) {
              lVar12 = -1;
            }
            puVar16 = (undefined *)thunk_FUN_0036b114(lVar12);
            if (lVar25 != 0) {
              puVar26 = puVar16;
              do {
                *puVar26 = 0;
                *(undefined4 *)(puVar26 + 4) = 0;
                *(undefined8 *)(puVar26 + 8) = 0;
                uVar13 = FUN_0034a23c();
                *(undefined8 *)(puVar26 + 8) = uVar13;
                puVar26 = puVar26 + 0x10;
              } while (puVar26 != puVar16 + lVar20 * -0x5555555555555550);
            }
            DAT_005101d8 = 1;
            DAT_00510080 = puVar16;
          }
          local_360 = (char *)0x427c000042a60000;
          uVar15 = Gui_ActionRow(&DAT_0012862f,&local_360,0);
          pbVar21 = DAT_005101b8;
          pbVar29 = DAT_005101c0;
          if (((uVar15 & 1) != 0) && (DAT_0050e634 == '\0')) {
            uStack632 = 0;
            local_280 = 0;
            uStack616 = 0;
            uStack624 = 0;
            uStack664 = 0;
            local_2a0 = 0;
            uStack648 = 0;
            uStack656 = 0;
            uStack696 = 0;
            local_2c0 = 0;
            uStack680 = 0;
            uStack688 = 0;
            uStack728 = 0;
            local_2e0 = 0;
            uStack712 = 0;
            uStack720 = 0;
            uStack760 = 0;
            local_300 = 0;
            uStack744 = 0;
            uStack752 = 0;
            uStack776 = 0;
            local_310 = 0;
            uStack808 = 0;
            local_330 = 0;
            uStack792 = 0;
            uStack800 = 0;
            puStack840 = (undefined *)0x0;
            uStack848 = 0;
            uStack842 = 0;
            local_338 = (undefined *)0x0;
            local_340 = (undefined *)0x0;
            fStack856 = 0.0;
            uStack852 = 0;
            uStack850 = 0;
            local_360 = (char *)0x0;
            lVar12 = 0;
            do {
              lVar20 = lVar12;
              lVar12 = lVar20 + 1;
            } while (s__storage_emulated_0_004d7154[lVar20] != '\0');
            do {
              lVar12 = lVar20 + -1;
              pcVar18 = &DAT_004d7153 + lVar20;
              lVar20 = lVar12;
            } while (*pcVar18 != '/');
            __memcpy_chk(&local_360,s__storage_emulated_0_004d7154,lVar12,0x100);
            __strcpy_chk(s__storage_emulated_0_004d7154,&local_360,0x100);
            if (s__storage_emulated_0_004d7154[0] == '\0') {
              __strcat_chk(s__storage_emulated_0_004d7154,&DAT_0011925d,0x100);
            }
            DAT_005101d8 = 0;
            pbVar21 = DAT_005101b8;
            pbVar29 = DAT_005101c0;
          }
          for (; pbVar22 = DAT_005101c0, bVar5 = pbVar21 != DAT_005101c0, DAT_005101c0 = pbVar29,
              bVar5; pbVar21 = pbVar21 + 0x18) {
            pbVar29 = pbVar21 + 1;
            pbVar23 = *(byte **)(pbVar21 + 0x10);
            if ((*pbVar21 & 1) == 0) {
              pbVar23 = pbVar21 + 1;
            }
            sVar17 = strlen((char *)pbVar23);
            pbVar23 = pbVar23 + sVar17 + 2;
            do {
              pbVar1 = pbVar23 + -2;
              pbVar23 = pbVar23 + -1;
            } while (*pbVar1 != 0x2f);
            __strcpy_chk(&local_360,pbVar23,0x80);
            local_140 = (undefined8 *)0x427c000042a60000;
            uVar15 = Gui_ActionRow(&local_360,&local_140,0);
            if (((uVar15 & 1) != 0) && (DAT_0050e634 == '\0')) {
              pcVar18 = strstr((char *)&local_360,".jpg");
              if ((pcVar18 == (char *)0x0) &&
                 (pcVar18 = strstr((char *)&local_360,".png"), pcVar18 == (char *)0x0)) {
                if ((*pbVar21 & 1) != 0) {
                  pbVar29 = *(byte **)(pbVar21 + 0x10);
                }
                __strcpy_chk(s__storage_emulated_0_004d7154,pbVar29,0x100);
                DAT_005101d8 = 0;
                break;
              }
              pbVar23 = pbVar29;
              if ((*pbVar21 & 1) != 0) {
                pbVar23 = *(byte **)(pbVar21 + 0x10);
              }
              __strcpy_chk(&DAT_00510090,pbVar23,0x100);
              if (DAT_00510088 == 0) {
                if ((*pbVar21 & 1) != 0) {
                  pbVar29 = *(byte **)(pbVar21 + 0x10);
                }
                DAT_00510088 = Gui_ReportFileError(pbVar29);
              }
            }
            pbVar29 = DAT_005101c0;
            DAT_005101c0 = pbVar22;
          }
        }
        else if (DAT_004d704c == 6) {
          if (((DAT_005101a8 & 1) == 0) && (iVar11 = FUN_0036eb48(&DAT_005101a8), iVar11 != 0)) {
            DAT_00510190 = (byte *)0x0;
            DAT_00510198 = (byte *)0x0;
            DAT_005101a0 = 0;
            __cxa_atexit(FUN_00264dd0,&DAT_00510190,&DAT_004d7920);
            FUN_0036eca0(&DAT_005101a8);
          }
          uVar13 = local_380;
          local_360 = (char *)0x3df0f0f23df0f0f2;
          uVar34 = NEON_fmov(0x41a00000,4);
          fStack856 = 0.1176471;
          uStack852 = 0;
          uStack850 = 0x3f80;
          local_140 = (undefined8 *)
                      CONCAT44(fStack900 + (float)((ulong)uVar34 >> 0x20),local_388 + (float)uVar34)
          ;
          uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
          ImDrawList_AddText(uVar13,0,&local_140,uVar9,s__storage_emulated_0_004d7054,0,0);
          local_360 = (char *)CONCAT44(fStack900 + 100.0,local_388);
          ImGui_SetCursorScreenPos(&local_360);
          if ((DAT_005101b0 & 1) == 0) {
            Gui_ListDirectory(s__storage_emulated_0_004d7054,&DAT_00510190,&DAT_00126062,
                              &DAT_0011e1b8);
          }
          if (DAT_00510078 == (undefined *)0x0) {
            pbVar21 = DAT_00510198;
            if ((DAT_00510190 != DAT_00510198) || (pbVar21 = DAT_00510190, (DAT_005101b0 & 1) == 0))
            goto LAB_002e9e04;
          }
          else if ((DAT_005101b0 & 1) == 0) {
            free(DAT_00510078);
            pbVar21 = DAT_00510198;
LAB_002e9e04:
            lVar25 = (long)pbVar21 - (long)DAT_00510190;
            lVar20 = lVar25 >> 3;
            lVar12 = lVar20 * -0x5555555555555550;
            if ((ulong)(lVar20 * -0x5555555555555555) >> 0x3c != 0) {
              lVar12 = -1;
            }
            puVar16 = (undefined *)thunk_FUN_0036b114(lVar12);
            if (lVar25 != 0) {
              puVar26 = puVar16;
              do {
                *puVar26 = 0;
                *(undefined4 *)(puVar26 + 4) = 0;
                *(undefined8 *)(puVar26 + 8) = 0;
                uVar13 = FUN_0034a23c();
                *(undefined8 *)(puVar26 + 8) = uVar13;
                puVar26 = puVar26 + 0x10;
              } while (puVar26 != puVar16 + lVar20 * -0x5555555555555550);
            }
            DAT_005101b0 = 1;
            DAT_00510078 = puVar16;
          }
          local_360 = (char *)0x427c000042a60000;
          uVar15 = Gui_ActionRow(&DAT_0012862f,&local_360,0);
          if (((uVar15 & 1) != 0) && (DAT_0050e634 == '\0')) {
            uStack632 = 0;
            local_280 = 0;
            uStack616 = 0;
            uStack624 = 0;
            uStack664 = 0;
            local_2a0 = 0;
            uStack648 = 0;
            uStack656 = 0;
            uStack696 = 0;
            local_2c0 = 0;
            uStack680 = 0;
            uStack688 = 0;
            uStack728 = 0;
            local_2e0 = 0;
            uStack712 = 0;
            uStack720 = 0;
            uStack760 = 0;
            local_300 = 0;
            uStack744 = 0;
            uStack752 = 0;
            uStack776 = 0;
            local_310 = 0;
            uStack808 = 0;
            local_330 = 0;
            uStack792 = 0;
            uStack800 = 0;
            puStack840 = (undefined *)0x0;
            uStack848 = 0;
            uStack842 = 0;
            local_338 = (undefined *)0x0;
            local_340 = (undefined *)0x0;
            fStack856 = 0.0;
            uStack852 = 0;
            uStack850 = 0;
            local_360 = (char *)0x0;
            lVar12 = 0;
            do {
              lVar20 = lVar12;
              lVar12 = lVar20 + 1;
            } while (s__storage_emulated_0_004d7054[lVar20] != '\0');
            do {
              lVar12 = lVar20 + -1;
              pcVar18 = &DAT_004d7053 + lVar20;
              lVar20 = lVar12;
            } while (*pcVar18 != '/');
            __memcpy_chk(&local_360,s__storage_emulated_0_004d7054,lVar12,0x100);
            __strcpy_chk(s__storage_emulated_0_004d7054,&local_360,0x100);
            if (s__storage_emulated_0_004d7054[0] == '\0') {
              __strcat_chk(s__storage_emulated_0_004d7054,&DAT_0011925d,0x100);
            }
            DAT_005101b0 = 0;
          }
          pbVar21 = DAT_00510198;
          if (DAT_00510190 != DAT_00510198) {
            lVar12 = 0;
            pbVar29 = DAT_00510190;
            do {
              pbVar22 = *(byte **)(pbVar29 + 0x10);
              if ((*pbVar29 & 1) == 0) {
                pbVar22 = pbVar29 + 1;
              }
              sVar17 = strlen((char *)pbVar22);
              pbVar22 = pbVar22 + sVar17 + 2;
              do {
                pbVar23 = pbVar22 + -2;
                pbVar22 = pbVar22 + -1;
              } while (*pbVar23 != 0x2f);
              __strcpy_chk(&local_360,pbVar22,0x80);
              local_140 = (undefined8 *)0x427c000042a60000;
              uVar15 = Gui_ActionRow(&local_360,&local_140,DAT_00510078 + lVar12 * 0x10);
              if (((uVar15 & 1) != 0) && (DAT_0050e634 == '\0')) {
                pcVar18 = strstr((char *)&local_360,".ttf");
                if ((pcVar18 == (char *)0x0) &&
                   (pcVar18 = strstr((char *)&local_360,".TTF"), pcVar18 == (char *)0x0)) {
                  pbVar21 = pbVar29 + 1;
                  if ((*pbVar29 & 1) != 0) {
                    pbVar21 = *(byte **)(pbVar29 + 0x10);
                  }
                  __strcpy_chk(s__storage_emulated_0_004d7054,pbVar21,0x100);
                  DAT_005101b0 = 0;
                  break;
                }
                DAT_0050fee8 = 1;
                pbVar22 = pbVar29 + 1;
                if ((*pbVar29 & 1) != 0) {
                  pbVar22 = *(byte **)(pbVar29 + 0x10);
                }
                __strcpy_chk(&DAT_004f3414,pbVar22,0x100);
                DAT_004d703c = 1;
              }
              lVar12 = lVar12 + 1;
              pbVar29 = pbVar29 + 0x18;
            } while (pbVar29 != pbVar21);
          }
        }
        if (DAT_00510088 != 0) {
          ImGui_SetCursorScreenPos(&local_368);
          local_360 = pcVar33;
          fStack856 = fVar30;
          uStack852 = uVar6;
          uStack850 = uVar7;
          ImGui_PushStyleColor(3,&local_360);
          fVar39 = -50.0;
          fVar37 = DAT_004f8168._4_4_ + -50.0;
          local_360 = (char *)((ulong)(uint)fVar37 << 0x20);
          ImGui_BeginChild("##PhotoLook",&local_360,0,0x80000c);
          ImGui_PopStyleColor(1);
          uVar13 = ImGui_GetWindowDrawList();
          ImGui_GetCursorScreenPos();
          local_398 = (undefined *)CONCAT44(fVar39,fVar37);
          fVar31 = fVar39;
          fVar36 = fVar37;
          ImGui_GetWindowPos();
          if (DAT_00510088 != 0) {
            local_140 = (undefined8 *)0x0;
            local_360 = (char *)CONCAT44(fVar31 + fVar39,fVar36 + fVar37);
            local_160 = puVar41;
            ImDrawList_AddRectFilledMultiColor
                      (uVar13,DAT_00510088,&local_398,&local_360,&local_140,&local_160,0xffffffff,0)
            ;
          }
          time((time_t *)0x0);
          FUN_0036cf74();
          uVar15 = (ulong)&local_360 | 1;
          if (((ulong)local_360 & 1) != 0) {
            uVar15 = CONCAT26(uStack842,uStack848);
          }
                    /* try { // try from 002ea5b8 to 002ea5bb has its CatchHandler @ 002eac90 */
          uVar15 = Gui_CloseButton(uVar15);
          if (((ulong)local_360 & 1) != 0) {
            free((void *)CONCAT26(uStack842,uStack848));
          }
          if ((uVar15 & 1) != 0) {
            glDeleteTextures(1,&DAT_00510088);
            DAT_00510088 = 0;
          }
          local_140 = (undefined8 *)
                      CONCAT44(fVar31 + local_398._4_4_ + -120.0,(float)local_398 + 100.0);
          fVar39 = 0.0;
          local_160 = (undefined *)
                      CONCAT44(fVar31 + local_398._4_4_ + -40.0,fVar36 + (float)local_398 + -100.0);
          fStack856 = 1.0;
          uStack852 = 0;
          uStack850 = 0x3f80;
          local_360 = (char *)0x3f10909100000000;
          uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
          ImDrawList_AddRectFilled(uVar13,&local_140,&local_160,uVar9,0);
          fVar37 = 50.0;
          ImGui_CalcTextSize(0,&DAT_00123433);
          local_140 = (undefined8 *)
                      CONCAT44(((fVar31 + local_398._4_4_ + -80.0) - fVar39 * 0.5) + -1.0,
                               (fVar36 * 0.5 + (float)local_398) - fVar37 * 0.5);
          local_360 = pcVar33;
          fStack856 = fVar30;
          uStack852 = uVar6;
          uStack850 = uVar7;
          uVar9 = ImGui_ColorConvertFloat4ToU32(&local_360);
          ImDrawList_AddText(uVar13,0,&local_140,uVar9,&DAT_00123433,0,0);
          local_360 = (char *)CONCAT44(fVar31 + local_398._4_4_ + -120.0,(float)local_398 + 100.0);
          ImGui_SetCursorScreenPos(&local_360);
          local_360 = (char *)CONCAT44(0x42a00000,fVar36 + -200.0);
          uVar15 = ImGui_Button(&DAT_00123433,&local_360,0);
          lVar12 = DAT_0050d728;
          if (((uVar15 & 1) != 0) && (DAT_0050e634 == '\0')) {
            DAT_0050d760 = 1;
            uVar10 = Gui_ReportFileError(&DAT_00510090);
            local_360 = (char *)((ulong)local_360 & 0xffffffff00000000 | (ulong)uVar10);
            FUN_002ec420(&DAT_0050d728,lVar12,&local_360);
            __strcpy_chk(&DAT_004f3314,&DAT_00510090,0x100);
            glDeleteTextures(1,&DAT_00510088);
            DAT_00510088 = 0;
            DAT_0050fef4 = '\0';
            DAT_004d7040 = -1;
            DAT_0050ff0c = '\0';
            DAT_0050ff24 = '\0';
            DAT_0050fef8 = 0.0;
            DAT_0050ff10 = 0.0;
            DAT_0050ff28 = 0.0;
          }
          ImGui_EndChild();
        }
      }
      else {
        DAT_0050ff24 = '\0';
        if (DAT_00510078 != (undefined *)0x0) {
          free(DAT_00510078);
          DAT_00510078 = (undefined *)0x0;
        }
        if (DAT_00510080 != (undefined *)0x0) {
          free(DAT_00510080);
          DAT_00510080 = (undefined *)0x0;
        }
      }
    }
  }
  ImGui_EndChild();
LAB_002ea7f0:
  if (*(long *)(lVar3 + 0x28) != local_b8) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

