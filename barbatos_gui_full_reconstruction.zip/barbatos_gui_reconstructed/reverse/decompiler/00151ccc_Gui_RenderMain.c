/* Entry: 0x00151ccc; Ghidra function: Gui_RenderMain */


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Could not reconcile some variable overlaps */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_RenderMain(void)

{
  ulong *puVar1;
  char *pcVar2;
  float *pfVar3;
  byte bVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  long lVar8;
  ulong uVar9;
  ulong *puVar10;
  long lVar11;
  undefined8 *puVar12;
  ulong *puVar13;
  char *pcVar14;
  undefined1 *puVar15;
  undefined1 *puVar16;
  ulong uVar17;
  ulong uVar18;
  void *pvVar19;
  void *pvVar20;
  size_t sVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  undefined auVar26 [16];
  undefined8 uVar27;
  float fVar28;
  double dVar29;
  double dVar30;
  float fVar31;
  float fVar32;
  float fVar34;
  float fVar35;
  undefined auVar33 [16];
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  float fVar43;
  float fVar44;
  ulong local_480 [60];
  long local_2a0;
  ulong local_298;
  float local_28c;
  float local_288;
  float local_284;
  undefined8 local_280;
  ulong uStack632;
  ulong local_268;
  ulong local_260;
  ulong uStack600;
  ulong local_250;
  ulong uStack584;
  ulong local_240;
  size_t local_238;
  void *local_230;
  byte local_228 [16];
  void *local_218;
  ulong local_210;
  ulong uStack520;
  void *local_200;
  ulong local_1f0;
  ulong uStack488;
  void *local_1e0;
  ulong local_1d0;
  size_t sStack456;
  void *local_1c0;
  ulong local_1b0;
  size_t sStack424;
  void *local_1a0;
  float local_190;
  float fStack396;
  undefined uStack392;
  undefined6 uStack391;
  undefined uStack385;
  void *local_180;
  ulong local_170;
  ulong uStack360;
  void *local_160;
  float local_150;
  float fStack332;
  float local_148;
  float fStack324;
  ulong local_140;
  ulong uStack312;
  void *local_130;
  long local_b8;
  
  lVar11 = cRead_8(tpidr_el0);
  local_b8 = *(long *)(lVar11 + 0x28);
  if (DAT_004f32f4 == 1.0) {
    Gui_InitializeFrameState();
  }
  if ((((DAT_003950f8 != 0) && (DAT_004f32f4 == 1.0)) && (*DAT_004f8138 <= 0.01)) ||
     (((DAT_003950f8 != 0 && (DAT_004f32f4 == 0.0)) && (*DAT_004f7fa8 < 0.002)))) {
    DAT_003950fc = '\x01';
  }
  dVar30 = (double)DAT_004f7fa0;
  ImGui_GetIO();
  Gui_FormatBuffer(dVar30,&DAT_004f8171,0x200,"%.1f  %.1f  %.1f");
  uVar7 = ImGui_GetBackgroundDrawList();
  auVar26 = NEON_fmov(0x3f800000,4);
  uStack584 = SUB168(auVar26 >> 0x40,0);
  local_250 = SUB168(auVar26,0);
  local_170 = CONCAT44((float)(DAT_0050dbb0 + -100),0x42480000);
  local_140 = local_250;
  uStack312 = uStack584;
  uVar5 = ImGui_ColorConvertFloat4ToU32((float)(DAT_0050dbb0 + -100),local_250,&local_140);
  fVar22 = 0.0;
  ImDrawList_AddText(0x42180000,uVar7,0,&local_170,uVar5,&DAT_004f8171,0,0);
  if (DAT_004f32f4 == 0.0) {
    Gui_RenderBootLayer();
  }
  if (DAT_003950f8 == 0) {
    fVar22 = (float)DAT_0050dbac * 0.5;
    fVar25 = (float)NEON_fmadd(DAT_004f32ec,0xc2b40000,fVar22);
    if (((fVar25 < (float)DAT_0050e640) &&
        (fVar22 = (float)NEON_fmadd(DAT_004f32ec,0x42b40000,fVar22), (float)DAT_0050e640 < fVar22))
       && ((fVar22 = DAT_0050e640._4_4_, DAT_0050e640._4_4_ <= DAT_004f32ec * 140.0 &&
           (DAT_0050e632 == '\0')))) {
      if (DAT_0050e630 == '\0') {
        bVar4 = DAT_004f8170;
        if ((DAT_004f8170 != 1) || (DAT_004f8170 = 0, DAT_003950f8 = bVar4, DAT_004f32f4 != 0.0))
        goto LAB_00251e7c;
        DAT_004f8038 = (float)DAT_004f8160;
        DAT_004f8054 = DAT_004f8160._4_4_;
        DAT_004f8018 = (float)DAT_004f8160 + (float)DAT_004f8168;
        DAT_004f801c = DAT_004f8160._4_4_ + DAT_004f8168._4_4_;
        fVar22 = (float)DAT_004f8160 + (float)DAT_004f8168 * 0.5;
        DAT_004f7fcc = 0x3e23d70a;
        DAT_004f7fe0 = 0x3e23d70a;
        DAT_004f7fb8 = fVar22 + -50.0;
        DAT_004f7fbc = fVar22 + 50.0;
        DAT_004f8024 = (float)DAT_0050dbb0 * 1.1;
        _DAT_004f8008 = 0x3f3333333f800000;
        DAT_004f8010 = CONCAT44(DAT_004f8160._4_4_,(float)DAT_004f8160);
        DAT_004f7fc4 = DAT_004f7fbc - DAT_004f8018;
        dVar29 = (double)NEON_fmadd((double)(DAT_004f801c - DAT_004f8160._4_4_),0x3fd54fdf3b645a1d,
                                    (double)DAT_004f8160._4_4_);
        dVar30 = (double)NEON_fmadd((double)(DAT_004f801c - DAT_004f8160._4_4_),0x3fe55810624dd2f2,
                                    (double)DAT_004f8160._4_4_);
        DAT_004f7fd4 = 0;
        DAT_004f803c = (float)dVar29;
        DAT_004f8044 = (float)dVar30;
        DAT_004f80b0 = CONCAT44(DAT_004f8024,DAT_004f7fb8);
        DAT_004f7fe8 = 0;
        DAT_004f7ffc = 0;
        DAT_004f7fc0 = DAT_004f7fb8 - (float)DAT_004f8160;
        DAT_004f7fc8 = (float)DAT_0050dbb0 - DAT_004f801c;
        DAT_004f7fd8 = 0x3f800000;
        DAT_004f7fec = 0x3f800000;
        DAT_004f8000 = 0x3f800000;
        puVar15 = &DAT_004f8130;
        DAT_004f8020 = DAT_004f7fb8;
        DAT_004f8030 = DAT_004f8010;
        DAT_004f8040 = DAT_004f8038;
        DAT_004f8048 = DAT_004f8038;
        DAT_004f804c = DAT_004f801c;
        DAT_004f8050 = DAT_004f8018;
        DAT_004f8058 = DAT_004f8018;
        DAT_004f805c = DAT_004f803c;
        DAT_004f8060 = DAT_004f8018;
        DAT_004f8064 = DAT_004f8044;
        DAT_004f8068 = DAT_004f8018;
        DAT_004f806c = DAT_004f801c;
        DAT_004f80b8 = DAT_004f80b0;
        DAT_004f80c0 = DAT_004f80b0;
        DAT_004f80c8 = DAT_004f80b0;
        DAT_004f80d0 = DAT_004f80b0;
        DAT_004f80d8 = DAT_004f80b0;
        DAT_004f80e0 = DAT_004f80b0;
        DAT_004f80e8 = DAT_004f80b0;
        fVar22 = DAT_004f8018;
      }
      else {
        puVar15 = &DAT_004f8170;
      }
      *puVar15 = 1;
    }
  }
LAB_00251e7c:
  if (DAT_003950fc == '\0') goto LAB_002541c8;
  ImGui_GetIO();
  lVar8 = FUN_00292020();
  if (DAT_0050dbac < DAT_0050dbb0) {
    local_170 = 0;
    local_140 = 0x4396000042c80000;
    ImGui_SetNextWindowPos(&local_140,2,&local_170);
  }
  local_140 = CONCAT44(DAT_004f1834,DAT_004f1830);
  ImGui_SetNextWindowSize(&local_140,2);
  uVar5 = DAT_00395168;
  *(undefined4 *)(lVar8 + 0x2c) = DAT_00395168;
  *(undefined4 *)(lVar8 + 0x10) = uVar5;
  uVar9 = ImGui_Begin("Hello ImGui",0,0x202b);
  if ((uVar9 & 1) == 0) goto LAB_002541c8;
  local_268 = ImGui_GetWindowDrawList();
  DAT_004f14e4 = ImGui_GetWindowSize();
  DAT_004f14e8 = fVar22;
  DAT_004f14dc = ImGui_GetWindowPos();
  DAT_004f14e0 = fVar22;
  DAT_004f8160._0_4_ = (float)ImGui_GetWindowSize();
  DAT_004f8160._4_4_ = fVar22;
  fVar22 = DAT_004f8160._4_4_;
  DAT_004f8168._0_4_ = (float)ImGui_GetWindowPos();
  DAT_004f8168._4_4_ = fVar22;
  if (((DAT_004f8380 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_004f8380), iVar6 != 0)) {
    DAT_004f8378 = '\0';
    DAT_004f837c = 0.0;
    DAT_004f8374 = 0.08;
    FUN_0036eca0(&DAT_004f8380);
  }
  lVar8 = ImGui_GetIO();
  fVar22 = DAT_004f837c;
  if (44.0 <= 1000.0 / (*(float *)(lVar8 + 0x10) * 1000.0)) {
    fVar25 = 1.0;
    if (DAT_004f8378 == '\0') {
      fVar25 = 0.0;
    }
    lVar8 = ImGui_GetIO();
    fVar22 = (float)NEON_fmadd(*(float *)(lVar8 + 0x10) / DAT_004f8374,fVar25 - DAT_004f837c,fVar22)
    ;
    fVar25 = (float)NEON_fmin(fVar22,0x3f800000);
    DAT_004f837c = 0.0;
    if (0.0 <= fVar22) {
      DAT_004f837c = fVar25;
    }
  }
  local_170 = CONCAT44(DAT_004f8160._4_4_,(float)DAT_004f8160);
  local_190 = (float)DAT_004f8160 + (float)DAT_004f8168;
  fStack396 = DAT_004f8160._4_4_ + DAT_004f8168._4_4_;
  uStack312 = 0x3f6bebed3f52d2d4;
  local_140 = 0x3f52d2d43f52d2d4;
  local_2a0 = lVar11;
  fVar22 = local_190;
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
  ImDrawList_AddRectFilled(DAT_00395168,local_268,&local_170,&local_190,uVar5,0);
  local_140 = 0x43870000;
  ImGui_BeginChild("##left",&local_140,0,0x800008);
  fVar25 = (float)ImGui_GetCursorScreenPos();
  local_288 = (float)ImGui_GetWindowPos();
  local_260 = ImGui_GetWindowDrawList();
  uVar5 = ImGui_GetCursorScreenPos();
  ImGui_GetWindowPos();
  Gui_DrawWindowBackground(uVar5);
  if (((DAT_004f8388 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_004f8388), iVar6 != 0)) {
    FUN_0036eca0(&DAT_004f8388);
  }
  local_140 = 0x428c000043160000;
  uVar9 = ImGui_Button("off Mywindow",&local_140,0);
  if ((uVar9 & 1) != 0) {
    if (DAT_0050d798 != 0) {
      glDeleteTextures(1,&DAT_0050d798);
      DAT_0050d798 = 0;
    }
    puVar10 = DAT_0050d788;
    DAT_003950fc = '\0';
    DAT_003950f8 = 0;
    puVar13 = DAT_0050d780;
    if (DAT_004f32f4 == 1.0) {
      for (; puVar13 != puVar10; puVar13 = puVar13 + 1) {
                    /* WARNING: Read-only address (ram,0x0012b460) is written */
                    /* WARNING: Read-only address (ram,0x0012b530) is written */
                    /* WARNING: Read-only address (ram,0x0012b710) is written */
                    /* WARNING: Read-only address (ram,0x0012bbb0) is written */
                    /* WARNING: Read-only address (ram,0x0012bc10) is written */
                    /* WARNING: Read-only address (ram,0x0012bd00) is written */
        glDeleteTextures(1,puVar13);
      }
                    /* WARNING: Read-only address (ram,0x0012b460) is written */
                    /* WARNING: Read-only address (ram,0x0012b530) is written */
                    /* WARNING: Read-only address (ram,0x0012b710) is written */
                    /* WARNING: Read-only address (ram,0x0012bbb0) is written */
                    /* WARNING: Read-only address (ram,0x0012bc10) is written */
                    /* WARNING: Read-only address (ram,0x0012bd00) is written */
      iVar6 = 1;
      *DAT_004f8138 = 0.02;
      DAT_0050d788 = DAT_0050d780;
      do {
        local_170 = CONCAT44(DAT_004f8168._4_4_,(float)DAT_004f8168);
        local_140 = CONCAT44(DAT_004f8160._4_4_,(float)DAT_004f8160);
        uVar9 = Gui_RenderImageLayer("Hello ImGui",&local_140,&local_170,iVar6,iVar6);
        puVar13 = DAT_0050d780;
        if (DAT_0050d788 < DAT_0050d790) {
          *DAT_0050d788 = uVar9 & 0xffffffff;
          DAT_0050d788 = DAT_0050d788 + 1;
        }
        else {
          sVar21 = (long)DAT_0050d788 - (long)DAT_0050d780;
          uVar18 = ((long)sVar21 >> 3) + 1;
          if (uVar18 >> 0x3d != 0) {
                    /* WARNING: Subroutine does not return */
            FUN_0036e680(&DAT_0050d780);
          }
          uVar17 = (long)DAT_0050d790 - (long)DAT_0050d780 >> 2;
          if (uVar18 <= uVar17) {
            uVar18 = uVar17;
          }
          if (0x7ffffffffffffff7 < (ulong)((long)DAT_0050d790 - (long)DAT_0050d780)) {
            uVar18 = 0x1fffffffffffffff;
          }
          if (uVar18 == 0) {
            puVar10 = (ulong *)0x0;
          }
          else {
            if (uVar18 >> 0x3d != 0) {
                    /* WARNING: Subroutine does not return */
              FUN_00268d80("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
            }
            puVar10 = (ulong *)FUN_0036b114(uVar18 << 3);
          }
          puVar1 = puVar10 + ((long)sVar21 >> 3);
          *puVar1 = uVar9 & 0xffffffff;
          if (0 < (long)sVar21) {
            memcpy(puVar10,puVar13,sVar21);
          }
          DAT_0050d790 = puVar10 + uVar18;
          DAT_0050d780 = puVar10;
          DAT_0050d788 = puVar1 + 1;
          if (puVar13 != (ulong *)0x0) {
            free(puVar13);
          }
        }
        iVar6 = iVar6 + 1;
      } while (iVar6 != 9);
    }
    else {
      uVar9 = Gui_RenderImageLayer("Hello ImGui",&DAT_004f8160,&DAT_004f8168,1,1);
      DAT_004f801c = DAT_004f8160._4_4_ + DAT_004f8168._4_4_;
      DAT_0050d798 = uVar9 & 0xffffffff;
      DAT_004f7fcc = 0x3e23d70a;
      DAT_004f7fe0 = 0x3e23d70a;
      DAT_004f8018 = (float)DAT_004f8160 + (float)DAT_004f8168;
      DAT_004f8024 = (float)DAT_0050dbb0 * 1.1;
      fVar28 = (float)DAT_004f8160 + (float)DAT_004f8168 * 0.5;
      DAT_004f8010 = CONCAT44(DAT_004f8160._4_4_,(float)DAT_004f8160);
      DAT_004f7fd8 = 0;
      if (DAT_003950f8 != 0) {
        DAT_004f7fd8 = 0x3f800000;
      }
      DAT_004f8054 = DAT_004f8160._4_4_;
      DAT_004f7fb8 = fVar28 + -50.0;
      DAT_004f7fbc = fVar28 + 50.0;
      DAT_004f8048 = (float)DAT_004f8160;
      DAT_004f7fd4 = DAT_003950f8 ^ 1;
      _DAT_004f8008 = CONCAT44(0x3f333333,DAT_004f7fd8);
      dVar29 = (double)NEON_fmadd((double)(DAT_004f801c - DAT_004f8160._4_4_),0x3fd54fdf3b645a1d,
                                  (double)DAT_004f8160._4_4_);
      dVar30 = (double)NEON_fmadd((double)(DAT_004f801c - DAT_004f8160._4_4_),0x3fe55810624dd2f2,
                                  (double)DAT_004f8160._4_4_);
      DAT_004f80b0 = CONCAT44(DAT_004f8024,DAT_004f7fb8);
      DAT_004f7fc4 = DAT_004f7fbc - DAT_004f8018;
      DAT_004f803c = (float)dVar29;
      DAT_004f8044 = (float)dVar30;
      DAT_004f8038 = (float)DAT_004f8160;
      DAT_004f8040 = (float)DAT_004f8160;
      DAT_004f7fc0 = DAT_004f7fb8 - (float)DAT_004f8160;
      DAT_004f7fc8 = (float)DAT_0050dbb0 - DAT_004f801c;
      DAT_004f8130 = 1;
      DAT_004f7fe8 = DAT_004f7fd4;
      DAT_004f7fec = DAT_004f7fd8;
      DAT_004f7ffc = DAT_004f7fd4;
      DAT_004f8000 = DAT_004f7fd8;
      DAT_004f8020 = DAT_004f7fb8;
      DAT_004f8030 = DAT_004f8010;
      DAT_004f804c = DAT_004f801c;
      DAT_004f8050 = DAT_004f8018;
      DAT_004f8058 = DAT_004f8018;
      DAT_004f805c = DAT_004f803c;
      DAT_004f8060 = DAT_004f8018;
      DAT_004f8064 = DAT_004f8044;
      DAT_004f8068 = DAT_004f8018;
      DAT_004f806c = DAT_004f801c;
      DAT_004f80b8 = DAT_004f80b0;
      DAT_004f80c0 = DAT_004f80b0;
      DAT_004f80c8 = DAT_004f80b0;
      DAT_004f80d0 = DAT_004f80b0;
      DAT_004f80d8 = DAT_004f80b0;
      DAT_004f80e0 = DAT_004f80b0;
      DAT_004f80e8 = DAT_004f80b0;
    }
  }
  local_140 = CONCAT44(DAT_0050e640._4_4_,(float)DAT_0050e640);
  local_170 = CONCAT44(fVar22 + 70.0,fVar25);
  local_190 = 170.0;
  fStack396 = 160.0;
  uVar9 = FUN_0029027c(&local_140,&local_170,&local_190);
  uVar7 = local_260;
  if ((((uVar9 & 1) != 0) && (DAT_0050e632 != '\0')) && (DAT_0050e634 == '\0')) {
    DAT_004f8378 = '\x01';
  }
  if (DAT_0050d760 == '\0') {
    lVar11 = ImGui_GetIO();
    uVar9 = local_268;
    lVar8 = (long)(int)DAT_0050d758;
    DAT_0050d758._4_4_ =
         (float)NEON_fmadd(*(undefined4 *)(lVar11 + 0x10),0x461c4000,DAT_0050d758._4_4_);
    if ((float)*(int *)(DAT_0050d740 + lVar8 * 4) <= DAT_0050d758._4_4_) {
      uVar18 = DAT_0050d730 - DAT_0050d728 >> 2;
      iVar6 = 0;
      if (uVar18 != 0) {
        iVar6 = (int)((ulong)(long)((int)DAT_0050d758 + 1) / uVar18);
      }
      DAT_0050d758._0_4_ = ((int)DAT_0050d758 + 1) - iVar6 * (int)uVar18;
      lVar8 = (long)(int)DAT_0050d758;
      DAT_0050d758._4_4_ = 0.0;
    }
    local_140 = CONCAT44(DAT_004f8160._4_4_ + 70.0,(float)DAT_004f8160 + 58.0);
    local_170 = CONCAT44(DAT_004f8160._4_4_ + 70.0 + 270.0 + -116.0,
                         (float)DAT_004f8160 + -0.0 + 270.0 + -58.0);
    FUN_002ac0dc(local_268,*(undefined4 *)(DAT_0050d728 + lVar8 * 4));
    uVar5 = *(undefined4 *)(uVar9 + 0x20);
    FUN_002ade50(0x42a40000,uVar9,&local_140,&local_170,0);
    FUN_002acedc(uVar9,*(undefined8 *)(uVar9 + 0x80),*(undefined4 *)(uVar9 + 0x78),0xffffffff);
    local_1b0 = NEON_fmov(0x3f800000,4);
    *(undefined4 *)(uVar9 + 0x78) = 0;
    local_190 = 0.0;
    fStack396 = 0.0;
    FUN_002aed3c(uVar9,uVar5,*(undefined4 *)(uVar9 + 0x20),&local_140,&local_170,&local_190,
                 &local_1b0,1);
    FUN_002ac270(uVar9);
  }
  local_288 = fVar25 + local_288;
  local_284 = local_288 + -20.0;
  local_298 = 0x43870000;
  fVar22 = fVar22 + 50.0;
  local_280 = CONCAT44(local_280._4_4_,fVar25 + 20.0);
  fStack396 = fVar22 + 235.0;
  local_170 = CONCAT44(fVar22 + 195.0,fVar25 + 20.0);
  uStack312 = uStack584;
  local_140 = local_250;
  local_190 = local_284;
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
  ImDrawList_AddRectFilled(0x42000000,uVar7,&local_170,&local_190,uVar5,0);
  local_28c = fVar22 + 215.0;
  local_268 = local_268 & 0xffffffff00000000 | (ulong)(uint)(fVar25 + 50.0);
  fVar24 = local_28c;
  Gui_DrawTexture(DAT_0050d8b8);
  fVar23 = (float)ImGui_CalcTextSize(0x42080000,0,&DAT_0011b418);
  fVar28 = fVar24;
  ImGui_CalcTextSize(0x41e80000,0,&DAT_0011d6bc);
  fVar31 = fVar22 + 214.0;
  fVar25 = fVar25 + 75.0;
  uStack600 = SUB168(_DAT_0012b530 >> 0x40,0);
  local_260 = SUB168(_DAT_0012b530,0);
  local_170 = CONCAT44(fVar31 + fVar24 * -0.5,fVar25);
  local_140 = local_260;
  uStack312 = uStack600;
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
  ImDrawList_AddText(0x42080000,uVar7,0,&local_170,uVar5,&DAT_0011d6cb,0,0);
  if (*(int *)(DAT_004f8390 + 0x68) == 0) {
    local_170 = CONCAT44(fVar31 + fVar28 * -0.5,fVar25 + fVar23);
    uStack312 = uStack600;
    local_140 = local_260;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    pcVar14 = "DitPro";
  }
  else {
    local_170 = CONCAT44(fVar31 + fVar28 * -0.5,fVar25 + fVar23);
    uStack312 = uStack600;
    local_140 = local_260;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    pcVar14 = "Dome";
  }
  ImDrawList_AddText(0x41e80000,uVar7,0,&local_170,uVar5,pcVar14,0,0);
  uStack312 = SUB168(_DAT_0012b710 >> 0x40,0);
  local_140 = SUB168(_DAT_0012b710,0);
  local_170 = CONCAT44(local_28c,local_288 + -40.0);
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
  ImDrawList_AddCircle(0x40e00000,uVar7,&local_170,uVar5,0xc);
  fVar22 = fVar22 + 50.0;
  fStack396 = fVar22 + 235.0;
  local_170 = local_280 & 0xffffffff | (ulong)(uint)(fVar22 + 195.0) << 0x20;
  local_190 = local_284;
  uStack312 = uStack584;
  local_140 = local_250;
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
  ImDrawList_AddRectFilled(0x42000000,uVar7,&local_170,&local_190,uVar5,0);
  fVar23 = fVar22 + 215.0;
  Gui_DrawTexture(local_268 & 0xffffffff,DAT_0050d8c0);
  fVar24 = (float)ImGui_CalcTextSize(0x42080000,0,&DAT_0011abd8);
  fVar28 = fVar23;
  ImGui_CalcTextSize(0x41e80000,0,&DAT_00125c7a);
  local_170 = CONCAT44((fVar22 + 214.0) - fVar23 * 0.5,fVar25);
  uStack312 = uStack600;
  local_140 = local_260;
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
  ImDrawList_AddText(0x42080000,uVar7,0,&local_170,uVar5,&DAT_0011a32a,0,0);
  local_190 = fVar25 + fVar24;
  fStack396 = (fVar22 + 214.0) - fVar28 * 0.5;
  uStack360 = uStack600;
  local_170 = local_260;
  uVar5 = ImGui_ColorConvertFloat4ToU32(&local_170);
  FUN_0036ce38(DAT_004d3e7c);
  pvVar19 = (void *)((ulong)&local_140 | 1);
  if ((local_140 & 1) != 0) {
    pvVar19 = local_130;
  }
                    /* try { // try from 00252990 to 002529b3 has its CatchHandler @ 00254584 */
  ImDrawList_AddText(0x41e80000,uVar7,0,&local_190,uVar5,pvVar19,0,0);
  uVar9 = local_298;
  if ((local_140 & 1) != 0) {
    free(local_130);
  }
  ImGui_SetCursorPosY(0x43ac8000);
  Gui_SidebarTabs(0,&DAT_004f7f5c,&PTR_DAT_00395108 + (long)DAT_004f3d14 * 6,5,&DAT_0050d7a0);
  ImGui_EndChild();
  local_140 = uVar9;
  ImGui_SetCursorPos(&local_140);
  switch(DAT_004f7f5c) {
  case 0:
    Gui_RenderHomePage();
    break;
  case 1:
    Gui_RenderDrawPage();
    puVar15 = &DAT_0050e8e0;
    puVar16 = &DAT_0050e8dc;
    goto LAB_00252acc;
  case 2:
    Gui_RenderAimPage();
    puVar15 = &DAT_0050eaa0;
    puVar16 = &DAT_0050ea98;
    goto LAB_00252acc;
  case 3:
    Gui_RenderItemsPage();
    break;
  case 4:
    Gui_RenderSettingsPage();
    break;
  default:
    goto switchD_00252a50_caseD_5;
  }
  puVar15 = &DAT_0050e8e0;
  puVar16 = &DAT_0050e8dc;
  DAT_0050ea98 = 1;
  DAT_0050eaa4 = 0;
LAB_00252acc:
  *(undefined4 *)(puVar15 + 4) = 0;
  *puVar16 = 1;
switchD_00252a50_caseD_5:
  if (DAT_003950f8 != 0) {
    lVar11 = 0;
    fVar28 = (float)DAT_004f8160 + (float)DAT_004f8168;
    fVar25 = DAT_004f8160._4_4_ + DAT_004f8168._4_4_;
    fVar22 = fVar28 + -35.0;
    fVar23 = fVar28 + -8.0;
    fVar24 = fVar25 + -8.0;
    fVar31 = fVar25 + -35.0;
    fVar25 = fVar25 + -2.0;
    fVar28 = fVar28 + -2.0;
    auVar26 = _DAT_0012bd00;
    do {
      auVar33 = NEON_scvtf(auVar26,4);
      lVar8 = (long)local_480 + lVar11;
      auVar26 = CONCAT412(SUB164(auVar26 >> 0x60,0) + 4,
                          CONCAT48(SUB164(auVar26 >> 0x40,0) + 4,
                                   CONCAT44(SUB164(auVar26 >> 0x20,0) + 4,SUB164(auVar26,0) + 4)));
      lVar11 = lVar11 + 0x20;
      fVar32 = SUB164(auVar33,0) / 59.0;
      fVar34 = SUB164(auVar33 >> 0x20,0) / 59.0;
      fVar35 = SUB164(auVar33 >> 0x40,0) / 59.0;
      fVar36 = SUB164(auVar33 >> 0x60,0) / 59.0;
      fVar37 = (float)local_250 - fVar32;
      fVar38 = (float)(local_250 >> 0x20) - fVar34;
      fVar39 = (float)uStack584 - fVar35;
      fVar40 = (float)(uStack584 >> 0x20) - fVar36;
      fVar41 = (fVar32 + fVar32) * fVar37;
      fVar42 = (fVar34 + fVar34) * fVar38;
      fVar43 = (fVar35 + fVar35) * fVar39;
      fVar44 = (fVar36 + fVar36) * fVar40;
      cWrite_8(tmp_ldXn,lVar8);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar41 * fVar28 + fVar23 * fVar37 * fVar37 + fVar22 * fVar32 * fVar32;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar41 * fVar25 + fVar31 * fVar37 * fVar37 + fVar24 * fVar32 * fVar32;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar42 * fVar28 + fVar23 * fVar38 * fVar38 + fVar22 * fVar34 * fVar34;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar42 * fVar25 + fVar31 * fVar38 * fVar38 + fVar24 * fVar34 * fVar34;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar43 * fVar28 + fVar23 * fVar39 * fVar39 + fVar22 * fVar35 * fVar35;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar43 * fVar25 + fVar31 * fVar39 * fVar39 + fVar24 * fVar35 * fVar35;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar44 * fVar28 + fVar23 * fVar40 * fVar40 + fVar22 * fVar36 * fVar36;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
      pfVar3 = (float *)cRead_8(tmp_ldXn);
      *pfVar3 = fVar44 * fVar25 + fVar31 * fVar40 * fVar40 + fVar24 * fVar36 * fVar36;
      lVar8 = cRead_8(tmp_ldXn);
      cWrite_8(tmp_ldXn,lVar8 + 4);
    } while (lVar11 != 0x1e0);
    lVar11 = 0;
    uStack584 = 0x3f8000003e70f0f2;
    local_250 = 0x3e70f0f23e70f0f2;
    do {
      uVar7 = FUN_00295488();
      local_170 = *(ulong *)((long)local_480 + lVar11);
      uStack312 = uStack584;
      local_140 = local_250;
      uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
      ImDrawList_AddCircle(0x40a00000,uVar7,&local_170,uVar5,0xc);
      lVar11 = lVar11 + 8;
    } while (lVar11 != 0x1e0);
    if ((((DAT_0050e630 != '\0') &&
         ((float)DAT_0050e640 < (float)DAT_004f8160 + (float)DAT_004f8168)) &&
        (((float)DAT_004f8160 + (float)DAT_004f8168 + -35.0 < (float)DAT_0050e640 &&
         ((DAT_0050e640._4_4_ < DAT_004f8160._4_4_ + DAT_004f8168._4_4_ &&
          (DAT_004f8160._4_4_ + DAT_004f8168._4_4_ + -35.0 < DAT_0050e640._4_4_)))))) ||
       (DAT_004f8398 == '\x01')) {
      DAT_004f8398 = '\x01';
      uVar7 = FUN_00295488();
      local_170 = CONCAT44(DAT_004f8160._4_4_ + -50.0,(float)DAT_004f8160 + -50.0);
      local_190 = (float)DAT_004f8160 + (float)DAT_004f8168 + 50.0;
      fStack396 = DAT_004f8160._4_4_ + DAT_004f8168._4_4_ + 50.0;
      uStack312 = 0x3f8000003f70f0f2;
      local_140 = 0x3f70f0f23f70f0f2;
      uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
      ImDrawList_AddRect(0x41900000,uVar7,&local_170,&local_190,uVar5,0);
      if (DAT_0050e639 != '\0') {
        fVar22 = (float)NEON_fmadd(DAT_0050e648 - (float)DAT_0050e640,0xbf99999a,DAT_004f1830);
        if (960.0 < fVar22) {
          DAT_004f1830 = fVar22;
        }
        fVar22 = (float)NEON_fmadd(DAT_0050e64c - DAT_0050e640._4_4_,0xbf99999a,DAT_004f1834);
        if (700.0 < fVar22) {
          DAT_004f1834 = fVar22;
        }
        local_140 = CONCAT44(DAT_004f1834,DAT_004f1830);
        ImGui_SetWindowSize("Hello ImGui",&local_140,0);
      }
    }
    if (DAT_0050e630 == '\0') {
      DAT_004f8398 = '\0';
    }
  }
  if (((DAT_004f83b0 & 1) == 0) && (iVar6 = FUN_0036eb48(&DAT_004f83b0), iVar6 != 0)) {
    DAT_004f83a4 = '\0';
    DAT_004f83a8 = 0.0;
    DAT_004f83a0 = 0.08;
    FUN_0036eca0(&DAT_004f83b0);
  }
  lVar11 = ImGui_GetIO();
  fVar22 = DAT_004f83a8;
  if (44.0 <= 1000.0 / (*(float *)(lVar11 + 0x10) * 1000.0)) {
    fVar25 = 0.0;
    if (DAT_004f83a4 != '\0') {
      fVar25 = 1.0;
    }
    lVar11 = ImGui_GetIO();
    fVar22 = (float)NEON_fmadd(*(float *)(lVar11 + 0x10) / DAT_004f83a0,fVar25 - DAT_004f83a8,fVar22
                              );
    fVar25 = (float)NEON_fmin(fVar22,0x3f800000);
    DAT_004f83a8 = 0.0;
    if (0.0 <= fVar22) {
      DAT_004f83a8 = fVar25;
    }
  }
  DAT_004f83a4 = DAT_004f83b8;
  if ((((DAT_004f83b8 != '\0') && (DAT_0039516c == '\0')) && (6 < DAT_004f839c)) &&
     (DAT_0039516d == '\0')) {
    DAT_00395170 = Gui_RenderImageLayer
                             ("Hello ImGui",&DAT_004f8160,&DAT_004f8168,(int)DAT_00395174,4);
    DAT_0039516c = '\x01';
  }
  if ((DAT_0039516c != '\0') && (DAT_0039516d == '\0')) {
    local_140 = 0;
    ImGui_SetCursorPos(&local_140);
    local_140 = 0;
    ImGui_BeginChild("##BottomBlur",&local_140,0,0x800008);
    uVar7 = ImGui_GetWindowDrawList();
    local_140 = CONCAT44(DAT_004f8160._4_4_ + DAT_004f8168._4_4_,
                         (float)DAT_004f8160 + (float)DAT_004f8168);
    uVar27 = NEON_fmov(0x3f800000,4);
    local_170 = 0;
    local_190 = (float)uVar27;
    fStack396 = (float)((ulong)uVar27 >> 0x20);
    ImDrawList_AddRectFilledMultiColor
              (DAT_00395168,uVar7,DAT_00395170,&DAT_004f8160,&local_140,&local_170,&local_190,
               (int)(DAT_004f83a8 * 255.0) * 0x1000000 + 0x1ffffff,0);
    local_170 = CONCAT44(DAT_004f8160._4_4_ + DAT_004f8168._4_4_,
                         (float)DAT_004f8160 + (float)DAT_004f8168);
    local_140 = 0x3f1696973f169697;
    uStack312 = CONCAT44((float)(int)(DAT_004f83a8 * 100.0) * 0.003921569,0x3f169697);
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    ImDrawList_AddRectFilled(DAT_00395168,uVar7,&DAT_004f8160,&local_170,uVar5,0);
    ImGui_EndChild();
    if ((DAT_004f83a4 == '\0') &&
       ((DAT_004f83a8 <= 0.02 && (DAT_0039516c = '\0', DAT_00395170 != 0)))) {
      glDeleteBuffers(1,&DAT_00395170);
      DAT_00395170 = 0;
    }
  }
  DAT_004f839c = DAT_004f839c + 1;
  if (0.02 < DAT_004f83a8) {
    uVar5 = NEON_fmsub(DAT_004f83a8,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 50.0);
    local_140 = CONCAT44(uVar5,0x42480000);
    ImGui_SetCursorPos(&local_140);
    uStack312 = 0x3f4000003f800000;
    local_140 = 0x3f8000003f800000;
    ImGui_PushStyleColor(3,&local_140);
    auVar26 = ZEXT816(CONCAT44(DAT_004f8168._4_4_,(float)DAT_004f8168));
    local_140 = CONCAT44(SUB164(auVar26 >> 0x20,0) + -100.0,(float)DAT_004f8168 + -100.0);
    ImGui_BeginChild("##UpdatePage",&local_140,0,0x80000c);
    fVar25 = SUB164(auVar26,0);
    ImGui_PopStyleColor(1);
    local_250 = ImGui_GetCursorScreenPos();
    fVar28 = 20.0;
    fVar24 = fVar25 + 20.0;
    fVar22 = (float)ImGui_GetWindowPos();
    lVar11 = ImGui_GetWindowDrawList();
    Gui_DrawWindowBackground(local_250);
    pcVar14 = "Find the new version";
    pcVar2 = &UNK_0011bc47;
    if (DAT_004f3d14 != 0) {
      pcVar2 = pcVar14;
    }
    fVar23 = (float)ImGui_CalcTextSize(0x42540000,0,pcVar2);
    fVar22 = fVar22 * 0.5;
    fVar31 = (float)local_250 + fVar22;
    uStack312 = SUB168(_DAT_0012b460 >> 0x40,0);
    local_140 = SUB168(_DAT_0012b460,0);
    local_170 = CONCAT44(fVar24,fVar31 - fVar23 * 0.5);
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    pcVar2 = &UNK_0011bc47;
    if (DAT_004f3d14 != 0) {
      pcVar2 = pcVar14;
    }
    ImDrawList_AddText(0x42540000,lVar11,0,&local_170,uVar5,pcVar2,0,0);
    local_284 = (float)local_250 + 140.0;
    fVar32 = fVar24 + 70.0;
    local_148 = (float)local_250 + 58.0;
    local_150 = local_284 + 58.0;
    fStack332 = fVar32 + 140.0;
    local_268 = local_268 & 0xffffffff00000000 | (ulong)(uint)local_148;
    fStack324 = fVar32;
    FUN_002ac0dc(lVar11,*(undefined4 *)(DAT_0050d728 + (long)(int)DAT_0050d758 * 4));
    uVar5 = *(undefined4 *)(lVar11 + 0x20);
    FUN_002ade50(0x41e00000,lVar11,&local_148,&local_150,0);
    FUN_002acedc(lVar11,*(undefined8 *)(lVar11 + 0x80),*(undefined4 *)(lVar11 + 0x78),0xffffffff);
    local_170 = NEON_fmov(0x3f800000,4);
    *(undefined4 *)(lVar11 + 0x78) = 0;
    local_140 = 0;
    FUN_002aed3c(lVar11,uVar5,*(undefined4 *)(lVar11 + 0x20),&local_148,&local_150,&local_140,
                 &local_170,1);
    FUN_002ac270(lVar11);
    fVar24 = fVar24 + 8.0 + 70.0 + 48.0 + 38.0;
    local_260 = (ulong)(uint)fVar24;
    uStack600 = 0;
    fVar23 = (float)local_250 + 10.0;
    local_250 = CONCAT44(fVar24 + 5.0,fVar23);
    fVar23 = fVar23 + 210.0;
    uStack584 = 0;
    uStack632 = 0x3f8000003e20a0a1;
    local_280 = 0x3e20a0a13e20a0a1;
    local_170 = CONCAT44(fVar32,fVar23);
    uStack312 = 0x3f8000003e20a0a1;
    local_140 = 0x3e20a0a13e20a0a1;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    ImDrawList_AddText(0x42400000,lVar11,0,&local_170,uVar5,&DAT_00125310,0,0);
    Gui_FormatBuffer(&local_140,0x80,"nullptr | %s -> %s",&DAT_004f83b9,&DAT_004f83d9);
    fStack396 = fVar32 + 48.0;
    uStack360 = SUB168(_DAT_0012bbb0 >> 0x40,0);
    local_170 = SUB168(_DAT_0012bbb0,0);
    local_190 = fVar23;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_170);
    fVar24 = 0.0;
    ImDrawList_AddText(0x42180000,lVar11,0,&local_190,uVar5,&local_140,0,0);
    pcVar2 = &UNK_0011bc47;
    if (DAT_004f3d14 != 0) {
      pcVar2 = pcVar14;
    }
    fVar32 = (float)ImGui_CalcTextSize(0x42000000,0,pcVar2);
    local_190 = fVar23 + fVar32 + 20.0;
    local_170 = CONCAT44((float)local_260,fVar23);
    fStack396 = (float)local_260 + fVar24 + 10.0;
    uStack312 = 0x3f8000003f1f9fa0;
    local_140 = 0x3f3bbbbc3f048485;
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    ImDrawList_AddRectFilled(DAT_00395168,lVar11,&local_170,&local_190,uVar5,0);
    local_170 = CONCAT44((float)(local_250 >> 0x20) + -1.0,(float)local_250 + 220.0);
    uStack312 = SUB168(_DAT_0012bc10 >> 0x40,0);
    local_140 = SUB168(_DAT_0012bc10,0);
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    pcVar2 = &UNK_0011bc47;
    if (DAT_004f3d14 != 0) {
      pcVar2 = pcVar14;
    }
    ImDrawList_AddText(0x42000000,lVar11,0,&local_170,uVar5,pcVar2,0,0);
    pvVar19 = (void *)((ulong)&local_170 | 1);
    lVar8 = 0xf;
    pcVar14 = &UNK_0011bc47;
    if (DAT_004f3d14 != 0) {
      lVar8 = 0x12;
      pcVar14 = "Find a new version";
    }
    local_170 = local_170 & 0xffffffffffffff00 | (ulong)(byte)((int)lVar8 << 1);
    __memcpy_chk(pvVar19,pcVar14,lVar8,0x17);
    *(undefined *)((long)pvVar19 + lVar8) = 0;
                    /* try { // try from 002534c0 to 0025352f has its CatchHandler @ 0025459c */
    FUN_0036c1a8(&local_170,&DAT_0011abe4);
    pcVar14 = &UNK_0012303b;
    if (DAT_004f3d14 != 0) {
      pcVar14 = "[Mandatory update]";
    }
    pcVar2 = &UNK_00128386;
    if (DAT_004f3d14 != 0) {
      pcVar2 = "[Not mandatory update]";
    }
    if (DAT_004f83f9 != '\0') {
      pcVar2 = pcVar14;
    }
    FUN_0036c1a8(&local_170,pcVar2);
    FUN_0036c1a8(&local_170,&DAT_0012532b);
    iVar6 = DAT_004f3d14;
    sVar21 = strlen((char *)&DAT_004f83b9);
    if (0xffffffffffffffef < sVar21) {
                    /* try { // try from 00254310 to 00254317 has its CatchHandler @ 0025457c */
                    /* WARNING: Subroutine does not return */
      FUN_0036b804(&local_1b0);
    }
    if (sVar21 < 0x17) {
      pvVar20 = (void *)((ulong)&local_1b0 | 1);
      local_1b0 = local_1b0 & 0xffffffffffffff00 | (ulong)(byte)((int)sVar21 << 1);
      if (sVar21 != 0) goto LAB_00253594;
    }
    else {
      uVar9 = sVar21 + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 0025357c to 00253583 has its CatchHandler @ 0025457c */
      pvVar20 = (void *)FUN_0036b114(uVar9);
      local_1b0 = uVar9 | 1;
      sStack424 = sVar21;
      local_1a0 = pvVar20;
LAB_00253594:
      memcpy(pvVar20,&DAT_004f83b9,sVar21);
    }
    *(undefined *)((long)pvVar20 + sVar21) = 0;
    pcVar14 = &UNK_0011c494;
    if (iVar6 != 0) {
      pcVar14 = "Now version:";
    }
                    /* try { // try from 002535c4 to 002535cf has its CatchHandler @ 00254560 */
    puVar12 = (undefined8 *)FUN_0036bd6c(&local_1b0,0,pcVar14);
    local_180 = (void *)puVar12[2];
    uVar7 = puVar12[1];
    uStack392 = (undefined)uVar7;
    uStack391 = (undefined6)((ulong)uVar7 >> 8);
    uStack385 = (undefined)((ulong)uVar7 >> 0x38);
    local_190 = (float)*puVar12;
    fStack396 = (float)((ulong)*puVar12 >> 0x20);
    puVar12[1] = 0;
    puVar12[2] = 0;
    *puVar12 = 0;
                    /* try { // try from 002535e8 to 002535f7 has its CatchHandler @ 00254540 */
    puVar13 = (ulong *)FUN_0036c1a8(&local_190,&DAT_0012532b);
    local_130 = (void *)puVar13[2];
    uStack312 = puVar13[1];
    local_140 = *puVar13;
    puVar13[1] = 0;
    puVar13[2] = 0;
    *puVar13 = 0;
    uVar9 = local_140 >> 1 & 0x7f;
    pvVar20 = (void *)((ulong)&local_140 | 1);
    if ((local_140 & 1) != 0) {
      uVar9 = uStack312;
      pvVar20 = local_130;
    }
                    /* try { // try from 00253630 to 00253637 has its CatchHandler @ 0025450c */
    FUN_0036bca0(&local_170,pvVar20,uVar9);
    if ((local_140 & 1) != 0) {
      free(local_130);
    }
    if (((uint)local_190 & 1) != 0) {
      free(local_180);
    }
    if ((local_1b0 & 1) != 0) {
      free(local_1a0);
    }
    iVar6 = DAT_004f3d14;
    sVar21 = strlen(&DAT_004f83d9);
    if (0xffffffffffffffef < sVar21) {
                    /* try { // try from 00254318 to 0025431f has its CatchHandler @ 00254578 */
                    /* WARNING: Subroutine does not return */
      FUN_0036b804(&local_1b0);
    }
    if (sVar21 < 0x17) {
      pvVar20 = (void *)((ulong)&local_1b0 | 1);
      local_1b0 = local_1b0 & 0xffffffffffffff00 | (ulong)(byte)((int)sVar21 << 1);
      if (sVar21 != 0) goto LAB_002536e0;
    }
    else {
      uVar9 = sVar21 + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 002536c8 to 002536cf has its CatchHandler @ 00254578 */
      pvVar20 = (void *)FUN_0036b114(uVar9);
      local_1b0 = uVar9 | 1;
      sStack424 = sVar21;
      local_1a0 = pvVar20;
LAB_002536e0:
      memcpy(pvVar20,&DAT_004f83d9,sVar21);
    }
    *(undefined *)((long)pvVar20 + sVar21) = 0;
    pcVar14 = &UNK_00125c88;
    if (iVar6 != 0) {
      pcVar14 = "New version:";
    }
                    /* try { // try from 00253710 to 0025371b has its CatchHandler @ 00254508 */
    puVar12 = (undefined8 *)FUN_0036bd6c(&local_1b0,0,pcVar14);
    local_180 = (void *)puVar12[2];
    uVar7 = puVar12[1];
    uStack392 = (undefined)uVar7;
    uStack391 = (undefined6)((ulong)uVar7 >> 8);
    uStack385 = (undefined)((ulong)uVar7 >> 0x38);
    local_190 = (float)*puVar12;
    fStack396 = (float)((ulong)*puVar12 >> 0x20);
    puVar12[1] = 0;
    puVar12[2] = 0;
    *puVar12 = 0;
                    /* try { // try from 00253734 to 00253743 has its CatchHandler @ 00254504 */
    puVar13 = (ulong *)FUN_0036c1a8(&local_190,&DAT_0012532b);
    local_130 = (void *)puVar13[2];
    uStack312 = puVar13[1];
    local_140 = *puVar13;
    puVar13[1] = 0;
    puVar13[2] = 0;
    *puVar13 = 0;
    uVar9 = local_140 >> 1 & 0x7f;
    pvVar20 = (void *)((ulong)&local_140 | 1);
    if ((local_140 & 1) != 0) {
      uVar9 = uStack312;
      pvVar20 = local_130;
    }
                    /* try { // try from 0025377c to 00253783 has its CatchHandler @ 00254500 */
    FUN_0036bca0(&local_170,pvVar20,uVar9);
    if ((local_140 & 1) != 0) {
      free(local_130);
    }
    if (((uint)local_190 & 1) != 0) {
      free(local_180);
    }
    if ((local_1b0 & 1) != 0) {
      free(local_1a0);
    }
    if (DAT_004f7d30 != '\0') {
      if ((int)DAT_004f7d34 < 1) {
        uVar9 = DAT_004f7d48;
        uVar7 = DAT_004f7d50;
        if ((DAT_004f7d40 & 1) == 0) {
          uVar9 = (ulong)(DAT_004f7d40 >> 1);
          uVar7 = 0x4f7d41;
        }
                    /* try { // try from 0025391c to 00253923 has its CatchHandler @ 0025459c */
        FUN_0036bca0(&local_170,uVar7,uVar9);
      }
      else {
                    /* try { // try from 002537d8 to 00253817 has its CatchHandler @ 00254598 */
        Gui_FormatBuffer((double)(DAT_004f7d34 / 1024000.0),&local_140,0x80,&DAT_001192af);
        pcVar14 = &UNK_0011d6e0;
        if (DAT_004f3d14 != 0) {
          pcVar14 = "Size:";
        }
        FUN_0036c1a8(&local_170,pcVar14);
                    /* try { // try from 00253820 to 00253827 has its CatchHandler @ 00254494 */
        FUN_0036ce38((int)DAT_004f7d34);
                    /* try { // try from 00253828 to 0025383b has its CatchHandler @ 00254484 */
        puVar13 = (ulong *)FUN_0036bd6c(local_228,0,&DAT_0011abe4);
        local_200 = (void *)puVar13[2];
        uStack520 = puVar13[1];
        local_210 = *puVar13;
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
                    /* try { // try from 00253854 to 00253863 has its CatchHandler @ 00254474 */
        puVar13 = (ulong *)FUN_0036c1a8(&local_210,&DAT_001188c4);
        local_1e0 = (void *)puVar13[2];
        uStack488 = puVar13[1];
        local_1f0 = *puVar13;
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
                    /* try { // try from 0025387c to 0025388b has its CatchHandler @ 00254464 */
        puVar13 = (ulong *)FUN_0036c1a8(&local_1f0,&DAT_0011b421);
        local_1c0 = (void *)puVar13[2];
        sStack456 = puVar13[1];
        local_1d0 = *puVar13;
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
        sVar21 = strlen((char *)&local_140);
        if (0xffffffffffffffef < sVar21) {
                    /* try { // try from 00254320 to 00254327 has its CatchHandler @ 002544ac */
                    /* WARNING: Subroutine does not return */
          FUN_0036b804(&local_240);
        }
        if (sVar21 < 0x17) {
          pvVar20 = (void *)((ulong)&local_240 | 1);
          local_240 = local_240 & 0xffffffffffffff00 | (ulong)(byte)((int)sVar21 << 1);
          if (sVar21 != 0) goto LAB_00253ac0;
        }
        else {
          local_240 = sVar21 + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 00253a9c to 00253aa3 has its CatchHandler @ 002544ac */
          pvVar20 = (void *)FUN_0036b114(local_240);
          local_240 = local_240 | 1;
          local_238 = sVar21;
          local_230 = pvVar20;
LAB_00253ac0:
          memcpy(pvVar20,&local_140,sVar21);
        }
        *(undefined *)((long)pvVar20 + sVar21) = 0;
        sVar21 = local_240 >> 1 & 0x7f;
        pvVar20 = (void *)((ulong)&local_240 | 1);
        if ((local_240 & 1) != 0) {
          sVar21 = local_238;
          pvVar20 = local_230;
        }
                    /* try { // try from 00253af4 to 00253afb has its CatchHandler @ 00254444 */
        puVar13 = (ulong *)FUN_0036bca0(&local_1d0,pvVar20,sVar21);
        local_1a0 = (void *)puVar13[2];
        sStack424 = puVar13[1];
        local_1b0 = *puVar13;
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
                    /* try { // try from 00253b14 to 00253b23 has its CatchHandler @ 00254424 */
        puVar13 = (ulong *)FUN_0036c1a8(&local_1b0,&DAT_00122620);
        local_180 = (void *)puVar13[2];
        uVar17 = puVar13[1];
        uVar18 = *puVar13;
        uStack392 = (undefined)uVar17;
        uStack391 = (undefined6)(uVar17 >> 8);
        uStack385 = (undefined)(uVar17 >> 0x38);
        local_190 = (float)uVar18;
        fStack396 = (float)(uVar18 >> 0x20);
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
        uVar9 = uVar18 >> 1 & 0x7f;
        pvVar20 = (void *)((ulong)&local_190 | 1);
        if ((uVar18 & 1) != 0) {
          uVar9 = uVar17;
          pvVar20 = local_180;
        }
                    /* try { // try from 00253b5c to 00253b63 has its CatchHandler @ 002543d0 */
        FUN_0036bca0(&local_170,pvVar20,uVar9);
        if (((uint)local_190 & 1) != 0) {
          free(local_180);
        }
        if ((local_1b0 & 1) != 0) {
          free(local_1a0);
        }
        if ((local_240 & 1) != 0) {
          free(local_230);
        }
        if ((local_1d0 & 1) != 0) {
          free(local_1c0);
        }
        if ((local_1f0 & 1) != 0) {
          free(local_1e0);
        }
        if ((local_210 & 1) != 0) {
          free(local_200);
        }
        if ((local_228[0] & 1) != 0) {
          free(local_218);
        }
                    /* try { // try from 00253ba4 to 00253bff has its CatchHandler @ 00254598 */
        FUN_0036c1a8(&local_170,&DAT_0012532b);
        Gui_FormatBuffer((double)DAT_004f7d38,&local_140,0x80,&DAT_001192af);
        pcVar14 = &UNK_00129420;
        if (DAT_004f3d14 != 0) {
          pcVar14 = "Load progress:";
        }
        FUN_0036c1a8(&local_170,pcVar14);
        sVar21 = strlen((char *)&local_140);
        if (0xffffffffffffffef < sVar21) {
                    /* try { // try from 00254328 to 0025432f has its CatchHandler @ 002544a8 */
                    /* WARNING: Subroutine does not return */
          FUN_0036b804(&local_1d0);
        }
        if (sVar21 < 0x17) {
          pvVar20 = (void *)((ulong)&local_1d0 | 1);
          local_1d0 = local_1d0 & 0xffffffffffffff00 | (ulong)(byte)((int)sVar21 << 1);
          if (sVar21 != 0) goto LAB_00253cd8;
        }
        else {
          uVar9 = sVar21 + 0x10 & 0xfffffffffffffff0;
                    /* try { // try from 00253cb0 to 00253cb7 has its CatchHandler @ 002544a8 */
          pvVar20 = (void *)FUN_0036b114(uVar9);
          local_1d0 = uVar9 | 1;
          sStack456 = sVar21;
          local_1c0 = pvVar20;
LAB_00253cd8:
          memcpy(pvVar20,&local_140,sVar21);
        }
        *(undefined *)((long)pvVar20 + sVar21) = 0;
                    /* try { // try from 00253cec to 00253cff has its CatchHandler @ 002543b8 */
        puVar13 = (ulong *)FUN_0036bd6c(&local_1d0,0,&DAT_0011abe4);
        local_1a0 = (void *)puVar13[2];
        sStack424 = puVar13[1];
        local_1b0 = *puVar13;
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
                    /* try { // try from 00253d18 to 00253d27 has its CatchHandler @ 00254398 */
        puVar13 = (ulong *)FUN_0036c1a8(&local_1b0,&DAT_00118086);
        local_180 = (void *)puVar13[2];
        uVar17 = puVar13[1];
        uVar18 = *puVar13;
        uStack392 = (undefined)uVar17;
        uStack391 = (undefined6)(uVar17 >> 8);
        uStack385 = (undefined)(uVar17 >> 0x38);
        local_190 = (float)uVar18;
        fStack396 = (float)(uVar18 >> 0x20);
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
        uVar9 = uVar18 >> 1 & 0x7f;
        pvVar20 = (void *)((ulong)&local_190 | 1);
        if ((uVar18 & 1) != 0) {
          uVar9 = uVar17;
          pvVar20 = local_180;
        }
                    /* try { // try from 00253d60 to 00253d67 has its CatchHandler @ 00254364 */
        FUN_0036bca0(&local_170,pvVar20,uVar9);
        if (((uint)local_190 & 1) != 0) {
          free(local_180);
        }
        if ((local_1b0 & 1) != 0) {
          free(local_1a0);
        }
        if ((local_1d0 & 1) != 0) {
          free(local_1c0);
        }
        if (DAT_004f7d31 != '\0') {
          pcVar14 = &UNK_001266ec;
          if (DAT_004f3d14 != 0) {
            pcVar14 = "Start a new one for you";
          }
                    /* try { // try from 00253de0 to 00253de7 has its CatchHandler @ 00254598 */
          FUN_0036c1a8(&local_170,pcVar14);
        }
      }
    }
    fVar24 = fVar25 + 70.0 + 48.0;
    fStack396 = fVar24 + 40.0 + 90.0;
    local_190 = (float)local_268;
    uStack312 = uStack632;
    local_140 = local_280;
                    /* try { // try from 00253e2c to 00253e6b has its CatchHandler @ 00254580 */
    uVar5 = ImGui_ColorConvertFloat4ToU32(&local_140);
    if ((local_170 & 1) != 0) {
      pvVar19 = local_160;
    }
    ImDrawList_AddText(0x42200000,lVar11,0,&local_190,uVar5,pvVar19,0,0);
    local_140 = CONCAT44(fVar24 + 65.0,fVar31);
                    /* try { // try from 00253e7c to 00253e83 has its CatchHandler @ 002544fc */
    ImGui_SetCursorScreenPos(&local_140);
                    /* try { // try from 00253e98 to 00253e9f has its CatchHandler @ 0025459c */
    Gui_TextBox(fVar22,DAT_004f8400);
    fVar25 = fVar25 + fVar28 + -100.0;
    local_140 = CONCAT44(fVar25,local_284);
                    /* try { // try from 00253eb8 to 00253ebf has its CatchHandler @ 002544f8 */
    ImGui_SetCursorScreenPos(&local_140);
    pcVar14 = &UNK_0011bc57;
    if (DAT_004f3d14 != 0) {
      pcVar14 = "Cancel Update";
    }
                    /* try { // try from 00253f2c to 00253f67 has its CatchHandler @ 0025459c */
    uVar9 = Gui_UpdateAction(fVar22 + -160.0,pcVar14);
    if ((uVar9 & 1) != 0) {
      DAT_004fafec = 0;
      DAT_004f83b8 = '\0';
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004fafe8);
    }
    local_140 = CONCAT44(fVar25,fVar31 + 20.0);
                    /* try { // try from 00253f74 to 00253f7b has its CatchHandler @ 002544f4 */
    ImGui_SetCursorScreenPos(&local_140);
    pcVar14 = &UNK_0011abf3;
    pcVar2 = &UNK_00121b95;
    if (DAT_004f3d14 != 0) {
      pcVar14 = "Confirm Update";
      pcVar2 = "Download";
    }
    if (DAT_004f7d30 != '\0') {
      pcVar14 = pcVar2;
    }
                    /* try { // try from 00253fc0 to 00254007 has its CatchHandler @ 0025459c */
    bVar4 = Gui_UpdateAction(fVar22 + -160.0,pcVar14);
    if ((bVar4 & DAT_004f7d30 == '\0') == 1) {
      DAT_004f7d30 = '\x01';
      uVar7 = FUN_0036b114(8);
                    /* try { // try from 0025400c to 00254017 has its CatchHandler @ 00254498 */
      Gui_UpdateCleanup(uVar7,FUN_00250da4);
    }
    if (DAT_004f83b8 != '\0') {
      pcVar14 = &UNK_001241e1;
      pcVar2 = &UNK_00121b95;
      if (DAT_004f3d14 != 0) {
        pcVar14 = "Use Update";
        pcVar2 = "Download";
      }
      if (DAT_004f7d30 != '\0') {
        pcVar14 = pcVar2;
      }
      DAT_004fafec = 1;
      __strcpy_chk(&DAT_004fb0b8,pcVar14,0x80);
      if ((int)DAT_004f7d34 < 1) {
        uRam00000000004fb040 = 0xe5968fe5b7;
        uRam00000000004fb045 = 0xa7a4;
        DAT_004fb047 = 0x8fb0e5;
        DAT_004fb038._0_5_ = 0x9ce5a3ade6;
        DAT_004fb038._5_3_ = 0x8ee8a8;
      }
      else {
        uStack385 = 0;
        local_190 = -2.903843e-07;
        fStack396 = -6.671361e+24;
        uStack392 = 0xbf;
        uStack391 = 0x203aa6bae59b;
                    /* try { // try from 002540c4 to 002540cf has its CatchHandler @ 0025434c */
        FUN_0036ce38((int)DAT_004f7d38);
        sVar21 = local_1b0 >> 1 & 0x7f;
        pvVar19 = (void *)((ulong)&local_1b0 | 1);
        if ((local_1b0 & 1) != 0) {
          sVar21 = sStack424;
          pvVar19 = local_1a0;
        }
                    /* try { // try from 002540ec to 002540f3 has its CatchHandler @ 00254334 */
        puVar13 = (ulong *)FUN_0036bca0(&local_190,pvVar19,sVar21);
        local_130 = (void *)puVar13[2];
        uStack312 = puVar13[1];
        local_140 = *puVar13;
        puVar13[1] = 0;
        puVar13[2] = 0;
        *puVar13 = 0;
        pvVar19 = (void *)((ulong)&local_140 | 1);
        if ((local_140 & 1) != 0) {
          pvVar19 = local_130;
        }
        __strcpy_chk(&DAT_004fb038,pvVar19,0x80);
        if ((local_140 & 1) != 0) {
          free(local_130);
        }
        if ((local_1b0 & 1) != 0) {
          free(local_1a0);
        }
        if (((uint)local_190 & 1) != 0) {
                    /* WARNING: Read-only address (ram,0x0012b460) is written */
                    /* WARNING: Read-only address (ram,0x0012b530) is written */
                    /* WARNING: Read-only address (ram,0x0012b710) is written */
                    /* WARNING: Read-only address (ram,0x0012bbb0) is written */
                    /* WARNING: Read-only address (ram,0x0012bc10) is written */
                    /* WARNING: Read-only address (ram,0x0012bd00) is written */
          free(local_180);
        }
      }
      if (DAT_004f7d31 != '\0') {
        pcVar14 = &UNK_00126e69;
        if (DAT_004f3d14 != 0) {
          pcVar14 = "Update Dome";
        }
        __strcpy_chk(&DAT_004fb0b8,pcVar14,0x80);
        DAT_004fb038._0_5_ = 0x9ce5a3ade6;
        DAT_004fb038._5_3_ = 0x90e5a8;
        uRam00000000004fb040 = 0xa88ae5af;
      }
                    /* try { // try from 002541a4 to 002541af has its CatchHandler @ 0025459c */
      Gui_UpdateWorker(&DAT_004f8408,&DAT_004fafe8);
    }
    ImGui_EndChild();
    if ((local_170 & 1) != 0) {
      free(local_160);
    }
  }
  FUN_002a1910();
  lVar11 = local_2a0;
LAB_002541c8:
  if (*(long *)(lVar11 + 0x28) == local_b8) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

