/* Entry: 0x00177914; Ghidra function: Gui_DecodeImage */


void Gui_DecodeImage(long param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  long lVar3;
  void *pvVar4;
  undefined uVar5;
  int iVar6;
  undefined *__src;
  int *piVar7;
  void *pvVar8;
  char **ppcVar9;
  size_t __size;
  long in_x8;
  char *pcVar10;
  ulong uVar11;
  int *__ptr;
  ulong uVar12;
  int *piVar13;
  ulong uVar14;
  long lVar15;
  size_t sVar16;
  int *__ptr_00;
  int local_89cc;
  int local_89c8;
  undefined auStack35268 [4];
  undefined auStack35264 [16];
  undefined8 local_89b0;
  undefined4 local_8990;
  undefined4 local_8908;
  long local_8900;
  long lStack35064;
  long local_88f0;
  long lStack35048;
  int local_88e0;
  int local_88dc;
  void *local_88d8;
  void *local_88d0;
  void *local_88c8;
  int iStack120;
  long local_70;
  
  lVar3 = cRead_8(tpidr_el0);
  local_70 = *(long *)(lVar3 + 0x28);
  lStack35064 = param_1 + param_2;
  local_89b0 = 0;
  local_8990 = 0;
  local_8908 = 0;
  local_8900 = param_1;
  local_88f0 = param_1;
  lStack35048 = lStack35064;
  iVar6 = FUN_0027f644(auStack35264);
  if (iVar6 == 0) {
    ppcVar9 = (char **)FUN_003892d8(&DAT_003f24c0);
    pcVar10 = "not GIF";
LAB_00277e84:
    *ppcVar9 = pcVar10;
  }
  else {
    memset(&local_88e0,0,0x8870);
    __src = (undefined *)FUN_0028135c(auStack35264,&local_88e0,auStack35268,0);
    uVar12 = 0;
    __ptr_00 = (int *)0x0;
    if (__src == auStack35264) {
      __ptr = (int *)0x0;
    }
    else {
      __ptr = (int *)0x0;
      if (__src != (undefined *)0x0) {
        __ptr_00 = (int *)0x0;
        lVar15 = 0;
        sVar16 = 4;
        piVar7 = (int *)0x0;
        uVar14 = 0;
        do {
          uVar12 = uVar14 + 1;
          iVar2 = local_88dc * local_88e0;
          local_89cc = local_88e0;
          local_89c8 = local_88dc;
          iVar6 = iVar2 * 4;
          __size = (size_t)(iVar6 * (int)uVar12);
          if (piVar7 == (int *)0x0) {
            __ptr = (int *)malloc(__size);
            if (__ptr == (int *)0x0) {
              free(local_88d8);
              free(local_88c8);
              free(local_88d0);
              if (__ptr_00 == (int *)0x0) goto LAB_00277e6c;
            }
            else {
              piVar7 = (int *)malloc(sVar16);
              if (piVar7 != (int *)0x0) goto LAB_002779e0;
              free(local_88d8);
              free(local_88c8);
              free(local_88d0);
              __ptr_00 = __ptr;
            }
LAB_00277e68:
            free(__ptr_00);
LAB_00277e6c:
            ppcVar9 = (char **)FUN_003892d8(&DAT_003f24c0);
            pcVar10 = "outofmem";
            goto LAB_00277e84;
          }
          __ptr = (int *)realloc(piVar7,__size);
          if (__ptr == (int *)0x0) {
            free(local_88d8);
            free(local_88c8);
            free(local_88d0);
            free(piVar7);
joined_r0x00277dec:
            if (__ptr_00 != (int *)0x0) goto LAB_00277e68;
            goto LAB_00277e6c;
          }
          piVar7 = (int *)realloc(__ptr_00,sVar16);
          if (piVar7 == (int *)0x0) {
            free(local_88d8);
            free(local_88c8);
            free(local_88d0);
            free(__ptr);
            goto joined_r0x00277dec;
          }
LAB_002779e0:
          __ptr_00 = piVar7;
          memcpy((void *)((long)__ptr + (long)(iVar6 * (int)uVar14)),__src,(long)iVar6);
          if (uVar14 != 0) {
            lVar15 = (long)__ptr - (long)(iVar2 * 8);
          }
          __ptr_00[uVar14] = iStack120;
          __src = (undefined *)FUN_0028135c(auStack35264,&local_88e0,auStack35268,lVar15);
          sVar16 = sVar16 + 4;
          piVar7 = __ptr;
          uVar14 = uVar12;
        } while (__src != auStack35264 && __src != (undefined *)0x0);
      }
    }
    free(local_88d8);
    free(local_88c8);
    free(local_88d0);
    if ((__ptr != (int *)0x0) && ((int)uVar12 != 0)) {
      if ((int)uVar12 < 1) {
        free(__ptr);
        if (__ptr_00 != (int *)0x0) goto LAB_00277d60;
      }
      else {
        iVar6 = 0;
        uVar12 = uVar12 & 0xffffffff;
        piVar7 = __ptr_00;
        do {
          glGenTextures(1,&local_88e0);
          glBindTexture(0xde1,local_88e0);
          glTexParameteri(0xde1,0x2801,0x2601);
          glTexParameteri(0xde1,0x2800,0x2601);
          glTexImage2D(0xde1,0,0x1908,local_89cc,local_89c8,0,0x1908,0x1401,
                       (long)__ptr + (long)iVar6);
          pvVar4 = DAT_0050d728;
          if (DAT_0050d730 == DAT_0050d738) {
            uVar11 = (long)DAT_0050d730 - (long)DAT_0050d728;
            uVar14 = ((long)uVar11 >> 2) + 1;
            if (uVar14 >> 0x3e != 0) {
                    /* WARNING: Subroutine does not return */
              FUN_0036e680(&DAT_0050d728);
            }
            if (uVar14 <= (ulong)((long)uVar11 >> 1)) {
              uVar14 = (long)uVar11 >> 1;
            }
            if (0x7ffffffffffffffb < uVar11) {
              uVar14 = 0x3fffffffffffffff;
            }
            if (uVar14 == 0) {
              pvVar8 = (void *)0x0;
            }
            else {
              if (uVar14 >> 0x3e != 0) goto LAB_00277f24;
              pvVar8 = (void *)FUN_0036b114(uVar14 << 2);
            }
            piVar1 = (int *)((long)pvVar8 + ((long)uVar11 >> 2) * 4);
            piVar13 = piVar1 + 1;
            *piVar1 = local_88e0;
            if (0 < (long)uVar11) {
              memcpy(pvVar8,pvVar4,uVar11);
            }
            DAT_0050d738 = (int *)((long)pvVar8 + uVar14 * 4);
            DAT_0050d728 = pvVar8;
            DAT_0050d730 = piVar13;
            if (pvVar4 != (void *)0x0) {
              free(pvVar4);
            }
          }
          else {
            *DAT_0050d730 = local_88e0;
            DAT_0050d730 = DAT_0050d730 + 1;
          }
          pvVar4 = DAT_0050d740;
          iVar2 = *piVar7;
          if (DAT_0050d748 < DAT_0050d750) {
            *DAT_0050d748 = iVar2 * 10;
            DAT_0050d748 = DAT_0050d748 + 1;
          }
          else {
            sVar16 = (long)DAT_0050d748 - (long)DAT_0050d740;
            uVar14 = ((long)sVar16 >> 2) + 1;
            if (uVar14 >> 0x3e != 0) {
                    /* WARNING: Subroutine does not return */
              FUN_0036e680(&DAT_0050d740);
            }
            uVar11 = (long)DAT_0050d750 - (long)DAT_0050d740 >> 1;
            if (uVar14 <= uVar11) {
              uVar14 = uVar11;
            }
            if (0x7ffffffffffffffb < (ulong)((long)DAT_0050d750 - (long)DAT_0050d740)) {
              uVar14 = 0x3fffffffffffffff;
            }
            if (uVar14 == 0) {
              pvVar8 = (void *)0x0;
            }
            else {
              if (uVar14 >> 0x3e != 0) {
LAB_00277f24:
                    /* WARNING: Subroutine does not return */
                FUN_00268d80("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size"
                            );
              }
              pvVar8 = (void *)FUN_0036b114(uVar14 << 2);
            }
            piVar1 = (int *)((long)pvVar8 + ((long)sVar16 >> 2) * 4);
            piVar13 = piVar1 + 1;
            *piVar1 = iVar2 * 10;
            if (0 < (long)sVar16) {
              memcpy(pvVar8,pvVar4,sVar16);
            }
            DAT_0050d750 = (int *)((long)pvVar8 + uVar14 * 4);
            DAT_0050d740 = pvVar8;
            DAT_0050d748 = piVar13;
            if (pvVar4 != (void *)0x0) {
              free(pvVar4);
            }
          }
          piVar7 = piVar7 + 1;
          uVar12 = uVar12 - 1;
          iVar6 = iVar6 + local_89c8 * local_89cc * 4;
        } while (uVar12 != 0);
        free(__ptr);
LAB_00277d60:
        free(__ptr_00);
      }
      FUN_00284c58(in_x8,&DAT_0050d728);
                    /* try { // try from 00277d80 to 00277d8b has its CatchHandler @ 00277f98 */
      FUN_00284d00(in_x8 + 0x18,&DAT_0050d740);
      uVar5 = DAT_0050d760;
      *(undefined8 *)(in_x8 + 0x30) = DAT_0050d758;
      *(undefined *)(in_x8 + 0x38) = uVar5;
                    /* try { // try from 00277da8 to 00277db3 has its CatchHandler @ 00277f94 */
      FUN_00284da8(in_x8 + 0x40,&DAT_0050d768);
                    /* try { // try from 00277db8 to 00277dc3 has its CatchHandler @ 00277f4c */
      FUN_00284e74(in_x8 + 0x58,&DAT_0050d780);
      goto LAB_00277ee4;
    }
  }
  FUN_00284c58(in_x8,&DAT_0050d728);
                    /* try { // try from 00277ea0 to 00277eab has its CatchHandler @ 00278034 */
  FUN_00284d00(in_x8 + 0x18,&DAT_0050d740);
  uVar5 = DAT_0050d760;
  *(undefined8 *)(in_x8 + 0x30) = DAT_0050d758;
  *(undefined *)(in_x8 + 0x38) = uVar5;
                    /* try { // try from 00277ec8 to 00277ed3 has its CatchHandler @ 00277ff4 */
  FUN_00284da8(in_x8 + 0x40,&DAT_0050d768);
                    /* try { // try from 00277ed8 to 00277ee3 has its CatchHandler @ 00277f9c */
  FUN_00284e74(in_x8 + 0x58,&DAT_0050d780);
LAB_00277ee4:
  *(undefined8 *)(in_x8 + 0x70) = DAT_0050d798;
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

