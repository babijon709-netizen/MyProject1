/* Entry: 0x001eb214; Ghidra function: Gui_PointerTable */


void Gui_PointerTable(undefined8 param_1,float param_2,int *param_3,long **param_4,long param_5)

{
  void *pvVar1;
  long lVar2;
  byte bVar3;
  undefined8 uVar4;
  long *plVar5;
  long lVar6;
  long lVar7;
  int iVar8;
  ulong uVar9;
  long *plVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined4 uVar14;
  float fVar15;
  float fVar16;
  uint uVar17;
  float fVar18;
  ulong uVar19;
  float fVar20;
  float fVar21;
  undefined8 local_f0;
  undefined8 uStack232;
  float local_d8;
  float fStack212;
  ulong local_d0;
  undefined8 uStack200;
  void *local_c0;
  long local_b0;
  
  lVar2 = cRead_8(tpidr_el0);
  local_b0 = *(long *)(lVar2 + 0x28);
  uVar4 = ImGui_GetWindowDrawList();
  fVar11 = (float)ImGui_GetCursorScreenPos();
  fVar12 = (float)ImGui_GetWindowPos();
  ImGui_GetScrollY();
  plVar10 = *param_4;
  plVar5 = param_4[1];
  if (plVar10 != plVar5) {
    iVar8 = 0;
    fVar13 = fVar11 + fVar12 + -20.0 + -45.0;
    uVar19 = (ulong)(uint)(fVar12 + -40.0);
    do {
      lVar7 = *plVar10;
      lVar6 = plVar10[1];
      fVar20 = (float)iVar8;
      if (lVar6 - lVar7 != 0x10) {
        fVar21 = 0.0;
        uVar9 = 0;
        do {
          fVar18 = (float)uVar19;
          if (fVar21 == 0.0) {
            Gui_FormatDiagnostic(&local_d0,0x20,"%d: %p",iVar8,*(undefined8 *)(lVar6 + -8));
          }
          else {
            Gui_FormatDiagnostic(&local_d0,0x20," > %p",*(undefined8 *)(lVar7 + uVar9 * 8));
          }
          fVar15 = (float)ImGui_CalcTextSize(0x42040000,0,&local_d0);
          fVar16 = (float)NEON_fmadd(*(float *)(param_5 + 4),fVar20,
                                     param_2 + *(float *)(param_5 + 4) * 0.5);
          local_d8 = fVar11 + 20.0 + fVar21;
          fStack212 = (fVar16 - fVar18 * 0.5) + -1.0;
          uStack232 = 0x3f8000003f75f5f7;
          local_f0 = 0x3e48c8ca;
          uVar14 = ImGui_ColorConvertFloat4ToU32(&local_f0);
          uVar19 = 0;
          ImDrawList_AddText(0x42040000,uVar4,0,&local_d8,uVar14,&local_d0,0,0);
          lVar7 = *plVar10;
          lVar6 = plVar10[1];
          uVar9 = uVar9 + 1;
          fVar21 = fVar21 + fVar15 + 5.0;
        } while (uVar9 < (lVar6 - lVar7 >> 3) - 2U);
      }
      uVar14 = NEON_fmadd(*(undefined4 *)(param_5 + 4),fVar20,param_2);
      local_d0 = CONCAT44(uVar14,fVar11 + 20.0);
      ImGui_SetCursorScreenPos(&local_d0);
      FUN_0036ce38(iVar8);
      pvVar1 = (void *)((ulong)&local_d0 | 1);
      if ((local_d0 & 1) != 0) {
        pvVar1 = local_c0;
      }
      local_f0 = CONCAT44(*(undefined4 *)(param_5 + 4),fVar12 + -40.0);
                    /* try { // try from 002eb36c to 002eb377 has its CatchHandler @ 002eb560 */
      bVar3 = ImGui_Button(pvVar1,&local_f0,0);
      if ((local_d0 & 1) != 0) {
        free(local_c0);
      }
      if ((bVar3 & DAT_0050e634 == '\0') == 1) {
        *param_3 = iVar8;
      }
      uVar14 = NEON_fmadd(*(float *)(param_5 + 4),fVar20,param_2 + *(float *)(param_5 + 4) * 0.5);
      uVar19 = (ulong)(uint)fVar13;
      local_f0 = CONCAT44(uVar14,fVar13);
      uStack200 = 0x3f8000003f66e6e8;
      local_d0 = 0x3f66e6e83f66e6e8;
      uVar14 = ImGui_ColorConvertFloat4ToU32(&local_d0);
      ImDrawList_AddCircle(0x41d80000,uVar4,&local_f0,uVar14,0);
      if (iVar8 == *param_3) {
        uVar17 = NEON_fmadd(*(float *)(param_5 + 4),fVar20,param_2 + *(float *)(param_5 + 4) * 0.5);
        uVar19 = (ulong)uVar17;
        Gui_DrawTexture(fVar13,uVar19,0x41a80000,0x3f866666,0x3f800000,DAT_0050d8a0);
      }
      iVar8 = iVar8 + 1;
      plVar10 = plVar10 + 3;
    } while (plVar10 != plVar5);
  }
  if (*(long *)(lVar2 + 0x28) == local_b0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

