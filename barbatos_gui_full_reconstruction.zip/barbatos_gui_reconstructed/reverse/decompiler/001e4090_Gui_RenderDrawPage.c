/* Entry: 0x001e4090; Ghidra function: Gui_RenderDrawPage */


/* WARNING: Could not reconcile some variable overlaps */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void Gui_RenderDrawPage(void)

{
  undefined *puVar1;
  long lVar2;
  bool bVar3;
  undefined4 uVar4;
  int iVar5;
  long lVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  ulong uVar9;
  undefined4 *puVar10;
  char *pcVar11;
  undefined *puVar12;
  char *pcVar13;
  undefined8 *puVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  undefined auVar18 [16];
  float fVar19;
  uint uVar20;
  undefined4 uVar21;
  float fVar22;
  long lVar24;
  float fVar25;
  undefined8 local_148;
  char *local_140 [4];
  char *local_120;
  char *pcStack280;
  undefined *local_110;
  undefined *local_108;
  undefined *local_100;
  undefined *puStack248;
  undefined8 local_f0;
  undefined8 uStack232;
  undefined8 local_e0;
  undefined *local_d0;
  undefined2 *puStack200;
  undefined *local_c0;
  undefined *puStack184;
  undefined *local_b0;
  undefined *puStack168;
  long local_a0;
  ulong uVar23;
  
  lVar2 = cRead_8(tpidr_el0);
  local_a0 = *(long *)(lVar2 + 0x28);
  if (((DAT_0050eac0 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050eac0), iVar5 != 0)) {
    DAT_0050eab8 = '\0';
    DAT_0050eabc = 0.0;
    DAT_0050eab4 = 0.08;
    FUN_0036eca0(&DAT_0050eac0);
  }
  lVar6 = ImGui_GetIO();
  fVar15 = DAT_0050eabc;
  if (44.0 <= 1000.0 / (*(float *)(lVar6 + 0x10) * 1000.0)) {
    fVar19 = 0.0;
    if (DAT_0050eab8 != '\0') {
      fVar19 = 1.0;
    }
    lVar6 = ImGui_GetIO();
    fVar15 = (float)NEON_fmadd(*(float *)(lVar6 + 0x10) / DAT_0050eab4,fVar19 - DAT_0050eabc,fVar15)
    ;
    fVar19 = (float)NEON_fmin(fVar15,0x3f800000);
    DAT_0050eabc = 0.0;
    if (0.0 <= fVar15) {
      DAT_0050eabc = fVar19;
    }
  }
  DAT_0050eab8 = DAT_004d6f98 != -1;
  if (((DAT_0050ead8 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ead8), iVar5 != 0)) {
    DAT_0050eacc = '\0';
    DAT_0050ead0 = 0.0;
    DAT_0050eac8 = 0.08;
    FUN_0036eca0(&DAT_0050ead8);
  }
  lVar6 = ImGui_GetIO();
  fVar15 = DAT_0050ead0;
  fVar19 = 1000.0 / (*(float *)(lVar6 + 0x10) * 1000.0);
  uVar9 = (ulong)(uint)fVar19;
  uVar23 = 0x42300000;
  if (44.0 <= fVar19) {
    fVar19 = 0.0;
    if (DAT_0050eacc != '\0') {
      fVar19 = 1.0;
    }
    lVar6 = ImGui_GetIO();
    fVar15 = (float)NEON_fmadd(*(float *)(lVar6 + 0x10) / DAT_0050eac8,fVar19 - DAT_0050ead0,fVar15)
    ;
    uVar20 = NEON_fmin(fVar15,0x3f800000);
    uVar23 = (ulong)uVar20;
    uVar9 = 0;
    if (0.0 <= fVar15) {
      uVar9 = uVar23;
    }
    DAT_0050ead0 = (float)uVar9;
  }
  DAT_0050eacc = DAT_004d6f9c != -1;
  if ((DAT_0050e634 == 0) || (DAT_0050e637 == 0)) {
    if ((DAT_0050e634 | DAT_0050e637) == 0) {
      if (DAT_0050eaa4 == 0.0) {
        DAT_0050eaa8 = FUN_0034a23c();
      }
      lVar6 = FUN_0034a23c();
      fVar15 = (float)((lVar6 - DAT_0050eaa8) / 1000) / 1000.0;
      if (fVar15 == 0.0) {
        fVar15 = 1.0;
      }
      uVar23 = 0x44bb8000;
      uVar9 = (ulong)(uint)fVar15;
      if (1500.0 <= fVar15) {
        uVar9 = 0;
      }
      DAT_0050eaa4 = (float)uVar9;
      if (1500.0 <= fVar15) {
        DAT_0050ea98 = '\0';
      }
    }
  }
  else {
    DAT_0050ea98 = '\x01';
    DAT_0050eaa4 = 0.0;
  }
  local_140[0] = (char *)0x0;
  ImGui_BeginChild("##Drawright",local_140,0,0x800008);
  uVar7 = ImGui_GetWindowDrawList();
  ImGui_GetCursorScreenPos();
  fVar22 = (float)uVar23;
  fVar17 = (float)uVar9;
  fVar15 = fVar17;
  fVar19 = fVar22;
  ImGui_GetCursorScreenPos();
  ImGui_GetWindowPos();
  if (((DAT_0050eae0 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050eae0), iVar5 != 0)) {
    FUN_0036eca0(&DAT_0050eae0);
  }
  auVar18 = NEON_fmov(0x3f800000,4);
  local_140[1] = SUB168(auVar18 >> 0x40,0);
  local_140[0] = SUB168(auVar18,0);
  fVar25 = fVar17 + fVar15;
  local_d0 = (undefined *)(uVar9 & 0xffffffff | uVar23 << 0x20);
  local_f0 = CONCAT44(fVar22 + fVar19,fVar25);
  uVar4 = ImGui_ColorConvertFloat4ToU32(local_140[0],local_140);
  ImDrawList_AddRectFilled(uVar7,&local_d0,&local_f0,uVar4,0xa0);
  if (DAT_0050d8d8 != 0) {
    local_d0 = (undefined *)CONCAT44(fVar22 + fVar19,fVar25);
    local_140[0] = (char *)(uVar9 & 0xffffffff | uVar23 << 0x20);
    FUN_002791f4(local_140,&local_d0,0xa0);
    FUN_002514f8(DAT_0050d8d8);
    FUN_00279398();
  }
  fVar19 = 3.0;
  if (3.0 < DAT_0050eab0) {
    local_d0 = (undefined *)(uVar9 & 0xffffffff | uVar23 << 0x20);
    fVar19 = 0.9019608;
    local_140[1] = (char *)0x3f1b9b9c3f66e6e8;
    local_140[0] = (char *)0x3f66e6e83f66e6e8;
    local_f0 = CONCAT44(fVar22 + DAT_00395104,fVar25);
    uVar4 = ImGui_ColorConvertFloat4ToU32(local_140);
    ImDrawList_AddRectFilled(uVar7,&local_d0,&local_f0,uVar4,0x20);
  }
  fVar16 = 55.0;
  ImGui_CalcTextSize(0,(&PTR_DAT_004d6f88)[DAT_004f3d14]);
  local_d0 = (undefined *)
             CONCAT44(fVar22 + 39.0 + fVar19 * -0.5,fVar17 + fVar15 * 0.5 + fVar16 * -0.5);
  local_140[1] = (char *)0x3f8000003df0f0f2;
  local_140[0] = (char *)0x3df0f0f23df0f0f2;
  uVar4 = ImGui_ColorConvertFloat4ToU32(local_140);
  fVar17 = 0.0;
  fVar15 = 0.0;
  ImDrawList_AddText(uVar7,0,&local_d0,uVar4,(&PTR_DAT_004d6f88)[DAT_004f3d14],0,0);
  fVar19 = DAT_00395104;
  ImGui_SetCursorPosY();
  uVar4 = 0x80000c;
  if (DAT_0050ea98 != '\0') {
    uVar4 = 0x840004;
  }
  local_140[0] = (char *)0x0;
  ImGui_BeginChild("##Drawcentre",local_140,0,uVar4);
  ImGui_GetCursorScreenPos();
  fVar16 = fVar19;
  ImGui_GetWindowPos();
  lVar6 = ImGui_GetWindowDrawList();
  if (DAT_004d6f98 == -1) {
    fVar15 = fVar16;
    Gui_OverlayStateBegin(0);
    Gui_OverlayStateEnd(0);
    Gui_OverlayAnimation(0);
  }
  local_140[0] = (char *)CONCAT44(fVar17 + fVar15 + 10.0,fVar19);
  ImGui_SetCursorScreenPos(local_140);
  bVar3 = DAT_004f3d14 != 0;
  local_140[1] = &DAT_00118baf;
  local_140[0] = &DAT_0011b68e;
  if (bVar3) {
    local_140[1] = &DAT_0012a7b8;
    local_140[0] = "Rect Box";
  }
  local_140[2] = &DAT_001220aa;
  if (bVar3) {
    local_140[2] = "Skeleton";
  }
  local_120 = &DAT_00119dd7;
  local_140[3] = &UNK_00120f31;
  if (bVar3) {
    local_120 = "Health";
    local_140[3] = "Name And Distance";
  }
  pcStack280 = &UNK_0011af0c;
  if (bVar3) {
    pcStack280 = "Player Weapon";
  }
  puStack200 = &DAT_004f1a58;
  puStack184 = &DAT_004f1a98;
  puStack168 = &DAT_004f1ad8;
  local_d0 = &DAT_004f1a38;
  local_c0 = &DAT_004f1a78;
  local_b0 = &DAT_004f1ab8;
  local_e0 = 0x500000004;
  uStack232 = SUB168(_DAT_0021db00 >> 0x40,0);
  local_f0 = SUB168(_DAT_0021db00,0);
  if (((DAT_0050eb48 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050eb48), iVar5 != 0)) {
    DAT_0050eaf5 = DAT_004f1a38;
    DAT_0050eb05 = (char)DAT_004f1a58;
    DAT_0050eae8 = 0;
    if (DAT_004f1a38 != '\0') {
      DAT_0050eae8 = 0x3f800000;
    }
    DAT_0050eb15 = DAT_004f1a78;
    DAT_0050eaf4 = 0;
    DAT_0050eaf8 = 0;
    if ((char)DAT_004f1a58 != '\0') {
      DAT_0050eaf8 = 0x3f800000;
    }
    DAT_0050eb25 = DAT_004f1a98;
    DAT_0050eaf0 = 0x3da3d70a;
    DAT_0050eb04 = 0;
    DAT_0050eb08 = 0;
    if (DAT_004f1a78 != '\0') {
      DAT_0050eb08 = 0x3f800000;
    }
    DAT_0050eb35 = DAT_004f1ab8;
    DAT_0050eb00 = 0x3da3d70a;
    DAT_0050eb14 = 0;
    DAT_0050eb18 = 0;
    if (DAT_004f1a98 != '\0') {
      DAT_0050eb18 = 0x3f800000;
    }
    DAT_0050eb45 = DAT_004f1ad8;
    DAT_0050eb10 = 0x3da3d70a;
    DAT_0050eb24 = 0;
    DAT_0050eb28 = 0;
    if (DAT_004f1ab8 != '\0') {
      DAT_0050eb28 = 0x3f800000;
    }
    DAT_0050eb20 = 0x3da3d70a;
    DAT_0050eb38 = 0;
    if (DAT_004f1ad8 != '\0') {
      DAT_0050eb38 = 0x3f800000;
    }
    DAT_0050eb34 = 0;
    DAT_0050eb30 = 0x3da3d70a;
    DAT_0050eb44 = 0;
    DAT_0050eb40 = 0x3da3d70a;
    DAT_0050eaec = DAT_0050eae8;
    DAT_0050eafc = DAT_0050eaf8;
    DAT_0050eb0c = DAT_0050eb08;
    DAT_0050eb1c = DAT_0050eb18;
    DAT_0050eb2c = DAT_0050eb28;
    DAT_0050eb3c = DAT_0050eb38;
    FUN_0036eca0(&DAT_0050eb48);
  }
  pcVar11 = &UNK_00119dde;
  if (DAT_004f3d14 != 0) {
    pcVar11 = "Player Class Draw [Long Down Adjust]";
  }
  Gui_ToggleRows(pcVar11,&DAT_004d6f98,local_140,&local_d0,&local_f0,6,&DAT_0050eae8,DAT_0050d7c8);
  local_140[1] = SUB168(_PTR_DAT_0038c468 >> 0x40,0);
  local_140[0] = SUB168(_PTR_DAT_0038c468,0);
  local_140[3] = PTR_DAT_0038c480;
  local_140[2] = PTR_DAT_0038c478;
  puStack200 = (undefined2 *)PTR_DAT_0038c490;
  local_d0 = PTR_DAT_0038c488;
  puStack184 = PTR_DAT_0038c4a0;
  local_c0 = PTR_DAT_0038c498;
  uStack232 = SUB168(_DAT_0012bb50 >> 0x40,0);
  local_f0 = SUB168(_DAT_0012bb50,0);
  if (((DAT_0050eb90 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050eb90), iVar5 != 0)) {
    DAT_0050eb5d = DAT_004f1af8;
    DAT_0050eb6d = (char)DAT_004f1b18;
    DAT_0050eb50 = 0;
    if (DAT_004f1af8 != '\0') {
      DAT_0050eb50 = 0x3f800000;
    }
    DAT_0050eb7d = DAT_004f1b38;
    DAT_0050eb5c = 0;
    DAT_0050eb60 = 0;
    if ((char)DAT_004f1b18 != '\0') {
      DAT_0050eb60 = 0x3f800000;
    }
    DAT_0050eb8d = DAT_004f1b58;
    DAT_0050eb58 = 0x3da3d70a;
    DAT_0050eb6c = 0;
    DAT_0050eb70 = 0;
    if (DAT_004f1b38 != '\0') {
      DAT_0050eb70 = 0x3f800000;
    }
    DAT_0050eb68 = 0x3da3d70a;
    DAT_0050eb80 = 0;
    if (DAT_004f1b58 != '\0') {
      DAT_0050eb80 = 0x3f800000;
    }
    DAT_0050eb7c = 0;
    DAT_0050eb78 = 0x3da3d70a;
    DAT_0050eb8c = 0;
    DAT_0050eb88 = 0x3da3d70a;
    DAT_0050eb54 = DAT_0050eb50;
    DAT_0050eb64 = DAT_0050eb60;
    DAT_0050eb74 = DAT_0050eb70;
    DAT_0050eb84 = DAT_0050eb80;
    FUN_0036eca0(&DAT_0050eb90);
  }
  pcVar11 = &UNK_0012a7bd;
  if (DAT_004f3d14 != 0) {
    pcVar11 = "Not Player Class Draw [Long Down Adjust]";
  }
  Gui_ToggleRows(pcVar11,&DAT_004d6f98,local_140,&local_d0,&local_f0,4,&DAT_0050eb50,DAT_0050d7d0);
  local_140[3] = &UNK_00122866;
  if (DAT_004f3d14 != 0) {
    local_140[3] = "Not Draw Ai";
  }
  local_140[0] = &DAT_0012a7f1;
  local_140[1] = &DAT_0011d959;
  local_120 = &UNK_00120f41;
  if (DAT_004f3d14 != 0) {
    local_120 = "Off Color Dynamic";
  }
  local_d0 = &DAT_004f1b78;
  local_140[2] = &DAT_0011b6a2;
  puStack200 = (undefined2 *)&DAT_004f1b98;
  local_c0 = &DAT_004f1bb8;
  puStack184 = &DAT_004f1bd8;
  local_b0 = &DAT_004f1bf8;
  local_e0 = CONCAT44(local_e0._4_4_,0xe);
  uStack232 = SUB168(_DAT_0021db18 >> 0x40,0);
  local_f0 = SUB168(_DAT_0021db18,0);
  if (((DAT_0050ebe8 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ebe8), iVar5 != 0)) {
    DAT_0050eba5 = DAT_004f1b78;
    DAT_0050ebb5 = DAT_004f1b98;
    DAT_0050eb98 = 0;
    if (DAT_004f1b78 != '\0') {
      DAT_0050eb98 = 0x3f800000;
    }
    DAT_0050ebc5 = DAT_004f1bb8;
    DAT_0050eba4 = 0;
    DAT_0050eba8 = 0;
    if (DAT_004f1b98 != '\0') {
      DAT_0050eba8 = 0x3f800000;
    }
    DAT_0050ebd5 = DAT_004f1bd8;
    DAT_0050eba0 = 0x3da3d70a;
    DAT_0050ebb4 = 0;
    DAT_0050ebb8 = 0;
    if (DAT_004f1bb8 != '\0') {
      DAT_0050ebb8 = 0x3f800000;
    }
    DAT_0050ebe5 = DAT_004f1bf8;
    DAT_0050ebb0 = 0x3da3d70a;
    DAT_0050ebc4 = 0;
    DAT_0050ebc8 = 0;
    if (DAT_004f1bd8 != '\0') {
      DAT_0050ebc8 = 0x3f800000;
    }
    DAT_0050ebc0 = 0x3da3d70a;
    DAT_0050ebd8 = 0;
    if (DAT_004f1bf8 != '\0') {
      DAT_0050ebd8 = 0x3f800000;
    }
    DAT_0050ebd4 = 0;
    DAT_0050ebd0 = 0x3da3d70a;
    DAT_0050ebe4 = 0;
    DAT_0050ebe0 = 0x3da3d70a;
    DAT_0050eb9c = DAT_0050eb98;
    DAT_0050ebac = DAT_0050eba8;
    DAT_0050ebbc = DAT_0050ebb8;
    DAT_0050ebcc = DAT_0050ebc8;
    DAT_0050ebdc = DAT_0050ebd8;
    FUN_0036eca0(&DAT_0050ebe8);
  }
  pcVar11 = &UNK_001207c0;
  if (DAT_004f3d14 != 0) {
    pcVar11 = "Else Class Draw [Long Down Adjust]";
  }
  fVar19 = 83.0;
  fVar17 = 63.0;
  Gui_ToggleRows(pcVar11,&DAT_004d6f98,local_140,&local_d0,&local_f0,5,&DAT_0050eb98,DAT_0050d7d8);
  ImGui_GetCursorScreenPos();
  local_140[0] = (char *)CONCAT44(fVar17 - fVar15,fVar19);
  ImGui_SetCursorScreenPos(local_140);
  ImGui_GetScrollY();
  DAT_0050eab0 = fVar19;
  ImGui_EndChild();
  if ((lVar6 != 0) && (3.0 < DAT_0050eab0)) {
    fVar15 = fVar22 + DAT_00395104 + 1.5;
    local_d0 = (undefined *)(uVar9 & 0xffffffff | (ulong)(uint)fVar15 << 0x20);
    local_f0 = CONCAT44(fVar15,fVar25);
    local_140[1] = (char *)0x3f8000003f20a0a1;
    local_140[0] = (char *)0x3f20a0a13f20a0a1;
    uVar4 = ImGui_ColorConvertFloat4ToU32(local_140);
    ImDrawList_AddLine(lVar6,&local_d0,&local_f0,uVar4);
  }
  ImGui_EndChild();
  uVar7 = NEON_fmov(0x3f800000,4);
  if ((DAT_0050eab8 == '\0') || (DAT_0039516c != '\0')) {
    if (DAT_0039516c != '\0') goto LAB_002e4900;
  }
  else {
    DAT_00395170 = Gui_RenderImageLayer
                             ("Hello ImGui",&DAT_004f8160,&DAT_004f8168,(int)DAT_00395174,4);
    _DAT_0039516c = 0x101;
LAB_002e4900:
    local_140[0] = (char *)0x0;
    ImGui_SetCursorPos(local_140);
    local_140[0] = (char *)0x0;
    ImGui_BeginChild("##BottomBlur",local_140,0,0x800008);
    uVar8 = ImGui_GetWindowDrawList();
    local_140[0] = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                                    (float)DAT_004f8160 + (float)DAT_004f8168);
    local_d0 = (undefined1 *)0x0;
    local_f0 = uVar7;
    ImDrawList_AddRectFilledMultiColor
              (uVar8,DAT_00395170,&DAT_004f8160,local_140,&local_d0,&local_f0,
               (int)(DAT_0050eabc * 255.0) * 0x1000000 + 0x1ffffff,0);
    local_d0 = (undefined *)
               CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + DAT_004f8168._4_4_,
                        (float)DAT_004f8160 + (float)DAT_004f8168);
    local_140[0] = (char *)0x3f1696973f169697;
    local_140[1] = (char *)CONCAT44((float)(int)(DAT_0050eabc * 100.0) * 0.003921569,0x3f169697);
    uVar4 = ImGui_ColorConvertFloat4ToU32(local_140);
    ImDrawList_AddRectFilled(uVar8,&DAT_004f8160,&local_d0,uVar4,0);
    ImGui_EndChild();
    if (((DAT_0050eab8 == '\0') && (DAT_0050eabc <= 0.02)) && (_DAT_0039516c = 0, DAT_00395170 != 0)
       ) {
      glDeleteBuffers(1,&DAT_00395170);
      DAT_00395170 = 0;
    }
  }
  if (DAT_0050eabc <= 0.02) goto LAB_002e57c4;
  uVar21 = NEON_fmadd(DAT_0050ead0,0x41a00000,0x428c0000);
  uVar4 = NEON_fmsub(DAT_0050eabc,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
  uVar4 = NEON_fmsub(DAT_0050ead0,0x41a00000,uVar4);
  local_140[0] = (char *)CONCAT44(uVar4,uVar21);
  ImGui_SetCursorPos(local_140);
  fVar15 = (float)NEON_fmadd(DAT_0050ead0,0xc1f00000,0x437f0000);
  fVar15 = fVar15 / 255.0;
  local_140[0] = (char *)CONCAT44(fVar15,fVar15);
  local_140[1] = (char *)CONCAT44(0x3f400000,fVar15);
  ImGui_PushStyleColor(3,local_140);
  fVar17 = DAT_004f8168._4_4_ + -140.0;
  fVar22 = (float)NEON_fmadd(DAT_0050ead0,0xc2200000,(float)DAT_004f8168 + -140.0);
  local_140[0] = (char *)CONCAT44(fVar17,fVar22);
  ImGui_BeginChild("##NewDrawPage1",local_140,0,0x80000c);
  ImGui_GetCursorScreenPos();
  fVar15 = fVar22;
  fVar19 = fVar17;
  ImGui_GetWindowPos();
  ImGui_GetWindowSize();
  ImGui_GetWindowDrawList();
  ImGui_PopStyleColor(1);
  if (DAT_004d6f98 != -1) {
    DAT_0050ebf4 = DAT_004d6f98;
  }
  time((time_t *)0x0);
  FUN_0036cf74();
  puVar1 = (undefined *)((ulong)local_140 | 1);
  if (((ulong)local_140[0] & 1) != 0) {
    puVar1 = local_140[2];
  }
                    /* try { // try from 002e4b74 to 002e4b77 has its CatchHandler @ 002e5d88 */
  uVar9 = Gui_CloseButton(puVar1);
  if (((ulong)local_140[0] & 1) != 0) {
    free(local_140[2]);
  }
  if ((uVar9 & 1) != 0) {
    DAT_004d6f98 = -1;
  }
  uVar4 = 0x42c80000;
  ImGui_SetCursorPosY();
  if (DAT_0050ebf4 == 4) goto LAB_002e508c;
  Gui_OverlayStateBegin(DAT_0050ebf0);
  uVar9 = (ulong)DAT_0050ebf4;
  switch(DAT_0050ebf4) {
  case 2:
    bVar3 = DAT_004f3d14 != 0;
    local_140[1] = (char *)&DAT_004f1a7c;
    local_140[0] = &UNK_00118bc8;
    if (bVar3) {
      local_140[0] = "Size";
    }
    local_120 = &UNK_0011c792;
    if (bVar3) {
      local_120 = "Skeleton Draw Distance Max";
    }
    local_140[2] = (undefined *)0x412000003f800000;
    pcStack280 = (char *)0x4f1a80;
    local_140[3] = "%.1f";
    local_110 = (undefined *)0x439600003f800000;
    pcVar11 = &UNK_00118bb6;
    if (bVar3) {
      pcVar11 = "Adjust";
    }
    local_108 = &DAT_0011b5ee;
    Gui_ValueEditorList(&DAT_0050ebf0,pcVar11,2,DAT_0050d898,local_140);
    if (((DAT_0050ed20 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ed20), iVar5 != 0)) {
      DAT_0050ec98 = 0;
      DAT_0050ec9c = 0;
      DAT_0050eca8 = 0;
      DAT_0050ecac = 0;
      DAT_0050ecb8 = 0;
      DAT_0050ec90 = 0x3db851ec00000000;
      DAT_0050eca0 = 0x3db851ec00000000;
      DAT_0050ecbc = 0;
      DAT_0050ecb0 = 0x3db851ec00000000;
      DAT_0050ecc8 = 0;
      DAT_0050eccc = 0;
      DAT_0050ecc0 = 0x3db851ec00000000;
      DAT_0050ecd8 = 0;
      DAT_0050ecdc = 0;
      DAT_0050ecd0 = 0x3db851ec00000000;
      DAT_0050ece8 = 0;
      DAT_0050ecec = 0;
      DAT_0050ece0 = 0x3db851ec00000000;
      DAT_0050ecf8 = 0;
      DAT_0050ecfc = 0;
      DAT_0050ecf0 = 0x3db851ec00000000;
      DAT_0050ed08 = 0;
      DAT_0050ed0c = 0;
      DAT_0050ed00 = 0x3db851ec00000000;
      DAT_0050ed18 = 0;
      DAT_0050ed1c = 0;
      DAT_0050ed10 = 0x3db851ec00000000;
      FUN_0036eca0(&DAT_0050ed20);
    }
    pcVar11 = &UNK_0011e11d;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Draw Color";
    }
    puVar10 = (undefined4 *)&DAT_004f1a88;
    puVar14 = &DAT_0050ec90;
    break;
  default:
    puVar1 = &UNK_0011d966;
    if (DAT_004f3d14 != 0) {
      puVar1 = &DAT_0011bf97;
    }
    if (DAT_0050ebf4 < 2) {
      pcVar11 = &UNK_00118bb6;
      if (DAT_004f3d14 != 0) {
        pcVar11 = "Adjust";
      }
      puVar12 = &DAT_00123207;
    }
    else {
      uVar9 = uVar9 & 0xffffffff;
      pcVar11 = &UNK_00118bb6;
      if (DAT_004f3d14 != 0) {
        pcVar11 = "Adjust";
      }
      puVar12 = &DAT_0011b5ee;
    }
    Gui_ValueEditor(&DAT_0050ebf0,puVar1,&DAT_004f1a3c + uVar9 * 8,puVar12,pcVar11,DAT_0050d898);
    if (((DAT_0050ec88 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ec88), iVar5 != 0)) {
      DAT_0050ec00 = 0;
      DAT_0050ec04 = 0;
      DAT_0050ec10 = 0;
      DAT_0050ec14 = 0;
      DAT_0050ec20 = 0;
      DAT_0050ebf8 = 0x3db851ec00000000;
      DAT_0050ec08 = 0x3db851ec00000000;
      DAT_0050ec24 = 0;
      DAT_0050ec18 = 0x3db851ec00000000;
      DAT_0050ec30 = 0;
      DAT_0050ec34 = 0;
      DAT_0050ec28 = 0x3db851ec00000000;
      DAT_0050ec40 = 0;
      DAT_0050ec44 = 0;
      DAT_0050ec38 = 0x3db851ec00000000;
      DAT_0050ec50 = 0;
      DAT_0050ec54 = 0;
      DAT_0050ec48 = 0x3db851ec00000000;
      DAT_0050ec60 = 0;
      DAT_0050ec64 = 0;
      DAT_0050ec58 = 0x3db851ec00000000;
      DAT_0050ec70 = 0;
      DAT_0050ec74 = 0;
      DAT_0050ec68 = 0x3db851ec00000000;
      DAT_0050ec80 = 0;
      DAT_0050ec84 = 0;
      DAT_0050ec78 = 0x3db851ec00000000;
      FUN_0036eca0(&DAT_0050ec88);
    }
    puVar10 = (undefined4 *)(&DAT_004f1a48 + (long)DAT_0050ebf4 * 0x20);
    pcVar11 = &UNK_0011e11d;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Draw Color";
    }
    puVar14 = &DAT_0050ebf8;
    break;
  case 7:
    if (((DAT_0050ed50 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ed50), iVar5 != 0)) {
      DAT_0050ed4d = (char)DAT_004f1b18;
      DAT_0050ed40 = 0;
      if ((char)DAT_004f1b18 != '\0') {
        DAT_0050ed40 = 0x3f800000;
      }
      DAT_0050ed4c = 0;
      DAT_0050ed48 = 0x3da3d70a;
      DAT_0050ed44 = DAT_0050ed40;
      FUN_0036eca0(&DAT_0050ed50);
    }
    pcVar11 = &UNK_0012a7f8;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Draw Vehicle State";
    }
    pcVar13 = &UNK_0011bf9c;
    if (DAT_004f3d14 != 0) {
      pcVar13 = "Draw Vehicle State [bug]";
    }
    Gui_TwoStateRow(pcVar11,pcVar13,&DAT_004f1a39 + (long)DAT_0050ebf4 * 0x20,&DAT_0050ed40,
                    DAT_0050d7d0);
    puVar1 = &UNK_0011d966;
    if (DAT_004f3d14 != 0) {
      puVar1 = &DAT_0011bf97;
    }
    pcVar11 = &UNK_00118bb6;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Adjust";
    }
    Gui_ValueEditor(&DAT_0050ebf0,puVar1,&DAT_004f1b1c,&DAT_0011b5ee,pcVar11,DAT_0050d898);
    if (((DAT_0050ede8 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ede8), iVar5 != 0)) {
      DAT_0050ed60 = 0;
      DAT_0050ed64 = 0;
      DAT_0050ed70 = 0;
      DAT_0050ed74 = 0;
      DAT_0050ed80 = 0;
      DAT_0050ed58 = 0x3db851ec00000000;
      DAT_0050ed68 = 0x3db851ec00000000;
      DAT_0050ed84 = 0;
      DAT_0050ed78 = 0x3db851ec00000000;
      DAT_0050ed90 = 0;
      DAT_0050ed94 = 0;
      DAT_0050ed88 = 0x3db851ec00000000;
      DAT_0050eda0 = 0;
      DAT_0050eda4 = 0;
      DAT_0050ed98 = 0x3db851ec00000000;
      DAT_0050edb0 = 0;
      DAT_0050edb4 = 0;
      DAT_0050eda8 = 0x3db851ec00000000;
      DAT_0050edc0 = 0;
      DAT_0050edc4 = 0;
      DAT_0050edb8 = 0x3db851ec00000000;
      DAT_0050edd0 = 0;
      DAT_0050edd4 = 0;
      DAT_0050edc8 = 0x3db851ec00000000;
      DAT_0050ede0 = 0;
      DAT_0050ede4 = 0;
      DAT_0050edd8 = 0x3db851ec00000000;
      FUN_0036eca0(&DAT_0050ede8);
    }
    pcVar11 = &UNK_0011e11d;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Draw Color";
    }
    puVar10 = &DAT_004f1b28;
    puVar14 = &DAT_0050ed58;
    break;
  case 10:
    if (((DAT_0050ed38 & 1) == 0) && (iVar5 = FUN_0036eb48(&DAT_0050ed38), iVar5 != 0)) {
      DAT_0050ed34 = 0;
      DAT_0050ed30 = 0x3da3d70a;
      DAT_0050ed28 = 0;
      FUN_0036eca0(&DAT_0050ed38);
    }
    pcVar11 = &UNK_00118bcf;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Radar Pos";
    }
    pcVar13 = &UNK_00128f40;
    if (DAT_004f3d14 != 0) {
      pcVar13 = "Pos | Size";
    }
    uVar4 = 0x42a60000;
    fVar15 = 63.0;
    Gui_TwoStateRow(pcVar11,pcVar13,&DAT_004fb920,&DAT_0050ed28,DAT_0050d8a8);
    goto LAB_002e5080;
  case 0xb:
    pcVar11 = &UNK_0011d066;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Player Aim You Tips Size";
    }
    pcVar13 = &UNK_00118bb6;
    if (DAT_004f3d14 != 0) {
      pcVar13 = "Adjust";
    }
    puVar10 = &DAT_004f1b9c;
    fVar15 = 100.0;
    uVar4 = 0x41f00000;
    goto LAB_002e4fb8;
  case 0xc:
    pcVar11 = &UNK_00127029;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Angle";
    }
    pcVar13 = &UNK_00118bb6;
    if (DAT_004f3d14 != 0) {
      pcVar13 = "Adjust";
    }
    puVar10 = &DAT_004f1bbc;
    fVar15 = 500.0;
    uVar4 = 0x42c80000;
LAB_002e4fb8:
    Gui_ValueEditor(&DAT_0050ebf0,pcVar11,puVar10,&DAT_0011b5ee,pcVar13,DAT_0050d898);
    goto LAB_002e5080;
  case 0xd:
    goto switchD_002e4be4_caseD_d;
  }
  uVar4 = 0x42a60000;
  fVar15 = 63.0;
  Gui_ColorPicker(puVar10,pcVar11,1,&DAT_004d6f9c,1,puVar14,DAT_0050d878);
LAB_002e5080:
  if (DAT_0050ebf4 == 4) {
LAB_002e508c:
    local_140[0] = (char *)0x0;
    ImGui_BeginChild("##Drawcentre99",local_140,0,0x800004);
    lVar6 = ImGui_GetWindowDrawList();
    Gui_OverlayStateBegin(DAT_0050ebf0);
    Gui_OverlayStateEnd(0);
    ImGui_GetCursorScreenPos();
    local_140[0] = (char *)CONCAT44(fVar15 + 10.0,uVar4);
    ImGui_SetCursorScreenPos(local_140);
    pcVar11 = &UNK_00123c50;
    if (DAT_004f3d14 != 0) {
      pcVar11 = "Health Transparency";
    }
    pcVar13 = &UNK_00118bb6;
    if (DAT_004f3d14 != 0) {
      pcVar13 = "Adjust";
    }
    Gui_ValueEditor(&DAT_0050ebf0,pcVar11,0x4f1ac0,&DAT_0011b5ee,pcVar13,DAT_0050d898);
    DAT_004fb7e8 = 0x3f109091;
    DAT_004fb838 = 0x3f41c1c2;
    DAT_004fb7e0 = 0x3f6eeeef3f109091;
    DAT_0039518c = (float)(int)DAT_004f1abc._4_4_ / 255.0;
    DAT_004fb7f0 = 0x3f4ececf3f078788;
    DAT_004fb830 = 0x3f36b6b73f800000;
    DAT_004fb828 = 0x3efefeff;
    DAT_004fb850 = 0x3f78f8f93f78f8f9;
    DAT_004fb848 = 0x3f56d6d7;
    DAT_004fb810 = 0x3f80000000000000;
    DAT_004fb820 = 0x3f80000000000000;
    DAT_004fb860 = 0x3f80000000000000;
    DAT_004fb800 = 0x3f800000;
    DAT_004fb840 = 0x3ee0e0e13f5adadb;
    DAT_004fb7f8 = 0x3f800000;
    DAT_004fb870 = 0x3f25a5a63f800000;
    DAT_004fb858 = 0x3f800000;
    DAT_004fb868 = 0x3f800000;
    DAT_004fb888 = 0x3f800000;
    DAT_004fb918 = 0x3f800000;
    DAT_004fb808 = 0;
    DAT_004fb890 = 0x3f8000003f4ccccd;
    DAT_004fb898 = 0x3f19999a;
    DAT_004fb8a8 = 0x3f19999a;
    DAT_004fb8b0 = 0x3f19999a3f800000;
    DAT_004fb8b8 = 0x3f19999a;
    DAT_004fb8e8 = 0x3f19999a;
    DAT_004fb8c0 = 0x3f19999a3f19999a;
    DAT_004fb8d0 = 0x3f4ccccd3f4ccccd;
    DAT_004fb818 = 0;
    DAT_004fb8e0 = 0x3f4ccccd3ecccccd;
    DAT_004fb8f0 = 0x3ecccccd3f800000;
    DAT_004fb900 = 0x3f4ccccd3ecccccd;
    DAT_004fb878 = 0;
    DAT_004fb880 = 0x3f4ccccd3f19999a;
    DAT_004fb8c8 = 0x3f4ccccd;
    DAT_004fb8d8 = 0x3f4ccccd;
    DAT_004fb908 = 0x3f4ccccd;
    DAT_004fb8f8 = 0;
    DAT_004fb910 = 0x3f4ccccd3f19999a;
    pcStack280 = PTR_s_Circular_Health_0038c4d0;
    local_120 = PTR_DAT_0038c4c8;
    local_108 = PTR_s_Rect_Health_Two_0038c4e0;
    local_110 = PTR_s_Rect_Health_One_0038c4d8;
    puStack248 = PTR_s_Wide_Blood_Volume_0038c4f0;
    local_100 = PTR_DAT_0038c4e8;
    pcVar11 = &UNK_00118be6;
    if ((long)DAT_004f3d14 != 0) {
      pcVar11 = "Health Type";
    }
    local_140[1] = PTR_DAT_0038c4b0;
    local_140[0] = PTR_DAT_0038c4a8;
    local_140[3] = SUB168(_PTR_DAT_0038c4b8 >> 0x40,0);
    local_140[2] = SUB168(_PTR_DAT_0038c4b8,0);
    DAT_004fb7ec = DAT_0039518c;
    DAT_004fb7fc = DAT_0039518c;
    DAT_004fb80c = DAT_0039518c;
    DAT_004fb81c = DAT_0039518c;
    DAT_004fb82c = DAT_0039518c;
    DAT_004fb83c = DAT_0039518c;
    DAT_004fb84c = DAT_0039518c;
    DAT_004fb85c = DAT_0039518c;
    DAT_004fb86c = DAT_0039518c;
    DAT_004fb87c = DAT_0039518c;
    DAT_004fb88c = DAT_0039518c;
    DAT_004fb89c = DAT_0039518c;
    DAT_004fb8a0 = uVar7;
    DAT_004fb8ac = DAT_0039518c;
    DAT_004fb8bc = DAT_0039518c;
    DAT_004fb8cc = DAT_0039518c;
    DAT_004fb8dc = DAT_0039518c;
    DAT_004fb8ec = DAT_0039518c;
    DAT_004fb8fc = DAT_0039518c;
    DAT_004fb90c = DAT_0039518c;
    DAT_004fb91c = DAT_0039518c;
    Gui_ChoiceCombo(&DAT_004f1abc,pcVar11,local_140 + (long)DAT_004f3d14 * 5,5,DAT_0050d7e0);
    pcVar11 = &UNK_00122880;
    if ((long)DAT_004f3d14 != 0) {
      pcVar11 = "Health Color";
    }
    local_140[1] = SUB168(_PTR_DAT_0038c4f8 >> 0x40,0);
    local_140[0] = SUB168(_PTR_DAT_0038c4f8,0);
    local_140[3] = PTR_s_Follow_blood_volume_0038c510;
    local_140[2] = PTR_s_Same_team_Same_color_0038c508;
    Gui_ChoiceCombo(&DAT_004f1ac4,pcVar11,local_140 + (long)DAT_004f3d14 * 2,2,DAT_0050d7e8);
    local_140[2] = &DAT_004f1a79;
    local_140[3] = &DAT_004f1a99;
    local_140[0] = &DAT_004f1a39;
    local_140[1] = (char *)0x4f1a59;
    fVar15 = 83.0;
    local_120 = &DAT_004f1ab9;
    pcStack280 = &DAT_004f1ad9;
    local_d0 = &DAT_0011b68e;
    puStack200 = (undefined2 *)&DAT_00118baf;
    local_c0 = &DAT_001220aa;
    puStack184 = &DAT_0012572e;
    local_b0 = &DAT_00119dd7;
    puStack168 = &DAT_001295a1;
    Gui_TaskToggleRows(&DAT_0021db2c + *(int *)(&DAT_0021db2c + (long)DAT_004f3d14 * 4),&local_d0,
                       local_140,6,DAT_0050d7f0);
    ImGui_GetScrollY();
    ImGui_EndChild();
    if ((lVar6 != 0) && (3.0 < fVar15)) {
      fVar15 = fVar22 + 100.0 + 1.5;
      local_d0 = (undefined *)CONCAT44(fVar15,fVar17);
      local_f0 = CONCAT44(fVar15,fVar17 + fVar19 + 20.0);
      local_140[1] = (char *)0x3f8000003f20a0a1;
      local_140[0] = (char *)0x3f20a0a13f20a0a1;
      uVar4 = ImGui_ColorConvertFloat4ToU32(local_140);
      ImDrawList_AddLine(lVar6,&local_d0,&local_f0,uVar4);
    }
  }
switchD_002e4be4_caseD_d:
  ImGui_EndChild();
  if ((DAT_0050eacc == '\0') || (DAT_0039517c != '\0')) {
    if (DAT_0039517c != '\0') goto LAB_002e5554;
  }
  else {
    local_140[0] = (char *)CONCAT44((float)((ulong)DAT_004f8160 >> 0x20) + 70.0,
                                    (float)DAT_004f8160 + 70.0);
    local_d0 = (undefined *)CONCAT44(DAT_004f8168._4_4_ + -140.0,(float)DAT_004f8168 + -140.0);
    DAT_00395180 = Gui_RenderImageLayer("Hello ImGui",local_140,&local_d0,(int)DAT_00395174,4);
    _DAT_0039517c = 0x101;
LAB_002e5554:
    if (((DAT_0050eacc == '\0') && (DAT_0050ead0 <= 0.02)) && (_DAT_0039517c = 0, DAT_00395180 != 0)
       ) {
      glDeleteBuffers(1,&DAT_00395180);
      DAT_00395180 = 0;
    }
  }
  if (0.01 < DAT_0050ead0) {
    uVar4 = NEON_fmsub(DAT_0050ead0,DAT_004f8168._4_4_,DAT_004f8168._4_4_ + 70.0);
    local_140[0] = (char *)CONCAT44(uVar4,0x428c0000);
    ImGui_SetCursorPos(local_140);
    lVar6 = CONCAT44(DAT_004f8168._4_4_,(float)DAT_004f8168);
    pcVar13 = (char *)CONCAT44(DAT_004f8168._4_4_ + -140.0,(float)DAT_004f8168 + -140.0);
    local_140[0] = pcVar13;
    ImGui_BeginChild("##DrawWinThree",local_140,0,0x80000c);
    ImGui_GetWindowPos();
    lVar24 = lVar6;
    pcVar11 = pcVar13;
    ImGui_GetWindowSize();
    local_d0 = (undefined *)((ulong)pcVar11 & 0xffffffff | lVar24 << 0x20);
    uVar8 = ImGui_GetWindowDrawList();
    local_f0 = 0;
    local_140[0] = (char *)CONCAT44((float)lVar6 + (float)lVar24,SUB84(pcVar13,0) + SUB84(pcVar11,0)
                                   );
    local_148 = uVar7;
    ImDrawList_AddRectFilledMultiColor
              (uVar8,DAT_00395180,&local_d0,local_140,&local_f0,&local_148,0xffffffff,0);
    local_f0 = CONCAT44((float)lVar6 + (float)((ulong)local_d0 >> 0x20),
                        SUB84(pcVar13,0) + SUB84(local_d0,0));
    local_140[1] = (char *)0x3ec8c8ca3f800000;
    local_140[0] = (char *)0x3f8000003f800000;
    uVar4 = ImGui_ColorConvertFloat4ToU32(local_140);
    ImDrawList_AddRectFilled(uVar8,&local_d0,&local_f0,uVar4,0);
    Gui_UpdateDragScroll();
    lVar6 = DAT_0050e6f0;
    *(undefined *)(*(long *)(DAT_0050e6f0 + 0x3eb0) + 0x90) = 1;
    puVar14 = DAT_0050edf0;
    lVar6 = *(long *)(lVar6 + 0x3eb0);
    if ((lVar6 != 0) && (*(char *)((long)DAT_0050edf0 + 0x14) == '\0')) {
      *(float *)(lVar6 + 0x60) = *(float *)((long)DAT_0050edf0 + 4) + *(float *)(lVar6 + 0x60);
      fVar15 = *(float *)(lVar6 + 0x68);
      *(float *)((long)puVar14 + 4) = *(float *)(puVar14 + 1) * *(float *)((long)puVar14 + 4);
      if ((fVar15 <= *(float *)(lVar6 + 0x60)) || (*(float *)(lVar6 + 0x60) <= 0.0)) {
        *DAT_0050edf0 = 0;
      }
      if (ABS(*(float *)((long)DAT_0050edf0 + 4)) < 0.1) {
        *DAT_0050edf0 = 0;
      }
    }
    time((time_t *)0x0);
    FUN_0036cf74();
    puVar1 = (undefined *)((ulong)local_140 | 1);
    if (((ulong)local_140[0] & 1) != 0) {
      puVar1 = local_140[2];
    }
                    /* try { // try from 002e5764 to 002e5767 has its CatchHandler @ 002e5d84 */
    uVar9 = Gui_CloseButton(puVar1);
    if (((ulong)local_140[0] & 1) != 0) {
      free(local_140[2]);
    }
    if ((uVar9 & 1) != 0) {
      DAT_004d6f9c = -1;
    }
    Gui_PresetColorPalette(&DAT_00128f72,&DAT_004f1a48 + (long)DAT_004d6f98 * 0x20,DAT_0050d890);
  }
  ImGui_EndChild();
LAB_002e57c4:
  if (*(long *)(lVar2 + 0x28) != local_a0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}

