# Technical reverse-engineering report

## 1. Scope

The goal was a static, maximally complete extraction of the GUI embedded in `barbatos.sh`. No payload code was executed. The deliverable separates:

- **address-faithful evidence** — Ghidra pseudocode, disassembly, xrefs, relocation tables and exact embedded assets;
- **compilable reconstruction** — GUI-only Dear ImGui C++ that omits hooks, process access, networking and game behavior.

The result is not represented as verbatim original source. A stripped optimized executable cannot preserve original identifiers, comments, typedefs or source layout.

## 2. Static unpacking and identity

The wrapper declares `skip=50` and uses `tail -n +50 | gzip -cd`. The same operation was applied without running the extracted file.

```text
barbatos.sh SHA-256: 27adfdd05d6dc9704fde0007f44d232fa8f9248f525933a1dccabe1a8ac9627d
payload SHA-256:     f48e21da34939699a183dbacf1ad046c1ed8f2c92fdaaf8c938b69f326bb0c86
```

ELF metadata:

```text
Class:       ELF64
Endian:      little
Type:        DYN / PIE
Machine:     AArch64
Entry VA:    0x14DCD0
Interpreter: /system/bin/linker64
Min API:     Android 21
Build ID:    786e852a38c9a955c87fa0837ce7b4b91141cbc4
Toolchain:   Android NDK r25c
```

Framework evidence includes `ImGui`, `1.88 WIP`, `imgui_impl_android`, `imgui_impl_opengl3`, EGL and GLES imports.

## 3. Analysis pipeline

1. `readelf`, `strings`, `file` and ELF program headers established format and dependencies.
2. `.eh_frame_hdr`/CFI plus Capstone recovered function boundaries and AArch64 `ADRP+ADD` references.
3. `R_AARCH64_RELATIVE` addends reconstructed string-pointer arrays that are zero/unresolved in the raw PIE image.
4. Ghidra 10.1.5 imported the payload as AArch64 with image base `0x00100000` and completed full analysis.
5. Ghidra recovered **4077 functions**. Fifty-three GUI/resource/file-picker functions were selected and all **53/53** decompiled successfully.
6. Recovered calls were assigned descriptive names only where behavior was supported by pseudocode/call usage. ELF VAs remain in every filename/header.
7. A compilable Dear ImGui reconstruction was written separately and checked against Dear ImGui v1.88.

Ghidra addresses are `ELF VA + 0x00100000`; the deliverable consistently reports original ELF VAs. Example: Ghidra `0x00251CCC` corresponds to ELF `0x00151CCC`.

## 4. Main renderer and page dispatch

`Gui_RenderMain` begins at ELF VA `0x151CCC` and is approximately 1300 lines of Ghidra C-like pseudocode. It builds the sidebar, selects resources, dispatches pages and renders update states.

The five-byte jump table at `0x2C210` contains:

```text
00 18 04 0A 02
```

Resolved dispatch:

```text
0 -> 0x1E5FE8  Gui_RenderHomePage
1 -> 0x1E4090  Gui_RenderDrawPage
2 -> 0x1E24EC  Gui_RenderAimPage
3 -> 0x1E69F8  Gui_RenderItemsPage
4 -> 0x1E8090  Gui_RenderSettingsPage
```

## 5. Custom widget region

The region `0x18A0EC–0x18D71C` contains private widgets and overlay animation/state helpers:

```text
0x18A0EC  Gui_CloseButton
0x18A268  Gui_TimedActionButton
0x18A604  Gui_ActionRow
0x18A9B4  Gui_ToggleRowCore
0x18AE40  Gui_ToggleRows
0x18B144  Gui_ToggleGroup
0x18B400  Gui_TwoStateRow
0x18B60C  Gui_ColorPicker
0x18BDD4  Gui_PresetColorPalette
0x18C248  Gui_ValueEditor
0x18C688  Gui_ValueEditorList
0x18CAC8  Gui_TaskToggleRows
0x18CEA0  Gui_ChoiceGroup
0x18D268  Gui_HomeNotices
0x18D3A0  Gui_TextBox
0x18D410  Gui_OverlayStateBegin
0x18D4C4  Gui_OverlayAnimation
0x18D71C  Gui_OverlayStateEnd
```

The public source implements behavioral equivalents. The decompiler directory preserves the actual private implementations, including cursor arithmetic, draw-list calls and animation state.

## 6. Aim page

`Gui_RenderAimPage` at `0x1E24EC` decompiles to roughly 700 lines. It contains:

- `Only Draw` mode;
- `Main Aim` group with `Aiming` and `Aim Pos`;
- aim-point combo: head/chest/pelvis;
- main auxiliary switches: Only Draw, Circle Aim, Finger Interference Aim, Hit aim, Not aim lie down, Not Ai;
- recoil, follow speed, steadiness and range/distance value editors;
- conditional panel values recovered from the overlay switch:
  - `2`: main auxiliary options;
  - `11`: stop-firing scope-flash / `Not Shoot Auto Aiming`;
  - `22`: `Continuous Click Aiming`;
  - `33`: sniper panel;
- weapon-ID action rows and three-state speed selector.

Relocation-backed labels at `0x28C3A8` and `0x28C3C0` provide the exact Chinese/English option arrays.

## 7. Draw page

`Gui_RenderDrawPage` at `0x1E4090` contains three top-level private toggle groups:

- player class: Rect Box, Line, Skeleton, Name And Distance, Health, Player Weapon;
- non-player class: 盒子, 载具, 空投, 地铁宝箱;
- other class: Radar, aimed warning, back-enemy warning, Not Draw Ai, Off Color Dynamic.

The overlay/config branches contain size, thickness/adjustment, skeleton distance, vehicle state, radar position/angle, aimed-warning size, health transparency/type/color, color selection and the 42-color popup.

Health choices and options are recovered from relocation arrays beginning at `0x28C4A8`.

## 8. Exact 42-color palette

`Gui_PresetColorPalette` at `0x18BDD4` iterates `0x2A` entries in six columns. Names are relocation pointers at `0x28C010`; RGBA values are copied to BSS by the guarded initializer at `0x14F4B4`.

All 42 names and exact float values are embedded in `src/barbatos_gui_reconstructed.cpp`. The list includes 紫罗兰, 克莱因蓝, 爱马仕橙, 蒂芙尼蓝, …, 纯白 and 纯黑.

## 9. Home and Items

Home notices are the relocation-backed six-string array at `0x28C518`.

The Items page includes Open Class Name, Dev Mode, My Items-Mate, the five-line tutorial array at `0x28C548`, global size/distance/color, category adjustment and custom class rows. `Gui_CustomItemRowCore` at `0x1E6130` combines:

- main button/toggle;
- animated enabled indicator;
- per-class color marker;
- class/display label;
- texture/icon action opening a class editor.

The reconstruction exposes equivalent enabled/color/size/distance/name editing for every `ItemEntry`.

## 10. Settings and file selection

`Gui_RenderSettingsPage` at `0x1E8090` is the largest page function (roughly 1450 lines). Recovered branches include:

- main process/screen-record controls and language mode;
- theme color branch;
- island size, photo, TTF/text, dynamic and island-test actions;
- two animation modes: `MacOS "神奇效果"` and `IpadOS "聚散效果"`;
- six dynamic task rows and long-island text;
- diagnostics: pid, libUE4, Matrix, Self, Arrayaddr/Count and SelfAddr;
- automatic traversal index and official/self/manual data mode;
- pointer-table overlay;
- restore original font/photo;
- cloud fonts;
- local `/storage/emulated/0` directory navigation;
- `.ttf`/`.TTF` and `.png`/`.jpg` filtering;
- photo preview and `设置为左上角图片` action.

The public implementation models file entries supplied by the host and deliberately performs no filesystem I/O.

## 11. Update dialog

`Gui_RenderMain` contains mandatory/non-mandatory update text, current/new version, size retrieval, progress, download/confirm/cancel, completion and launch states. The reconstruction exposes each side effect as a request flag in `UpdateDialogState`; no network or process action is performed.

## 12. String recovery

Two complementary catalogs are shipped:

- `gui_utf8_catalog.tsv`: direct UTF-8 references from the 53 selected functions;
- `gui_relocated_utf8.tsv`: GUI-range `R_AARCH64_RELATIVE` string pointers;
- `relocated_utf8_strings.tsv`: all printable relative-pointer strings.

Control characters are escaped as `\\n`, `\\r`, and `\\t` to keep the TSV machine-readable.

## 13. Assets

Forty valid PNG streams were carved by parsing chunks through `IEND`; five valid sfnt/TTF files were reconstructed from table directories. Files are byte-identical to payload data.

The large font at `0x2F04E0` is PingFang SC Heavy with 4142 glyphs. Smaller fonts identify as Kingsoft Cloud, Alibaba Health Font, OPPO Sans H and TTTGB Medium. Exact offsets, dimensions and hashes are in `assets/manifest.csv` and `reverse/fonts_manifest.txt`.

## 14. Validation

- Ghidra full analysis: 4077 functions.
- Selected GUI decompilation: 53/53 successful, no timeout/error.
- C++ syntax validation against Dear ImGui v1.88 with `-Wall -Wextra -Wpedantic`: successful.
- CMake static library build: recorded in `build_verification.txt`.

## 15. Limitations

- Original C++ identifiers, types, templates and comments are irrecoverable from this stripped binary.
- Ghidra pseudocode uses inferred types and may contain overlap warnings or low-level NEON expressions.
- Private pixel layout/easing is retained in pseudocode but translated to maintainable public Dear ImGui equivalents in `src/`.
- Dynamic behavior dependent on runtime game/process/network state cannot be established by static GUI analysis and is intentionally not implemented.
