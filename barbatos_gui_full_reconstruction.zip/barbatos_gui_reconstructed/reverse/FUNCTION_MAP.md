# Address map — selected GUI decompilation set

All addresses are original ELF virtual addresses. Ghidra used image base `0x00100000`, so its database address is `ELF VA + 0x00100000`. Every listed function has a corresponding file in `decompiler/`; all 53 selected functions decompiled successfully.

| ELF VA | Assigned name | Role |
|---:|---|---|
| `0x150D00` | `Gui_FormatBuffer` | variadic checked-format wrapper used by GUI text |
| `0x15109C` | `Gui_SidebarTabs` | navigation/tab helper |
| `0x151374` | `Gui_DrawWindowBackground` | main background drawing |
| `0x151598` | `Gui_RenderBootLayer` | boot/loading layer |
| `0x151938` | `Gui_InitializeFrameState` | frame/UI state initialization |
| `0x151CCC` | `Gui_RenderMain` | main renderer, page dispatch, updater |
| `0x154648` | `Gui_UpdateAction` | update action helper |
| `0x154790` | `Gui_UpdateWorker` | update/dynamic worker helper |
| `0x154964` | `Gui_UpdateCleanup` | update cleanup |
| `0x177570` | `Gui_CreateTextureFromMemory` | OpenGL texture creation |
| `0x177914` | `Gui_DecodeImage` | memory image decode |
| `0x178354` | `Gui_LoadExternalAsset` | external image load path |
| `0x17882C` | `Gui_SetExternalAsset` | replaces external asset slot |
| `0x1789AC` | `Gui_LoadEmbeddedAssets` | embedded PNG loader |
| `0x178FFC` | `Gui_LoadTextureToSlot` | decoded texture assignment |
| `0x179138` | `Gui_DrawTexture` | draw-list texture helper |
| `0x1793B8` | `Gui_RenderImageLayer` | image/backdrop layer |
| `0x18A0EC` | `Gui_CloseButton` | overlay close control |
| `0x18A268` | `Gui_TimedActionButton` | dual/timed action row |
| `0x18A604` | `Gui_ActionRow` | action row |
| `0x18A9B4` | `Gui_ToggleRowCore` | one animated toggle row |
| `0x18AE40` | `Gui_ToggleRows` | multi-row toggle widget |
| `0x18B144` | `Gui_ToggleGroup` | titled toggle group |
| `0x18B400` | `Gui_TwoStateRow` | two-state row |
| `0x18B60C` | `Gui_ColorPicker` | color editor widget |
| `0x18BDD4` | `Gui_PresetColorPalette` | 42 colors in 6 columns |
| `0x18C248` | `Gui_ValueEditor` | slider/value editor |
| `0x18C688` | `Gui_ValueEditorList` | list of parameter editors |
| `0x18CAC8` | `Gui_TaskToggleRows` | labeled task/toggle rows |
| `0x18CEA0` | `Gui_ChoiceGroup` | vertical icon/choice selector |
| `0x18D268` | `Gui_HomeNotices` | notice-list rendering |
| `0x18D3A0` | `Gui_TextBox` | custom text box |
| `0x18D410` | `Gui_OverlayStateBegin` | overlay opening state |
| `0x18D4C4` | `Gui_OverlayAnimation` | overlay transition update |
| `0x18D71C` | `Gui_OverlayStateEnd` | overlay closing state |
| `0x1E24EC` | `Gui_RenderAimPage` | full Aim page |
| `0x1E3B14` | `Gui_ChoiceCombo` | combo/segmented selector |
| `0x1E3FB8` | `Gui_FormatText` | bounded GUI formatter |
| `0x1E4090` | `Gui_RenderDrawPage` | full Draw page |
| `0x1E5DA4` | `Gui_UpdateDragScroll` | custom drag/scroll gesture state |
| `0x1E5FE8` | `Gui_RenderHomePage` | Home page |
| `0x1E6130` | `Gui_CustomItemRowCore` | custom-item row core |
| `0x1E67C4` | `Gui_CustomItemRow` | titled custom-item wrapper |
| `0x1E69F8` | `Gui_RenderItemsPage` | Items page |
| `0x1E7B28` | `Gui_ItemsWorker` | Items background/helper worker |
| `0x1E8090` | `Gui_RenderSettingsPage` | full Settings and nested overlays |
| `0x1EACB8` | `Gui_LanguageChoice` | language/radio choice row |
| `0x1EB170` | `Gui_FormatDiagnostic` | diagnostic text formatter |
| `0x1EB214` | `Gui_PointerTable` | pointer-table panel |
| `0x1EB57C` | `Gui_IsPictureExtension` | image extension classifier |
| `0x1EB820` | `Gui_PathSelection` | path/image selection UI |
| `0x1EB9CC` | `Gui_ListDirectory` | filtered directory enumeration |
| `0x1EBED0` | `Gui_ReportFileError` | selected-file decode/error helper |

Assigned names are analytical labels, not recovered symbol names. Address and body identity are authoritative; descriptive names may abstract compiler-inlined source concepts.
