# Technical reverse-engineering notes

## Unpacking

The shell wrapper declares `skip=50` and runs:

```sh
tail -n +50 "$0" | gzip -cd > "$gztmp"
```

Static extraction therefore used the same pipeline without executing the result.

## ELF metadata

```text
Class:       ELF64
Endian:      little
Type:        DYN / PIE
Machine:     AArch64
Entry VA:    0x14DCD0
Interpreter: /system/bin/linker64
Min API:     Android 21
Build ID:    786e852a38c9a955c87fa0837ce7b4b91141cbc4
```

Dependencies: `libEGL.so`, `libGLESv2.so`, `libGLESv3.so`, `libOpenSLES.so`, `libandroid.so`, `liblog.so`, `libz.so`, `libc.so`, `libm.so`, `libdl.so`.

The ELF contains no normal symbol table. Function boundaries were recovered from 3145 `.eh_frame_hdr` entries. AArch64 ADRP+ADD references were resolved against `.rodata`; 3636 string xrefs were recovered.

## GUI evidence

Framework strings include:

```text
ImGui
1.88 WIP
imgui_impl_android
imgui_impl_opengl3
imgui.ini
imgui_log.txt
```

The main render function `0x151CCC` calls all five page functions. Its switch uses a five-byte jump table at file/VA `0x2C210`:

```text
00 18 04 0A 02
```

Resolved targets:

```text
index 0 -> 0x152A54 -> 0x1E5FE8 Home
index 1 -> 0x152AB4 -> 0x1E4090 Draw
index 2 -> 0x152A64 -> 0x1E24EC Aim
index 3 -> 0x152A7C -> 0x1E69F8 Items
index 4 -> 0x152A5C -> 0x1E8090 Settings
```

## Relocation-backed GUI arrays

Because PIE pointers are zero in the file image, strings in pointer arrays were recovered from `R_AARCH64_RELATIVE` addends.

Aim points (`0x28C3A8`):

```text
头颅 / 胸腔 / 盆骨
Head / Chest / Pelvis (English labels inferred from the selected page)
```

Aim option arrays (`0x28C3C0`):

```text
单透模式, 圈内瞄准, 辅助横拉与压枪, 掉血瞄准, 倒地不瞄, 人机不瞄
Only Draw, Circle Aim, Finger Interference Aim, Hit aim, Not aim lie down, Not Ai
```

Item categories (`0x28C468`):

```text
盒子, 载具, 空投, 地铁宝箱
```

Health types/options (`0x28C4A8`):

```text
圆形血量, 矩形血量, 长条血量, 格式血量, 宽型血量
Circular Health, Rect Health One, Rect Health Two, 格式血量, Wide Blood Volume
同队同色 / Same team Same color
跟随血量 / Follow blood volume
```

Home notices (`0x28C518`):

```text
本系列产品无任何收费以及内部等
切勿被骗，开发者也不会主动联系你
本系列作品仅供学习研究
使用者的任何行为与应用作者无关
请在24小时内删除本应用 [下载代表同意本协议]
若有侵权违法行为,请联系我删除内容
```

Items tutorial (`0x28C548`):

```text
自定义物资教程
打开开发者模式
长按屏幕内你需要绘制的类名
如多个类名重叠可长按之后滑动选择
更改名字在启动本辅助的文件内更改
```

Language/effect options (`0x28C580`):

```text
简体中文
English
MacOS "神奇效果"
IpadOS "聚散效果"
```

## Assets

Forty valid PNG streams were carved by parsing PNG chunks through `IEND`. Five valid sfnt fonts were reconstructed by their table directories. Their exact metadata and hashes are in `assets/manifest.csv` and `fonts_manifest.txt`.

The large font at `0x2F04E0` is PingFang SC Heavy (4142 glyphs). The four small fonts appear to be icon/subset fonts: Kingsoft Cloud, Alibaba Health Font, OPPO Sans H, and TTTGB Medium.

## Limitations

This is a source-level reconstruction, not a claim that the original C++ was recovered verbatim. Compiler optimizations, stripping, inlining, lost variable names, and custom widget helpers prevent exact recovery. The public reconstruction preserves the GUI hierarchy and strings but replaces private widgets with equivalent Dear ImGui code.
