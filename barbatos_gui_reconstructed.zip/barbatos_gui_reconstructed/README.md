# Barbatos GUI — восстановленный исходный код

Это **статически восстановленная GUI-часть** файла `barbatos.sh` с Google Drive. Исходный C++ после компиляции вернуть побайтно невозможно: полезная нагрузка — stripped ELF без исходных имён и отладочной информации. Поэтому `src/` содержит читаемую реконструкцию интерфейса на Dear ImGui, построенную по строковым ссылкам, графу вызовов, структуре страниц и встроенным ресурсам.

## Что обнаружено

- `barbatos.sh` — оболочка `gzexe`: первые 49 строк распаковывают gzip-поток, начинающийся со строки 50.
- Внутри: **ELF64 AArch64 PIE для Android 21**, интерпретатор `/system/bin/linker64`.
- GUI: **Dear ImGui 1.88 WIP**, Android + OpenGL ES (`imgui_impl_android`, `imgui_impl_opengl3`, EGL/GLES).
- Бинарник собран NDK r25c, stripped.
- Интерфейс относится к оверлею для `com.tencent.ig`/`libUE4.so`; в нём есть страницы Aim, Draw/ESP, Items и Settings.
- Анализ выполнялся статически; ELF не запускался.

Хеши:

```text
barbatos.sh     SHA-256 27adfdd05d6dc9704fde0007f44d232fa8f9248f525933a1dccabe1a8ac9627d
unpacked ELF    SHA-256 f48e21da34939699a183dbacf1ad046c1ed8f2c92fdaaf8c938b69f326bb0c86
```

## Восстановленные функции GUI

| ELF VA | Назначение |
|---:|---|
| `0x151CCC` | главное окно, боковая навигация, выбор страницы, update dialog |
| `0x1789AC` | загрузка 40 встроенных PNG в GL-текстуры |
| `0x1E5FE8` | Home |
| `0x1E24EC` | Aim |
| `0x1E4090` | Draw/ESP |
| `0x1E69F8` | Items |
| `0x1E8090` | Settings |
| `0x1A2B0C` | `ImGui::BeginChild`-совместимая обёртка |
| `0x1A2C34` | `ImGui::EndChild` |
| `0x1A4DA8` | `ImGui::GetWindowDrawList` |
| `0x1A4BE4` | `ImGui::GetWindowPos` |
| `0x1A4BD0` | `ImGui::GetWindowSize` |
| `0x1A5BD0` | `ImGui::GetCursorScreenPos` |
| `0x1A5BE4` | `ImGui::SetCursorScreenPos` |
| `0x191800` | `ImGui::ColorConvertFloat4ToU32` |
| `0x1AF0EC` | `ImDrawList::AddText`-совместимый вызов |

Навигационный индекс восстановлен из jump table по адресу `0x2C210`:

```text
0 Home, 1 Draw, 2 Aim, 3 Items, 4 Settings
```

## Содержимое

- `src/barbatos_gui_reconstructed.hpp` — модель состояния, enum страниц и ресурсов.
- `src/barbatos_gui_reconstructed.cpp` — GUI-only реконструкция на Dear ImGui.
- `assets/` — 40 извлечённых PNG и 5 TTF, без перекодирования.
- `assets/contact_sheet.jpg` — контактный лист всех PNG.
- `assets/manifest.csv` — размеры, ELF-offset и SHA-256 ресурсов.
- `reverse/gui_string_xrefs.tsv` — строки GUI с адресами функции, инструкции и строки.
- `reverse/main_ui_disassembly.txt`, `reverse/aim_ui_disassembly.txt` — аннотированный AArch64 disassembly.
- `reverse/asset_xrefs.txt` — связи PNG → загрузчик.

## Использование реконструкции

Нужен Dear ImGui и backend приложения. Подключите:

```text
src/barbatos_gui_reconstructed.cpp
src/barbatos_gui_reconstructed.hpp
imgui.cpp / imgui_draw.cpp / imgui_tables.cpp / imgui_widgets.cpp
misc/cpp/imgui_stdlib.cpp
```

После загрузки PNG в текстуры заполните `TextureRegistry::images` в порядке `assets/manifest.csv` и вызывайте:

```cpp
barbatos_gui::GuiState state;
barbatos_gui::TextureRegistry textures;
// textures.images[...] = IDs, полученные backend-ом OpenGL/Vulkan/DirectX.
barbatos_gui::RenderBarbatosGui(state, textures);
```

Код намеренно содержит только интерфейс и модель состояния. В нём нет чтения памяти процессов, Android SurfaceComposer, сетевой авторизации, обновлятора, игровых хуков или реализации Aim/ESP.

## Точность реконструкции

Высокая точность:

- набор и порядок основных страниц;
- видимые подписи и группы элементов;
- Home-disclaimer, списки Aim point/health type/languages;
- update dialog;
- встроенные изображения и шрифты — извлечены напрямую, байт-в-байт.

Приблизительно восстановлено:

- исходные имена C++ переменных;
- точные размеры/отступы некоторых custom widgets;
- анимационные easing-параметры;
- часть условной видимости вложенных панелей;
- оригинальные пользовательские виджеты заменены эквивалентами на публичном API Dear ImGui.
