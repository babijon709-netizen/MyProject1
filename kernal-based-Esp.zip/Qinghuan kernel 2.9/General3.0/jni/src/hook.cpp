#include <cstring>
#include <cstdio>
#include <unistd.h>
#include <sys/system_properties.h>
#include <dlfcn.h>
#include <string.h>
#include <jni.h>
#include <draw.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <fstream>
#include <cassert>
#include <string>
#include <iostream>
#include <sys/mman.h>
#include <dlfcn.h>
#include <math.h>
#include <array>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <sys/inotify.h>
#include <wanbai.hpp>
#include <VecTool.h>
#include <timer.h>
#include <UeTools.h>
#include <hook.h>
#include <draw.h>
#include "Tools/shou.hpp"
//#include "过缺页.h"
//#include "内核读写.h"



void getUTF8(UTF8 * buf, long namepy)
{
    UTF16 buf16[16] = { 0 };
    落叶->读取指针(namepy, buf16, 28);
    UTF16 *pTempUTF16 = buf16;
    UTF8 *pTempUTF8 = buf;
    UTF8 *pUTF8End = pTempUTF8 + 32;
    while (pTempUTF16 < pTempUTF16 + 28)
    {
        if (*pTempUTF16 <= 0x007F && pTempUTF8 + 1 < pUTF8End)
        {
            *pTempUTF8++ = (UTF8) * pTempUTF16;
        }
        else if (*pTempUTF16 >= 0x0080 && *pTempUTF16 <= 0x07FF && pTempUTF8 + 2 < pUTF8End)
        {
            *pTempUTF8++ = (*pTempUTF16 >> 6) | 0xC0;
            *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
        }
        else if (*pTempUTF16 >= 0x0800 && *pTempUTF16 <= 0xFFFF && pTempUTF8 + 3 < pUTF8End)
        {
            *pTempUTF8++ = (*pTempUTF16 >> 12) | 0xE0;
            *pTempUTF8++ = ((*pTempUTF16 >> 6) & 0x3F) | 0x80;
            *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
        }
        else
        {
            break;
        }
        pTempUTF16++;
    }
}

FTransform getBone(uintptr_t addr)
{
    FTransform transform;  
    落叶->读取指针(addr, reinterpret_cast<void*>(&transform), 4 * 11);
    return transform;
}


float camera;
uintptr_t libUE4;
TempData TempRead;
TempData TempUes;
TempData *tempRead;

uintptr_t Matrix, oneself, Bone, Human, Mesh;
int AddrCount, MyTeam;


pid_t get_name_pid(char* name) {
    FILE* fp;
    pid_t pid;
    char cmd[0x100] = "pidof ";

    strcat(cmd, name);
    fp = popen(cmd,"r");
    fscanf(fp,"%d", &pid);
    pclose(fp);
    return pid;
}


using namespace std;






void 读取进程() 
{
	pid_t pid = get_name_pid((char*)"com.tencent.ig");
	pid_t pid2 = get_name_pid ((char*)"com.rekoo.pubgm");
	pid_t pid3 = get_name_pid ((char*)"com.vng.pubgmobile");
	pid_t pid4 = get_name_pid ((char*)"com.pubg.krmobile");
	pid_t pid5 = get_name_pid ((char*)"com.pubg.imobile");
	pid_t pid6 = get_name_pid((char*)"com.tencent.igce");
	
	if (pid > 0) {		
		落叶->initialize(pid);
	} else if (pid2 > 0) {
		落叶->initialize(pid2);
	} else if (pid3 > 0) {
		落叶->initialize(pid3);
	} else if (pid4 > 0) {
		落叶->initialize(pid4);
	} else if (pid5 > 0) {
		落叶->initialize(pid5);
	} else if (pid6 > 0) {
		落叶->initialize(pid6);
	} else {	
		printf("游戏未启动");
		exit(0);
	}
	
    memset(matrix, 0, 16);
	
	libUE4 = 落叶->getModuleBase("libUE4.so");
	
	while (!libUE4)
	{
		libUE4 = 落叶->getModuleBase("libUE4.so");
		sleep(1);
	}
	
    tempRead = &TempUes;

	if (screen_x > screen_y) {
		Higtih = screen_y / 2;
		Widtih = screen_x / 2;
	} else {
		Higtih = screen_x / 2;
		Widtih = screen_y / 2;
	}
	
	for (;;) {
		
		if(初始化){
	for(int i = 0; i<10;i++){
	pid_t pid = get_name_pid((char*)"com.tencent.ig");
	pid_t pid2 = get_name_pid ((char*)"com.rekoo.pubgm");
	pid_t pid3 = get_name_pid ((char*)"com.vng.pubgmobile");
	pid_t pid4 = get_name_pid ((char*)"com.pubg.krmobile");
	pid_t pid5 = get_name_pid ((char*)"com.pubg.imobile");
	pid_t pid6 = get_name_pid((char*)"com.tencent.igce");
	
	if (pid > 0) {		
		落叶->initialize(pid);
	} else if (pid2 > 0) {
		落叶->initialize(pid2);
	} else if (pid3 > 0) {
		落叶->initialize(pid3);
	} else if (pid4 > 0) {
		落叶->initialize(pid4);
	} else if (pid5 > 0) {
		落叶->initialize(pid5);
	} else if (pid6 > 0) {
		落叶->initialize(pid6);
	}
	
	libUE4 = 落叶->getModuleBase("libUE4.so");
	测试++;
	}
	
		}
		
		
		
		TempRead.mPlayerArray.Count = AddrCount;
		*tempRead = TempRead;
		
		AddrCount = 0;
		
		模块地址 = libUE4;
	
		auto Uworld = 落叶->读取指针<uintptr_t>(落叶->读取指针<uintptr_t>(libUE4 + 0xC36A488) + 0x0); // 读取游戏世界
		
    	auto Uleve = 落叶->读取指针<uintptr_t>(Uworld + 0x20);    // Uleve
		
    	auto 对象阵列 = DecryptActorsArray(Uleve, 0xA0, 0x448);
		
		if (!对象阵列) {
             对象阵列 = DecryptActorsArray(Uleve, 0xA0, 0x488);
        }
		
        if (!对象阵列) 
        {
            continue;
        }

		auto Arrayaddr = 落叶->读取指针<uintptr_t>(对象阵列);
		
		数组 = Arrayaddr;
		
		if(Arrayaddr >= 0x10000000000){
			continue;
		}

		auto Count = 落叶->读取指针<int>(对象阵列 + 0x8);
		
		if(Count <=0 || Count >=2000){
		    continue;
		}
		
		
		//矩阵
		Matrix = 落叶->读取指针<uintptr_t>(落叶->读取指针<uintptr_t>(libUE4 + 0xC7AE018) + 0x20) + 0x270;	
		
		//自身
		oneself =  落叶->读取指针<uintptr_t>(落叶->读取指针<uintptr_t>(libUE4 + 0xC36A488) + 0x0);
	
		//自身队伍
		MyTeam = 落叶->读取指针<int>(oneself + 0x8f8);		
		
	
		落叶->读取指针(落叶->读取指针<uintptr_t>(oneself + 0x1b0) + 0x1b0, &TempRead.MyPos, 12);				
		
		落叶->读取指针(Matrix, &matrix, 16 * 4);	
		落叶->读取指针(Matrix, &TempRead.matrix, 16 * 4);
		
		TempRead.Fov = 落叶->读取指针<float>(落叶->读取指针<uintptr_t>(落叶->读取指针<uintptr_t>(oneself + 0x90) + 0x490) + 0x4A4);  // 自身FOV   
		TempRead.IsAiming = 落叶->读取指针<int>(oneself + 0xfe1);
        TempRead.IsFiring = 落叶->读取指针<int>(oneself + 0x15a8);	
		
		for (int i = 0; i < Count; i ++)
		{		
			auto Objaddr = 落叶->读取指针<uintptr_t>(Arrayaddr + 8 * i);  // 遍历数量次数
			
		
				//过滤物资			
			if (落叶->读取指针<float>(Objaddr + 0x26c8) != 479.5) {
				continue;
			}
			
			
			uintptr_t object = 落叶->读取指针<uintptr_t>(Objaddr + 0x1b0); // 坐标指针
			
			if (object <= 0xffff || object == 0 || object <= 0x10000000 || object % 4 != 0 || object >= 0x10000000000)
            	continue;
				
			auto *Players = &TempRead.mPlayerArray.mPlayer[AddrCount];
			
	    
	           				
			落叶->读取指针(object + 0x1b0, &Players->Pos, 12);
			if (Players->Pos.x == 0 || Players->Pos.y == 0 || Players->Pos.x == 0) {
         		continue;
     		}
			
			int State = 落叶->读取指针<int>(Objaddr + 0xd34);
        	if (State == 1048576 || State == 1048592)
           		continue;
        

        	Players->TeamID = 落叶->读取指针<int>(Objaddr + 0x8f8);  // 队伍ID
        	if (Players->TeamID == MyTeam || Players->TeamID < 1)
            	continue;
            
        	float MinHealth = 落叶->读取指针<float>(Objaddr + 0xd50);  // 最小血量
        	float MaxHealth = 落叶->读取指针<float>(Objaddr + 0xd54);  //  最大血量
        	Players->Health = (MinHealth / MaxHealth) * 100;
        	
			
        	if (Players->Health > 100)
           		continue;
				
			if (落叶->读取指针<uintptr_t>(Objaddr + 0x1c0)) {
            	落叶->读取指针(落叶->读取指针<uintptr_t>(Objaddr + 0xd60) + 0xb0, &Players->Predict, sizeof(Players->Predict)); // 载具向量
      	 	} else {
            	落叶->读取指针(object + 0x200, &Players->Predict, sizeof(Players->Predict)); // 敌人向量
        	}              	
			
			GetDistance(Players->Pos, TempRead.MyPos, &Players->Distance);
			WorldToScreen(&Players->ScreenPos, &camera, &Players->w, Players->Pos);			
						
			Players->camera = camera;
			
			Players->IsBot = 落叶->读取指针<int>(Objaddr + 0x9a9);  // 人机
			
			if(DrawIo[9]&&Players->IsBot==1){
				continue;
			}
			
			getUTF8(Players->PlayerName, 落叶->读取指针<uintptr_t>(Objaddr + 0x8b0));// 名字
			
			Mesh = 落叶->读取指针<uintptr_t>(Objaddr + 0x458);		
		/*	
			if (Mesh <= 0xffff) 
				continue;
        	*/
        	
        	Human = Mesh + 0x1A0;	//骨骼阵列
			
        	Bone = 落叶->读取指针<uintptr_t>(Mesh + 0x7F8);		
	/*
		if (Bone <= 0xffff) 
				continue;
				*/
				
				
			
			
			FTransform meshtrans = getBone(Human);
            FMatrix c2wMatrix = TransformToMatrix(meshtrans);		
			
            /* 头部 */
            FTransform headtrans = getBone(Bone + 6 * 48);
            FMatrix boneMatrix = TransformToMatrix(headtrans);
            Players->Head.Pos = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
            Players->Head.Pos.z += 7; /* 脖子长度 */   			
            Players->Head.ScreenPos = WorldToScreen(Players->Head.Pos, matrix, camera);
			
            /* 胸部 */
            FTransform chesttrans = getBone(Bone + 5 * 48);
            FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
            Players->Chest.Pos = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
            Players->Chest.ScreenPos = WorldToScreen(Players->Chest.Pos, matrix, camera);
            
			/* 盆骨 */
            FTransform pelvistrans = getBone(Bone + 1 * 48);
            FMatrix boneMatrix2 = TransformToMatrix(pelvistrans);
            Players->Pelvis.Pos = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
            Players->Pelvis.ScreenPos = WorldToScreen(Players->Pelvis.Pos, matrix, camera);
			
            /* 左肩膀 */
            FTransform lshtrans = getBone(Bone + 12 * 48);
            FMatrix boneMatrix3 = TransformToMatrix(lshtrans);
            Players->Left_Shoulder.Pos = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
            Players->Left_Shoulder.ScreenPos = WorldToScreen(Players->Left_Shoulder.Pos, matrix, camera);
			
            /* 右肩膀 */
            FTransform rshtrans = getBone(Bone + 33 * 48);
            FMatrix boneMatrix4 = TransformToMatrix(rshtrans);
            Players->Right_Shoulder.Pos = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
            Players->Right_Shoulder.ScreenPos = WorldToScreen(Players->Left_Shoulder.Pos, matrix, camera);
			
            /* 左手肘 */
            FTransform lelbtrans = getBone(Bone + 13 * 48);
            FMatrix boneMatrix5 = TransformToMatrix(lelbtrans);
            Players->Left_Elbow.Pos = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
            Players->Left_Elbow.ScreenPos = WorldToScreen(Players->Left_Elbow.Pos, matrix, camera);
			
            /* 右手肘 */
            FTransform relbtrans = getBone(Bone + 34 * 48);
            FMatrix boneMatrix6 = TransformToMatrix(relbtrans);
            Players->Right_Elbow.Pos = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
            Players->Right_Elbow.ScreenPos = WorldToScreen(Players->Right_Elbow.Pos, matrix, camera);
			
            /* 左手腕 */
            FTransform lwtrans = getBone(Bone + 64 * 48);
            FMatrix boneMatrix7 = TransformToMatrix(lwtrans);
            Players->Left_Wrist.Pos = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
            Players->Left_Wrist.ScreenPos = WorldToScreen(Players->Left_Wrist.Pos, matrix, camera);
			
            /* 右手腕 */
            FTransform rwtrans = getBone(Bone + 63 * 48);
            FMatrix boneMatrix8 = TransformToMatrix(rwtrans);
            Players->Right_Wrist.Pos = MarixToVector(MatrixMulti(boneMatrix8, c2wMatrix));
            Players->Right_Wrist.ScreenPos = WorldToScreen(Players->Right_Wrist.Pos, matrix, camera);
			
            /* 左大腿 */
            FTransform Llshtrans = getBone(Bone + 53 * 48);
            FMatrix boneMatrix9 = TransformToMatrix(Llshtrans);
            Players->Left_Thigh.Pos = MarixToVector(MatrixMulti(boneMatrix9, c2wMatrix));
            Players->Left_Thigh.ScreenPos = WorldToScreen(Players->Left_Thigh.Pos, matrix, camera);
			
            /* 右大腿 */
            FTransform Lrshtrans = getBone(Bone + 57 * 48);
            FMatrix boneMatrix10 = TransformToMatrix(Lrshtrans);
            Players->Right_Thigh.Pos = MarixToVector(MatrixMulti(boneMatrix10, c2wMatrix));
            Players->Right_Thigh.ScreenPos = WorldToScreen(Players->Right_Thigh.Pos, matrix, camera);
			
            /* 左膝盖 */
            FTransform Llelbtrans = getBone(Bone + 54 * 48);
            FMatrix boneMatrix11 = TransformToMatrix(Llelbtrans);
            Players->Left_Knee.Pos = MarixToVector(MatrixMulti(boneMatrix11, c2wMatrix));
            Players->Left_Knee.ScreenPos = WorldToScreen(Players->Left_Knee.Pos, matrix, camera);
			
            /* 右膝盖 */
            FTransform Lrelbtrans = getBone(Bone + 58 * 48);
            FMatrix boneMatrix12 = TransformToMatrix(Lrelbtrans);
            Players->Right_Knee.Pos = MarixToVector(MatrixMulti(boneMatrix12, c2wMatrix));
            Players->Right_Knee.ScreenPos = WorldToScreen(Players->Right_Knee.Pos, matrix, camera);
			
            /* 左脚腕 */
            FTransform Llwtrans = getBone(Bone + 55 * 48);
            FMatrix boneMatrix13 = TransformToMatrix(Llwtrans);
            Players->Left_Ankle.Pos = MarixToVector(MatrixMulti(boneMatrix13, c2wMatrix));
            Players->Left_Ankle.ScreenPos = WorldToScreen(Players->Left_Ankle.Pos, matrix, camera);
			
            /* 右脚腕 */
            FTransform Lrwtrans = getBone(Bone + 59 * 48);
            FMatrix boneMatrix14 = TransformToMatrix(Lrwtrans);
            Players->Right_Ankle.Pos = MarixToVector(MatrixMulti(boneMatrix14, c2wMatrix));
            Players->Right_Ankle.ScreenPos = WorldToScreen(Players->Right_Ankle.Pos, matrix, camera);
			AddrCount ++; // 遍历人物数量
		}
		
	
usleep(200);
	}
	
	
}
