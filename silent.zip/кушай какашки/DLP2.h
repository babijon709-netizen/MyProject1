#pragma once
// ═══════════════════════════════════════════════════════════════════════════
// v147 DLP2 — САЙЛЕНТ = ЯДРО v140 («сделай как в v140» — запрос юзера)
// + ЕДИНСТВЕННАЯ прививка из v144: анти-краш (ревалидация цепи КАЖДЫЙ
// тик + сентинел оружия). Пост-в140 новодел УДАЛЁН: 3-е лицо (TP3W),
// крутилка («DLP2-МУЗЫКА»), анти-тряска, быстрая стрельба, АВТОШОТ с
// экранной кнопкой, зеркало тач-панели, RAGE-лэйн, busy-спин v145 —
// дерево = v140, кроме гвардов ниже и гейта «в упор» (AimbotEngine).
//
// ЯДРО v140 (проверено юзером: «норм сайлент») — наследник v134-v136,
// «0 патчинга».
//
// Архитектура подтверждена юзером на v134-v136 («щас работает», «норм
// сайлент»): НИ ОДНОГО байта кода не патчится — мы управляем ДАННЫМИ,
// которые читает фаер-код игры. Дизасм 11920 (v134): фаер-низ CDD
// (RVA 0x6561E24) строит Ray так: читает [this+0xC8]→brc, затем
// [brc+0x140]→brI, направление полёта — Vector3 по brI+0x20 (x) / +0x24
// (y) / +0x28 (z). Затем нормализует, крутит Quaternion.FromEulerRad
// (штатный разброс) и отдаёт Ray в CDR/CDW.
//
// ЗНАЧИТ: кто последним записал 12 байт в brI+0x20 — тот и направил пулю.
// MouseLook игры пишет то же поле 1 раз/кадр (~16мс); наш райтер тикает
// каждые 200мкс, а при СПРЕЕ (выстрел < 280мс назад) — ХОТ 70мкс (v139:
// «не все пули попадают» = окно протечки было равно такту 300мкс; 200/70
// сжимают протечку до <1%). probe=100% в v138 — смещённая выборка.
//
// Цепи до brc (ТРИ, дедуп, classguard-самосогласованность):
//   [pm+0x78]                      — маршрут 1
//   [[pm+0x90]+0x40]               — маршрут 2 (fpMgr = [pm+0x90])
//   [[[pm+0x90]+0x50]+0xC8]        — маршрут 3 ([fpMgr+0x50] = оружие,
//                                     [weapon+0xC8] = this фаер-компонента)
//   brI = [brc+0x140]
//
// Живой глаз: направление пересчитывается на КАЖДОЙ записи из ТЕКУЩЕЙ
// нативной камеры (Camera::getLastNativeEye) — прыжки/бег/тряска учтены
// в момент выстрела (репорт «прыгаю и стреляю»).
//
// Стелс: .text заводской 100% сессии; профиль записи неотличим от
// легального MouseLook (те же 12Б данных, те же адреса); ноль ptrace/
// RWX/свапов указателей. Окно: флуд пока держится цель (600мс продление
// публикацией) + 60мс грейс после отпускания — прыжковый ТАП ловится.
// ═══════════════════════════════════════════════════════════════════════════
#include <cstdint>
#include <atomic>
#include <mutex>

namespace dlp2 {

struct Stats {
    uint64_t writes    = 0;   // ok — фактически записанных 12Б пакетов
    uint64_t publishes = 0;   // команд от тика аима
    uint64_t iters     = 0;   // рабочих тиков райтера
    uint32_t guardFails= 0;   // classguard-отбои цепи
    uint32_t revalFails= 0;   // v147: гварды спасли кучу (цепь умерла до записи)
    uint32_t probeTot  = 0;   // проб чтения поля
    uint32_t probeOurs = 0;   // из них «наше» направление (≤1.8°)
    int      chains    = 0;   // живых цепей на последнем резолве (0..3)
    uintptr_t brI       = 0;  // последняя brI (диагностика)
    uintptr_t brc       = 0;  // последняя brc
};

class Writer {
public:
    static Writer& instance();

    // Включение механизма (меню сайлента). Запускает поток при первом вкл.
    void setEnabled(bool on);
    bool enabled() const { return m_enabled.load(std::memory_order_acquire); }

    // Команда от тика аима: держим цель. pm — адрес PlayerManager локала
    // (цепи резолвятся в потоке райтера), aim — точка аима (голова/тело).
    void publish(uintptr_t pm, const float aim[3], uintptr_t targetAddr);

    // Цель отпущена — 60мс грейс и тишина.
    void clearIntent();

    // Полный стоп (выход EGLIS).
    void shutdown();

    // Диагностика мгновенного состояния (для [SLNT]-лога).
    Stats stats() const;

private:
    Writer() = default;
    void threadLoop();
    bool resolveChains(uintptr_t pm);   // 3 маршрута → до 3 brI (кэш 500мс)
    void invalidateChains(const char* why);

    std::atomic<bool> m_enabled{false};
    std::atomic<bool> m_run{false};
    std::atomic<bool> m_threadLive{false};

    // почтовый ящик команды (мутекс: публикует тик аима, читает райтер)
    std::mutex  m_cmdMutex;
    uintptr_t   m_pm         = 0;   // PlayerManager локала
    float       m_aim[3]     = {0, 0, 0};
    uintptr_t   m_targetAddr = 0;
    uint64_t    m_lastPubMs  = 0;
    uint64_t    m_lastClearMs= 0;

    // счётчики
    std::atomic<uint64_t> m_writes{0};
    std::atomic<uint64_t> m_publishes{0};
    std::atomic<uint64_t> m_iters{0};
    std::atomic<uint32_t> m_guardFails{0};
    std::atomic<uint32_t> m_probeTot{0};
    std::atomic<uint32_t> m_probeOurs{0};

    // кэш цепей (доступ только из потока райтера)
    // v147: klassBrI — сырой klass-указатель brI (первое слово объекта)
    // для дешёвой ревалидации каждого тика (хэши имён — для 500мс-резолва)
    struct Chain { uintptr_t brc = 0; uintptr_t brI = 0; uint64_t klassBrcHash = 0; uint64_t klassBrIHash = 0; uintptr_t klassBrI = 0; bool ok = false; };
    Chain     m_ch[3];
    int       m_nCh      = 0;
    uint64_t  m_chainMs  = 0;     // когда резолвили
    uint64_t  m_lastDirMs= 0;     // для probe-периода
    float     m_lastDir[3] = {0, 0, 0};

    // v147: анти-краш (прививка v144) — состояние гвардов
    bool      chainStillValid(int i, uintptr_t pm);
    uint32_t  m_revalTick      = 0;
    uintptr_t m_lastWpnSentinel = 0;
    uint32_t  m_wpnDiffStreak  = 0;
    std::atomic<uint32_t> m_revalFails{0};

    // телеметрия
    uint64_t  m_telMs     = 0;
};

} // namespace dlp2
