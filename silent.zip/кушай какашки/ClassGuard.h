#pragma once
// ═══════════════════════════════════════════════════════════════════════════
// v100: КЛАСС-ГВАРД ГОРЯЧИХ ЗАПИСЕЙ (анти-UAF) — фикс крашей игры.
//
// Дамп v99 (3 краша за день): SIGSEGV в UnityMain/UnityGfxDeviceW с ДИКИМИ
// адресами (0xaa3d6f6191faf0, 0xa0db7d030352d0) — классическая ПОРЧА GC-Кучи
// Unity. Механика: мы пишем process_vm_writev'ом в адрес объекта
// (AimAssistConfig/Geg/FPHitscan/MouseLook/DispersionConfig), объект умирает,
// GC переиспользует память под ДРУГОЙ объект — наша запись ложится в чужие
// заголовки/поля, Unity падает на мусорных указателях.
// PointerValidator::isValid не ловит это: страница смаппирована, память
// «валидна», объект там ЧУЖОЙ.
//
// ГВАРД: перед серией записей читаем klass → имя класса и требуем совпадения
// (точное, из списка, или по префиксу). Не совпало — серия отменяется.
// Стоимость: 2-3 чтения на объект за тик — несопоставимо с ценой краша.
// ═══════════════════════════════════════════════════════════════════════════
#include "memory/MemoryMgr.h"
#include <cstdint>
#include <cstring>
#include <cstddef>

namespace classguard {

inline bool is(MemoryMgr& mem, uintptr_t obj,
               const char* const* names, size_t nNames) {
    if (obj < 0x10000 || obj > 0x7FFFFFFFFFFF) return false;
    const uintptr_t klass = mem.readPtr(obj);            // Il2CppObject.klass
    if (klass < 0x10000 || klass > 0x7FFFFFFFFFFF) return false;
    const uintptr_t nameP = mem.readPtr(klass + 0x10);   // Il2CppClass.name
    if (nameP < 0x10000 || nameP > 0x7FFFFFFFFFFF) return false;
    char buf[48] = {};
    if (!mem.readRaw(nameP, buf, sizeof(buf) - 1)) return false;
    buf[sizeof(buf) - 1] = '\0';
    for (size_t i = 0; i < nNames; ++i)
        if (std::strncmp(buf, names[i], sizeof(buf) - 1) == 0) return true;
    return false;
}

// один класс
inline bool is(MemoryMgr& mem, uintptr_t obj, const char* name) {
    return is(mem, obj, &name, 1);
}

// ═══ v101 ФИКС: startsWith был МЁРТВЫМ с рождения v100 ═══════════════════
// Было: is(mem, obj, &pfx, 1) → strncmp(buf, "FP", 47). strncmp сравнивает
// ВКЛЮЧАЯ завершающий '\0' префикса: "FPHitscan" vs "FP" → на 3-м символе
// 'H' vs '\0' → НЕ РАВНО → гвард отклонял ЛЮБОЙ класс оружия ВСЕГДА.
// Лог v100: [BULLET] гвард ×133 (100% попыток), «активен» всего ~10 раз =
// BULLET-режим был фактически мёртв весь день.
// Стало: сравнение ровно по длине префикса — «FP» ловит FPHitscan/FPBow/
// FPMelee/FPProjectile/FPWeaponBase и т.п.
inline bool startsWith(MemoryMgr& mem, uintptr_t obj, const char* pfx) {
    if (obj < 0x10000 || obj > 0x7FFFFFFFFFFF) return false;
    const uintptr_t klass = mem.readPtr(obj);
    if (klass < 0x10000 || klass > 0x7FFFFFFFFFFF) return false;
    const uintptr_t nameP = mem.readPtr(klass + 0x10);
    if (nameP < 0x10000 || nameP > 0x7FFFFFFFFFFF) return false;
    char buf[48] = {};
    if (!mem.readRaw(nameP, buf, sizeof(buf) - 1)) return false;
    buf[sizeof(buf) - 1] = '\0';
    const size_t n = std::strlen(pfx);
    if (n == 0 || n >= sizeof(buf)) return false;
    return std::strncmp(buf, pfx, n) == 0;
}

// v101: имя класса для ДИАГНОСТИКИ гвардов (лог [BULLET]: какой класс
// реально виден по адресу — сразу видно UAF или наш strncmp-баг).
// Возвращает false, если имя не читается.
inline bool className(MemoryMgr& mem, uintptr_t obj,
                      char* out, size_t cap) {
    if (!out || cap == 0) return false;
    out[0] = '\0';
    if (obj < 0x10000 || obj > 0x7FFFFFFFFFFF) return false;
    const uintptr_t klass = mem.readPtr(obj);
    if (klass < 0x10000 || klass > 0x7FFFFFFFFFFF) return false;
    const uintptr_t nameP = mem.readPtr(klass + 0x10);
    if (nameP < 0x10000 || nameP > 0x7FFFFFFFFFFF) return false;
    if (!mem.readRaw(nameP, out, cap - 1)) return false;
    out[cap - 1] = '\0';
    return out[0] != '\0';
}

} // namespace classguard
