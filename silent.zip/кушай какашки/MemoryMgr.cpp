#include "MemoryMgr.h"
#include "PointerValidator.h"
#include <sys/uio.h>
#include <cerrno>
#include <cstring>
#include <atomic>
#include <chrono>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "MemoryMgr"
#define LOGD(...) do { __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__); printf("[D] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGW(...) do { __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__); printf("[W] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)
#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__); printf("[E] " __VA_ARGS__); printf("\n"); fflush(stdout); } while(0)

namespace {
    std::atomic<int64_t> g_lastErrLogMs{0};
    std::atomic<int>     g_suppressedSinceLog{0};

    bool shouldLogError() {
        auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        int64_t last = g_lastErrLogMs.load(std::memory_order_relaxed);
        if (now_ms - last < 1000) {
            g_suppressedSinceLog.fetch_add(1, std::memory_order_relaxed);
            return false;
        }

        if (!g_lastErrLogMs.compare_exchange_strong(last, now_ms,
                std::memory_order_relaxed)) {
            return false;
        }
        return true;
    }

    int popSuppressedCount() {
        return g_suppressedSinceLog.exchange(0, std::memory_order_relaxed);
    }
}

MemoryMgr& MemoryMgr::instance() {
    static MemoryMgr mgr;
    return mgr;
}

bool MemoryMgr::attach(pid_t pid) {

    if (m_attached.load() && m_pid.load() == pid) {
        LOGD("Already attached to PID %d", pid);
        return true;
    }

    if (kill(pid, 0) != 0) {
        LOGE("Process %d does not exist or no permission (errno=%d: %s)",
             pid, errno, strerror(errno));
        m_attached.store(false);
        m_pid.store(0);
        return false;
    }

    m_pid.store(pid, std::memory_order_release);
    m_attached.store(true, std::memory_order_release);
    LOGD("Attached to PID %d", pid);
    return true;
}

void MemoryMgr::detach() {
    bool wasAttached = m_attached.exchange(false, std::memory_order_acq_rel);
    pid_t prev = m_pid.exchange(0, std::memory_order_acq_rel);
    if (wasAttached) {
        LOGD("Detached from PID %d", prev);
    }
}

ssize_t MemoryMgr::sysRead(uintptr_t remote, void* local, size_t len) const {
    pid_t pid = m_pid.load(std::memory_order_acquire);
    if (pid == 0) return -1;
    if (!PointerValidator::isRangeValid(remote, len)) return -1;

    struct iovec lv { local, len };
    struct iovec rv { reinterpret_cast<void*>(remote), len };
    return process_vm_readv(pid, &lv, 1, &rv, 1, 0);
}

ssize_t MemoryMgr::sysWrite(uintptr_t remote, const void* local, size_t len) const {
    pid_t pid = m_pid.load(std::memory_order_acquire);
    if (pid == 0) return -1;
    if (!PointerValidator::isRangeValid(remote, len)) return -1;

    struct iovec lv { const_cast<void*>(local), len };
    struct iovec rv { reinterpret_cast<void*>(remote), len };
    ssize_t n = process_vm_writev(pid, &lv, 1, &rv, 1, 0);
    if (n < 0 && shouldLogError()) {
        int suppressed = popSuppressedCount();
        LOGW("process_vm_writev failed at 0x%lx: %s (+%d similar errors suppressed)",
             static_cast<unsigned long>(remote), strerror(errno), suppressed);
    }
    return n;
}

bool MemoryMgr::readRaw(uintptr_t addr, void* buf, size_t len) const {
    if (!m_attached.load(std::memory_order_acquire)) return false;
    if (len == 0) return true;

    constexpr size_t MAX_CHUNK = 0x800000;
    uint8_t* dst = static_cast<uint8_t*>(buf);
    size_t remaining = len;
    uintptr_t cur = addr;

    uint8_t* origDst = dst;
    size_t totalDone = 0;
    while (remaining > 0) {
        size_t chunk = remaining > MAX_CHUNK ? MAX_CHUNK : remaining;
        ssize_t n = sysRead(cur, dst, chunk);
        if (n < 0 || static_cast<size_t>(n) != chunk) {
            size_t got = (n > 0) ? static_cast<size_t>(n) : 0;
            std::memset(origDst + totalDone + got, 0, len - totalDone - got);
            return false;
        }
        dst += chunk;
        cur += chunk;
        remaining -= chunk;
        totalDone += chunk;
    }
    return true;
}

// v21: стабильное чтение (см. MemoryMgr.h) — против «рваных» слепков
bool MemoryMgr::readRawStable(uintptr_t addr, void* buf, size_t len, int tries) const {
    if (len == 0) return true;
    if (len > 256) return readRaw(addr, buf, len);

    uint8_t a[256], b[256];
    for (int i = 0; i < tries; ++i) {
        if (!readRaw(addr, a, len)) return false;
        if (!readRaw(addr, b, len)) return false;
        if (std::memcmp(a, b, len) == 0) {
            std::memcpy(buf, a, len);
            return true;
        }
    }
    std::memcpy(buf, a, len);   // так и не совпало — отдаём последнее
    return true;
}

size_t MemoryMgr::readBestEffort(uintptr_t addr, void* buf, size_t len) const {
    if (!m_attached.load(std::memory_order_acquire) || len == 0) return 0;

    constexpr size_t MAX_CHUNK = 0x800000;
    uint8_t* dst = static_cast<uint8_t*>(buf);
    size_t remaining = len;
    uintptr_t cur = addr;
    size_t totalGot = 0;

    while (remaining > 0) {
        size_t chunk = remaining > MAX_CHUNK ? MAX_CHUNK : remaining;
        ssize_t n = sysRead(cur, dst, chunk);
        if (n <= 0) break;
        size_t got = static_cast<size_t>(n);
        totalGot += got;
        if (got != chunk) break;
        dst += chunk;
        cur += chunk;
        remaining -= chunk;
    }
    if (totalGot < len) {
        std::memset(static_cast<uint8_t*>(buf) + totalGot, 0, len - totalGot);
    }
    return totalGot;
}

bool MemoryMgr::writeRaw(uintptr_t addr, const void* buf, size_t len) const {
    if (!m_attached.load(std::memory_order_acquire)) return false;
    if (len == 0) return true;
    ssize_t n = sysWrite(addr, buf, len);
    return n >= 0 && static_cast<size_t>(n) == len;
}

bool MemoryMgr::readMany(const std::vector<ReadOp>& ops) const {
    if (!m_attached.load(std::memory_order_acquire) || ops.empty()) return false;
    pid_t pid = m_pid.load(std::memory_order_acquire);
    if (pid == 0) return false;

    constexpr size_t IOV_BATCH = 1024;
    bool allOk = true;

    for (size_t base = 0; base < ops.size(); base += IOV_BATCH) {
        size_t batch = std::min(IOV_BATCH, ops.size() - base);
        std::vector<struct iovec> locals(batch), remotes(batch);

        for (size_t i = 0; i < batch; ++i) {
            locals[i].iov_base  = ops[base + i].localBuf;
            locals[i].iov_len   = ops[base + i].size;
            remotes[i].iov_base = reinterpret_cast<void*>(ops[base + i].remoteAddr);
            remotes[i].iov_len  = ops[base + i].size;
        }

        size_t expected = 0;
        for (size_t i = 0; i < batch; ++i) expected += remotes[i].iov_len;

        ssize_t n = process_vm_readv(pid, locals.data(), batch,
                                     remotes.data(), batch, 0);
        if (n < 0) {
            // Throttle: логируем только 1 раз в секунду
            static int64_t lastLogMs = 0;
            int64_t now = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count();
            if (now - lastLogMs > 1000) {
                lastLogMs = now;
                LOGW("readMany batch at 0x%lx failed: %s",
                     (unsigned long)base, strerror(errno));
            }
            allOk = false;
        } else if (static_cast<size_t>(n) != expected) {
            // Partial read — это нормально (адрес частично невалиден).
            // Не логируем — это спам.
            allOk = false;
        }
    }
    return allOk;
}

uintptr_t MemoryMgr::readChain(uintptr_t base, std::initializer_list<uintptr_t> offsets) const {
    if (!m_attached.load(std::memory_order_acquire) || base == 0) return 0;

    uintptr_t addr = base;
    for (uintptr_t off : offsets) {
        uintptr_t ptr = 0;
        if (!readRaw(addr + off, &ptr, sizeof(uintptr_t))) return 0;
        if (ptr == 0 || !PointerValidator::isValid(ptr))  return 0;
        addr = ptr;
    }
    return addr;
}

