#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <vector>
#include <atomic>
#include <initializer_list>
#include <unistd.h>
#include <signal.h>

struct ReadOp {
    uintptr_t remoteAddr;
    void*     localBuf;
    size_t    size;
};

class MemoryMgr {
public:
    static MemoryMgr& instance();

    bool    attach(pid_t pid);
    void    detach();
    bool    isAttached() const { return m_attached.load(std::memory_order_acquire); }
    pid_t   getPid() const     { return m_pid.load(std::memory_order_acquire); }

    template<typename T>
    bool read(uintptr_t addr, T* out) const {
        if (!out) return false;
        return readRaw(addr, out, sizeof(T));
    }

    bool readRaw(uintptr_t addr, void* buf, size_t len) const;
    bool writeRaw(uintptr_t addr, const void* buf, size_t len) const;
    bool readRawStable(uintptr_t addr, void* buf, size_t len, int tries = 4) const;

    size_t readBestEffort(uintptr_t addr, void* buf, size_t len) const;

    template<typename T>
    bool write(uintptr_t addr, const T& value) const {
        return writeRaw(addr, &value, sizeof(T));
    }

    bool readMany(const std::vector<ReadOp>& ops) const;

    uintptr_t readPtr(uintptr_t addr) const {
        uintptr_t v = 0;
        return readRaw(addr, &v, sizeof(v)) ? v : 0;
    }

    uintptr_t readChain(uintptr_t base, std::initializer_list<uintptr_t> offsets) const;

    float   readFloat(uintptr_t addr) const { float v=0.0f; read(addr,&v); return v; }
    int32_t readInt32(uintptr_t addr) const { int32_t v=0;  read(addr,&v); return v; }
    int64_t readInt64(uintptr_t addr) const { int64_t v=0;  read(addr,&v); return v; }
    bool    readBool(uintptr_t addr)  const { uint8_t v=0;  read(addr,&v); return v!=0; }

private:
    MemoryMgr() = default;

    std::atomic<pid_t> m_pid{0};
    std::atomic<bool>  m_attached{false};

    ssize_t sysRead(uintptr_t remote, void* local, size_t len) const;
    ssize_t sysWrite(uintptr_t remote, const void* local, size_t len) const;
};

