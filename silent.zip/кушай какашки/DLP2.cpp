// ═══════════════════════════════════════════════════════════════════════════
// v137 DLP2 — реализация райтера (см. DLP2.h за архитектурой).
// История: v134 безжалостный райтер (около выстрелов) → v135 кап 60°/точка
// на выбор → v136 флуд весь тик удержания + единый вх-гейт → v137: тот же
// подтверждённый механизм + голова по оффсетам + авто noSpread (зажим и
// прыжок) — вся дельта поверх ядра, которое юзер подтвердил рабочим.
// ═══════════════════════════════════════════════════════════════════════════
#include "DLP2.h"

#include "../memory/MemoryMgr.h"
#include "../memory/ClassGuard.h"
#include "../game/Camera.h"
#include "../game/PlayerCache.h"  // v147: живой глаз локала (мотор)
#include "../esp/CombatFx.h"      // v139: детект выстрела для ХОТ-режима
#include "../offsets.h"

#include <android/log.h>
#include <cmath>
#include <cstring>
#include <unistd.h>
#include <chrono>
#include <thread>

#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, "EGLIS", __VA_ARGS__)

namespace {

uint64_t dlpNowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

bool dlpValid(uintptr_t p) {
    return p > 0x10000 && p < 0x7FFFFFFFFFFF;
}

} // namespace

namespace dlp2 {

Writer& Writer::instance() {
    static Writer w;
    return w;
}

void Writer::setEnabled(bool on) {
    if (on == m_enabled.load(std::memory_order_acquire)) return;
    m_enabled.store(on, std::memory_order_release);
    if (on && !m_run.load(std::memory_order_acquire)) {
        m_run.store(true, std::memory_order_release);
        if (!m_threadLive.load(std::memory_order_acquire)) {
            m_threadLive.store(true, std::memory_order_release);
            std::thread(&Writer::threadLoop, this).detach();
            ALOGI("[DLP2] v147 райтер запущен: калибр %umкс (ХОТ %umкс при спрее), окно %ums, грейс %ums, "
                  "12Б данных (Vector3 @+0x%lx), .text НЕ пишется",
                  (unsigned)offsets::player::dlp2::TICK_US,
                  (unsigned)offsets::player::dlp2::HOT_US,
                  (unsigned)offsets::player::dlp2::WINDOW_ACTIVE_MS,
                  (unsigned)offsets::player::dlp2::GRACE_MS,
                  (unsigned long)offsets::player::dlp2::BRI_XYZ);
        }
    }
    if (!on) {
        clearIntent();
        ALOGI("[DLP2] v147 райтер выключен — поле отпущено, MouseLook игры владеет камерой");
    }
}

void Writer::publish(uintptr_t pm, const float aim[3], uintptr_t targetAddr) {
    {
        std::lock_guard<std::mutex> lk(m_cmdMutex);
        m_pm = pm;
        m_aim[0] = aim[0]; m_aim[1] = aim[1]; m_aim[2] = aim[2];
        m_targetAddr = targetAddr;
        m_lastPubMs = dlpNowMs();
    }
    m_publishes.fetch_add(1, std::memory_order_relaxed);
}

void Writer::clearIntent() {
    std::lock_guard<std::mutex> lk(m_cmdMutex);
    m_lastClearMs = dlpNowMs();
}

Stats Writer::stats() const {
    Stats s;
    s.writes     = m_writes.load(std::memory_order_relaxed);
    s.publishes  = m_publishes.load(std::memory_order_relaxed);
    s.iters      = m_iters.load(std::memory_order_relaxed);
    s.guardFails = m_guardFails.load(std::memory_order_relaxed);
    s.revalFails = m_revalFails.load(std::memory_order_relaxed);
    s.revalFails = m_revalFails.load(std::memory_order_relaxed);
    s.probeTot   = m_probeTot.load(std::memory_order_relaxed);
    s.probeOurs  = m_probeOurs.load(std::memory_order_relaxed);
    s.chains     = m_nCh;   // поток райтера пишет — гонка безобидна (int)
    s.brI        = m_nCh > 0 ? m_ch[0].brI : 0;
    s.brc        = m_nCh > 0 ? m_ch[0].brc : 0;
    return s;
}

void Writer::shutdown() {
    m_run.store(false, std::memory_order_release);
    m_enabled.store(false, std::memory_order_release);
}

// ─── резолв 3 цепей: pm → brc → brI, самосогласованность классов ─────────
// classguard здесь самосогласованный: имя класса brc/brI в этом билде не
// документировано (обфускация), поэтому фиксируем имя при ПЕРВОМ успешном
// резолве и требуем его же при ревалидации — смена имени = UAF/мусор.
bool Writer::resolveChains(uintptr_t pm) {
    auto& mem = MemoryMgr::instance();

    const uintptr_t fpMgr = mem.readPtr(pm + offsets::player::dlp2::PM_FP_MANAGER);
    if (!dlpValid(fpMgr)) { invalidateChains("fpMgr"); return false; }

    const uintptr_t wpn = mem.readPtr(fpMgr + offsets::player::dlp2::FPMGR_WEAPON);
    const uintptr_t brcCand[3] = {
        mem.readPtr(pm + offsets::player::dlp2::PM_FIRE_COMP),                       // маршрут 1
        mem.readPtr(fpMgr + offsets::player::dlp2::FPMGR_BRC),                       // маршрут 2
        dlpValid(wpn) ? mem.readPtr(wpn + offsets::player::dlp2::WEAPON_BRC)
                      : (uintptr_t)0,                                                // маршрут 3
    };

    auto fnv = [](const char* s) {
        uint64_t h = 1469598103934665603ull;
        while (*s) { h ^= (uint8_t)*s++; h *= 1099511628211ull; }
        return h;
    };

    // слот = номер маршрута; хэши имён живут в слоте и переживают компакцию
    Chain tmp[3];
    int nOk = 0;
    for (int i = 0; i < 3; ++i) {
        const uintptr_t brc = brcCand[i];
        if (!dlpValid(brc)) continue;
        const uintptr_t brI = mem.readPtr(brc + offsets::player::dlp2::BRC_LOOKDIR);
        if (!dlpValid(brI)) continue;

        char nmBrc[32] = {0}, nmBrI[32] = {0};
        if (!classguard::className(mem, brc, nmBrc, sizeof(nmBrc))) continue;
        if (!classguard::className(mem, brI, nmBrI, sizeof(nmBrI))) continue;
        if (nmBrc[0] == '\0' || nmBrI[0] == '\0') continue;

        const uint64_t hB = fnv(nmBrc), hI = fnv(nmBrI);
        if (m_ch[i].klassBrcHash == 0) {
            // первый резолв слота — фиксируем имена
            m_ch[i].klassBrcHash = hB;
            m_ch[i].klassBrIHash = hI;
        } else if (m_ch[i].klassBrcHash != hB || m_ch[i].klassBrIHash != hI) {
            m_guardFails.fetch_add(1, std::memory_order_relaxed);
            continue;   // UAF/переиспользованная память — маршрут мёртв
        }

        tmp[nOk].brc = brc;
        tmp[nOk].brI = brI;
        tmp[nOk].klassBrcHash = hB;
        tmp[nOk].klassBrIHash = hI;
        tmp[nOk].klassBrI = mem.readPtr(brI);   // v147: сырой klass для ревалидации каждого тика
        tmp[nOk].ok  = true;
        ++nOk;
    }

    // дедуп одинаковых brI (цепи сходятся к одному компоненту)
    for (int i = 1; i < nOk; ++i) {
        for (int j = 0; j < i; ++j) {
            if (tmp[i].ok && tmp[j].ok && tmp[i].brI == tmp[j].brI) {
                tmp[i].ok = false;
                break;
            }
        }
    }
    int uniq = 0;
    for (int i = 0; i < nOk; ++i) {
        if (tmp[i].ok) m_ch[uniq++] = tmp[i];
    }
    for (int i = uniq; i < 3; ++i) m_ch[i] = Chain{};
    m_nCh = uniq;
    m_chainMs = dlpNowMs();
    return uniq > 0;
}

void Writer::invalidateChains(const char* why) {
    (void)why;
    m_nCh = 0;
    m_chainMs = 0;
}

// ═══ v147: РЕВАЛИДАЦИЯ ЦЕПИ ПЕРЕД КАЖДОЙ ЗАПИСЬЮ (прививка v144) ═════
// Краш v142/v143 (SEGV_ACCERR в UnityMain): цепь кэшировалась до 500мс;
// если объект освобождали (смена оружия/смерть/респавн) и GC переиспользовал
// память — райтер писал 12Б в ЧУЖОЙ объект = порча кучи игры. Гвард
// классов в резолве проверяет ПОСЛЕ факта. Здесь: 2-3 чтения на тик:
//   (1) поле brc+0x140 всё ещё указывает на НАШ brI;
//   (2) brc.manager всё ещё НАШ pm (обратный гард);
//   (3) klass brI не сменился (каждые 16 тиков, ~3мс).
// Любое «нет» — НЕ пишем, перерезолв. Цена: 2-3 чтения/тик — на фоне
// 12Б-записи незаметно; смысл: окно порчи сжато с 500мс до 1 такта.
bool Writer::chainStillValid(int i, uintptr_t pm) {
    auto& mem = MemoryMgr::instance();
    const Chain& c = m_ch[i];
    if (!c.ok || !dlpValid(c.brc) || !dlpValid(c.brI)) return false;

    // 1) brI всё ещё то, на что указывает поле brc+0x140 (маршрут-независимо)
    const uintptr_t brINow = mem.readPtr(c.brc + offsets::player::dlp2::BRC_LOOKDIR);
    if (brINow != c.brI) return false;

    // 2) brc всё ещё принадлежит НАШЕМУ локалу (обратный гард brc.manager)
    if (mem.readPtr(c.brc + offsets::player::dlp2::BRC_MANAGER) != pm) return false;

    // 3) klass brI не сменился (UAF-переиспользование с сохранившимися
    //    полями 1-2 — редкий, но возможный случай). Каждые 16 тиков (~3мс).
    if (((m_revalTick + (uint32_t)i) & 15u) == 0) {
        const uintptr_t k = mem.readPtr(c.brI);
        if (k != c.klassBrI) return false;
    }
    return true;
}

// ─── главный цикл райтера ────────────────────────────────────────────────
void Writer::threadLoop() {
    auto& mem = MemoryMgr::instance();
    auto& cam = Camera::instance();

    uint32_t writeCount = 0;   // для probe-периода (каждые 64 записи)
    bool     hotLogged  = false;   // v139: одноразовый лог ХОТ-режима

    while (m_run.load(std::memory_order_acquire)) {
        // ═══ v139: ХОТ-ТАКТ ПРИ СПРЕЕ ════════════════════════════════
        // «не все пули попадают, некоторые летят по центру»: между записью
        // игры (MouseLook каждый кадр) и нашей следующей записью есть окно
        // = наш такт; выстрел, прочитавший LookDirection в этом окне, летит
        // по камере. При спрее (выстрел < HOT_AFTER_MS назад) жмём такт до
        // 70мкс — окно протечки падает в ~4 раза, редирект каждой пули.
        {
            const uint64_t ls = CombatFx::instance().lastShotAtMs();
            const bool hot = (ls != 0 && dlpNowMs() - ls < offsets::player::dlp2::HOT_AFTER_MS);
            if (hot && !hotLogged) {
                hotLogged = true;
                ALOGI("[DLP2] v147: ХОТ-режим (спрей): такт %u→%umкс — редирект каждой пули",
                      (unsigned)offsets::player::dlp2::TICK_US,
                      (unsigned)offsets::player::dlp2::HOT_US);
            } else if (!hot) {
                hotLogged = false;
            }
            usleep(hot ? offsets::player::dlp2::HOT_US
                       : offsets::player::dlp2::TICK_US);
        }

        const uint64_t now = dlpNowMs();

        // ── окно активности: держим цель (publish продлевает) или грейс ──
        uint64_t lastPub = 0, lastClear = 0;
        uintptr_t pm = 0, tgt = 0;
        float aim[3] = {0, 0, 0};
        {
            std::lock_guard<std::mutex> lk(m_cmdMutex);
            lastPub = m_lastPubMs; lastClear = m_lastClearMs;
            pm = m_pm; tgt = m_targetAddr;
            aim[0] = m_aim[0]; aim[1] = m_aim[1]; aim[2] = m_aim[2];
        }
        const bool holding = (lastPub != 0 && now - lastPub <= offsets::player::dlp2::WINDOW_ACTIVE_MS);
        const bool grace   = (lastClear != 0 && now - lastClear <= offsets::player::dlp2::GRACE_MS);
        if (!holding && !grace) continue;          // тишина: поле у игры
        if (!holding) continue;                    // грейс без цели — не продлеваем
        if (!dlpValid(pm) || !dlpValid(tgt)) continue;

        // ── цепи: кэш 500мс, иначе резолв ───────────────────────────────
        if (m_nCh == 0 || now - m_chainMs > 500) {
            resolveChains(pm);
            if (m_nCh == 0) continue;
        }

        // ═══ v147: СЕНТИНЕЛ ОРУЖИЯ — смена = мгновенная инвалидация ═══
        // Смена оружия/смерть/респавн = brc/brI освобождаются В ЭТОТ КАДР.
        // Раньше (v140) писали по протухшей цепи до 500мс. Дебаунс: указатель
        // оружия МЕРЦАЕТ между инстансами — реальная смена = 2 чтения подряд.
        {
            const uintptr_t fpS = mem.readPtr(pm + offsets::player::dlp2::PM_FP_MANAGER);
            uintptr_t wpnS = 0;
            if (dlpValid(fpS)) wpnS = mem.readPtr(fpS + offsets::player::dlp2::FPMGR_WEAPON);
            if (m_lastWpnSentinel != 0 && wpnS != 0 && wpnS != m_lastWpnSentinel) {
                if (++m_wpnDiffStreak >= 2) {
                    m_wpnDiffStreak = 0;
                    m_lastWpnSentinel = wpnS;
                    invalidateChains("wpn switch");
                    m_revalFails.fetch_add(1, std::memory_order_relaxed);
                    continue;
                }
            } else {
                m_wpnDiffStreak = 0;
                if (wpnS != 0) m_lastWpnSentinel = wpnS;
            }
        }

        // ═══ v149: ГЛАЗ = НАТИВНАЯ КАМЕРА (откат к геометрии v138-v140) ═══
        // Репорт v148: «стоя не попадает, в присяде только в тело». Разбор:
        // отдача МЕРТВА ([SHOTD] lastH=0.000 при NREC; дизасм WeaponRecoil
        // bUG: vert = Random(MinRecoil.x, MaxRecoil.x) — занулено), разброс
        // 0 — а хитов 9.6% (77/798, из них 58 в голову = куда целятся, ТО
        // регистрируется). Регрессия = глаз v147 (мотор+калибровка):
        // eyeOffH — EMA по неподвижным кадрам → лагает присед/ADS; мотор —
        // 15Гц-снапшоты с интерполяцией. Сервер реплеит выстрел от СВОЕГО
        // глаза (= нативная камера в FP). В v138-v140 глаз был камерой — и
        // «попадал». Порядок v149: (1) камера ≤400мс; (2) мотор+высота
        // (живой фолбэк); (3) камера без ограничения возраста.
        Vec3 eye{0, 0, 0};
        bool eyeOk = false;
        {
            CameraData cdF{};
            if (cam.getLastGoodNative(cdF, 400.0) && cdF.position.length() > 0.5f) {
                eye = cdF.position;
                eyeOk = true;
            }
        }
        if (!eyeOk) {
            float mpv[3] = {0.0f, 0.0f, 0.0f};
            if (PlayerCache::readLivePosition(pm, mpv)) {
                const Vec3 motor{mpv[0], mpv[1], mpv[2]};
                if (motor.length() > 0.5f) {
                    eye = motor + Vec3{0.0f, cam.getCalibratedEyeHeight(), 0.0f};
                    eyeOk = true;
                }
            }
        }
        if (!eyeOk) {
            eye = cam.getLastNativeEye(eyeOk);
            if (eyeOk && eye.length() <= 0.5f) eyeOk = false;
        }
        if (!eyeOk) continue;

        const float dx = aim[0] - eye.x;
        const float dy = aim[1] - eye.y;
        const float dz = aim[2] - eye.z;
        const float len = std::sqrt(dx*dx + dy*dy + dz*dz);
        if (len < 0.25f || !std::isfinite(len)) continue;   // слишком близко/мусор

        const float dir[3] = { dx / len, dy / len, dz / len };

        // ── запись 12Б во все живые цепи ────────────────────────────────
        uint32_t okW = 0;
        ++m_revalTick;
        bool chainDied = false;
        for (int i = 0; i < m_nCh; ++i) {
            if (!m_ch[i].ok) continue;
            // v147: ревалидация КАЖДОГО тика — не пишем в освобождённый объект
            if (!chainStillValid(i, pm)) {
                chainDied = true;
                break;
            }
            if (mem.writeRaw(m_ch[i].brI + offsets::player::dlp2::BRI_XYZ, dir, 12))
                ++okW;
        }
        if (chainDied) {
            m_revalFails.fetch_add(1, std::memory_order_relaxed);
            invalidateChains("reval fail");
            continue;
        }
        if (okW == 0) {
            // все записи отбились — цепи протухли, форс-резолв
            invalidateChains("write fail");
            continue;
        }
        m_writes.fetch_add(okW, std::memory_order_relaxed);
        m_iters.fetch_add(1, std::memory_order_relaxed);

        // ── probe: каждые 64 записи читаем поле назад — наше ли оно ─────
        m_lastDir[0] = dir[0]; m_lastDir[1] = dir[1]; m_lastDir[2] = dir[2];
        if (++writeCount >= 64) {
            writeCount = 0;
            float rd[3] = {0, 0, 0};
            if (m_nCh > 0 &&
                mem.readRaw(m_ch[0].brI + offsets::player::dlp2::BRI_XYZ, rd, 12) &&
                std::isfinite(rd[0]) && std::isfinite(rd[1]) && std::isfinite(rd[2])) {
                const float dot = rd[0]*m_lastDir[0] + rd[1]*m_lastDir[1] + rd[2]*m_lastDir[2];
                const float ang = std::acos(std::fminf(std::fmaxf(dot, -1.0f), 1.0f)) * 57.2958f;
                m_probeTot.fetch_add(1, std::memory_order_relaxed);
                if (ang <= offsets::player::dlp2::PROBE_OURS_DEG)
                    m_probeOurs.fetch_add(1, std::memory_order_relaxed);
            }
        }

        // ── телеметрия раз в 2с (формат v136 — юзер по нему читает бой) ─
        if (now - m_telMs > 2000) {
            m_telMs = now;
            const Stats st = stats();
            const int pct = st.probeTot ? (st.probeOurs * 100 / st.probeTot) : 0;
            ALOGI("[DLP2] v147: цель 0x%lx — ok=%llu pub=%llu guard=%u reval=%u chain=%d "
                  "iters=%llu | probe=%d%% | brI=0x%lx brc=0x%lx | "
                  "12Б данных, .text НЕ пишется",
                  (unsigned long)tgt,
                  (unsigned long long)st.writes, (unsigned long long)st.publishes,
                  (unsigned)st.guardFails, (unsigned)st.revalFails, st.chains,
                  (unsigned long long)st.iters,
                  pct,
                  (unsigned long)st.brI, (unsigned long)st.brc);
        }
    }
}

} // namespace dlp2
