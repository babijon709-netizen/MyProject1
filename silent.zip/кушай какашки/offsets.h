#pragma once

#include <cstdint>
#include <cstddef>

namespace offsets {

namespace il2cpp {

    constexpr uintptr_t OBJECT_KLASS          = 0x0;

    constexpr uintptr_t CLASS_NAME            = 0x10;
    constexpr uintptr_t CLASS_NAMESPACE       = 0x18;
    constexpr uintptr_t CLASS_TYPE_INFO_PTR   = 0x28;
    constexpr uintptr_t CLASS_PARENT          = 0x30;
    constexpr uintptr_t CLASS_ELEMENT_CLASS   = 0x38;
    constexpr uintptr_t CLASS_FIELDS          = 0x50;
    constexpr uintptr_t CLASS_FIELD_COUNT     = 0x58;
    constexpr uintptr_t CLASS_METHOD_COUNT    = 0x5C;
    constexpr uintptr_t CLASS_STATIC_FIELDS   = 0xB8;

    constexpr uintptr_t STRING_LENGTH         = 0x10;
    constexpr uintptr_t STRING_CHARS          = 0x14;

    constexpr uintptr_t ARRAY_LENGTH          = 0x18;
    constexpr uintptr_t ARRAY_ELEMENTS        = 0x20;

    constexpr uintptr_t LIST_ITEMS            = 0x10;
    constexpr uintptr_t LIST_SIZE             = 0x18;
    constexpr uintptr_t LIST_VERSION          = 0x1C;

    constexpr uintptr_t DICT_ENTRIES          = 0x10;
    constexpr uintptr_t DICT_COUNT            = 0x18;

#if defined(__LP64__)
    constexpr size_t PTR_SIZE  = 8;
    constexpr size_t WORD_SIZE = 8;
#else
    constexpr size_t PTR_SIZE  = 4;
    constexpr size_t WORD_SIZE = 4;
#endif
}

namespace unity {

    constexpr uintptr_t GAMEOBJECT_NAME       = 0x18;
    constexpr uintptr_t GAMEOBJECT_TRANSFORM  = 0x20;
    constexpr uintptr_t GAMEOBJECT_LAYER      = 0x2C;
    constexpr uintptr_t GAMEOBJECT_TAG        = 0x30;
    constexpr uintptr_t GAMEOBJECT_ACTIVE     = 0x34;
    constexpr uintptr_t GAMEOBJECT_COMPONENTS = 0x38;

    constexpr uintptr_t TRANSFORM_POSITION    = 0x20;
    constexpr uintptr_t TRANSFORM_LOCAL_POS   = 0x2C;
    constexpr uintptr_t TRANSFORM_ROTATION    = 0x38;
    constexpr uintptr_t TRANSFORM_LOCAL_SCALE = 0x44;
    constexpr uintptr_t TRANSFORM_FORWARD     = 0x50;
    constexpr uintptr_t TRANSFORM_UP          = 0x5C;

    constexpr size_t VECTOR3_SIZE             = 12;
    constexpr size_t QUATERNION_SIZE          = 16;
    constexpr size_t MATRIX4X4_SIZE           = 64;
}

namespace baseEntity {

    constexpr uintptr_t GAMEOBJECT_PTR = 0x10;

    constexpr uintptr_t NETWORK_ID     = 0x20;
    constexpr uintptr_t PREFAB_ID      = 0x24;
}

namespace game_controller {

    // RVA взяты из свежего дампа 1.13.11910 (GameController — наследник GameControllerBase):
    //   Start() = 0x646A4FC  (можно хукать для GC instance)
    //   Update() = 0x64688A4
    // GameControllerBase абстрактный, Awake в нём нет.
    constexpr uintptr_t RVA_AWAKE   = 0x60aea03;  // legacy — оставлен для совместимости (в 11910 неактуален)
    constexpr uintptr_t RVA_START   = 0x646a4fc;  // GameController.Start()  — сврено по дампу 11910
    constexpr uintptr_t RVA_UPDATE   = 0x64688a4;  // GameController.Update() — сврено по дампу 11910

    constexpr uintptr_t OFFSET_PLAYER_MANAGER      = 0x10;
    constexpr uintptr_t OFFSET_CAMERA_MANAGER      = 0x38;
    constexpr uintptr_t OFFSET_INPUT_MANAGER       = 0x28;
    constexpr uintptr_t OFFSET_AUDIO_UTILS         = 0x30;
    constexpr uintptr_t OFFSET_ITEM_DATABASE       = 0x48;
    constexpr uintptr_t OFFSET_SCREEN_CONTROLS     = 0x50;
    constexpr uintptr_t OFFSET_DISSONANCE_COMMS    = 0x58;
    constexpr uintptr_t OFFSET_GAME_CONTROLLER     = 0x60;
    constexpr uintptr_t OFFSET_GAME_NETWORK        = 0x0;
    constexpr uintptr_t OFFSET_PLAYER_INPUT_HANDLER = 0x20;
}

namespace player {

    // ═══════════════════════════════════════════════════════════════════
    // ВСЕ ПОЛЕВЫЕ ОФФСЕТЫ СВЕРЕНЫ С dump.cs 1.13.11914 (v83, полная
    // сверка диффом 11910→11914): все классы БЕЗ СДВИГОВ — патч-обновление
    // игры сменило ТОЛЬКО имена обфускации и добавило misfire-поля в
    // HitscanWeaponConfig (см. v83-блок ниже, namespace hsc2).
    // Переименованная обфускация (11910→11914): fs→ZL (KCC-интерфейс),
    // Qq→hB (combat), RH*→ze*, uo→iV, fZ→ZT, Jb*→Sb*, Zh*→Kl*, ZM*→Ka*,
    // WN*→UW*, Rk*→zb*, Zvr→KkL, ZqU→KhJ, Zqu→Kht, TxG→KlB ...
    // ПРАНК 11905→11910 (легаси): QCF→ZCf, DPx→RxI и пр.
    // ═══════════════════════════════════════════════════════════════════

    // RVA из дампа 1.13.11910 (легаси, в 11914 НЕ АКТУАЛЬНЫ — RVA меняются
    // каждым билдом; код их не использует, оставлены для истории):
    // PlayerManager.OnStartLocalPlayer() = 0x652ABB8
    constexpr uintptr_t RVA_ON_START_LOCAL_PLAYER = 0x652abb8;

    // ============================================================
    // СТАТИЧЕСКИЕ ПОЛЯ PlayerManager (из дампа)
    // ЭТО СМЕЩЕНИЯ ВНУТРИ СТАТИЧЕСКОЙ СЕКЦИИ!
    // Реальные RVA = BaseStatic + эти смещения
    // ============================================================
    constexpr uintptr_t STATIC_SLEEPING_PLAYER_LIST = 0x0;   // PQ`1<PlayerManager>
    constexpr uintptr_t STATIC_ACTIVE_PLAYER_LIST   = 0x8;   // PQ`1<PlayerManager> (ESP loop)
    constexpr uintptr_t STATIC_CLIENT_PLAYER_LIST   = 0x10;  // List`1<PlayerManager>
    constexpr uintptr_t STATIC_SERVER_NAME          = 0x18;  // string
    constexpr uintptr_t STATIC_SERVER_BUILD_NUMBER  = 0x20;  // string
    constexpr uintptr_t STATIC_TZW                  = 0x28;  // HashSet`1<PlayerManager> (11910: ZpQ)

    // ============================================================
    // ПОЛЯ PlayerManager (из дампа) — ВСЕ СМЕЩЕНИЯ ПРОВЕРЕНЫ
    // ============================================================
    constexpr uintptr_t WORLD_CAMERA_ROOT    = 0x68;
    constexpr uintptr_t MOUSE_LOOK           = 0x70;
    // v92: MouseLook.m_LookRoot @0x28 — ТРАНСФОРМ РИГА КАМЕРЫ (управляемый
    // Transform). Главный путь 3-го лица: managed Transform → m_CachedPtr@0x10
    // → resolveNativeTransformTD — ТОТ ЖЕ проверенный путь, что кости ESP.
    // (Нативная цепочка Camera→GameObject из v90 не собралась: ни один
    // кандидат +0x10/0x8/0x18/0x20 не дал валидный localPos — лог v90.)
    constexpr uintptr_t MOUSE_LOOK_LOOKROOT  = 0x28;
    constexpr uintptr_t EVENT_HANDLER        = 0x78;
    constexpr uintptr_t RAYCAST_MANAGER      = 0x88;
    constexpr uintptr_t FP_MANAGER           = 0x90;
    constexpr uintptr_t INVENTORY            = 0x98;
    constexpr uintptr_t PLAYER_MAP           = 0xA0;
    constexpr uintptr_t NET_POS_OBSERVER     = 0xA8;
    constexpr uintptr_t KCC_REFERENCE        = 0xB0;
    constexpr uintptr_t VITALS               = 0xC8;
    constexpr uintptr_t STATS                = 0xD0;
    constexpr uintptr_t LOOT_REFERENCE       = 0xD8;
    constexpr uintptr_t LIFE_STORY           = 0xE0;
    constexpr uintptr_t EQUIPMENT            = 0xE8;
    constexpr uintptr_t WEAPON_REFERENCE     = 0xF0;
    constexpr uintptr_t BLUEPRINTS_REFERENCE = 0xF8;
    constexpr uintptr_t COMPASS              = 0x100;
    constexpr uintptr_t STATISTICS           = 0x108;
    constexpr uintptr_t PURCHASES            = 0x110;
    constexpr uintptr_t MISSIONS             = 0x118;
    constexpr uintptr_t TEAM                 = 0x120;
    constexpr uintptr_t STATUS_EFFECT_VISUALS = 0x128;
    constexpr uintptr_t NICKLABEL            = 0x130;
    constexpr uintptr_t BROADCAST_TRIGGER    = 0x138;
    constexpr uintptr_t VOICE_PLAYER         = 0x140;
    constexpr uintptr_t SIMULATION           = 0x148;
    constexpr uintptr_t CHARACTER_MODEL      = 0x150;
    constexpr uintptr_t PLAYER_CALENDAR_DATA = 0x160;
    constexpr uintptr_t LEVELS_CONFIG        = 0x178;
    constexpr uintptr_t AIM_ASSIST_CONFIG    = 0x180;
    constexpr uintptr_t BOOL_TXG             = 0x188;  // <Zhl>k__BackingField (11905: TxG)
    constexpr uintptr_t ANIMATOR             = 0x190;

    // ─── v22: РЕАЛЬНЫЙ СКЕЛЕТ — поля KCC (HyperHug...Player.KCC, дамп) ─────
    // Наш KCC валидируется по *(comp+0x78)==PM (player@0x78). Все читается
    // как managed-поля (те же чтения, что и Motor — у remote РАБОТАЮТ,
    // в отличие от native GO→Transform цепочек).
    constexpr uintptr_t KCC_HEAD             = 0x88;   // KCC.head : Transform (реальная кость головы)
    // v147 КОРЕНЬ «СКЕЛЕТ НЕ ПРАВИЛЬНЫЙ + ТОЧКА=ФОЛБЭК»: в 11920 поле
    // CharacterAnimation ovH лежит на 0xF0 (дамп 11920 dump.cs:188131),
    // было 0x108 (11905/11914) — выше добавился AnimThrottleConfig _animConfig
    // @0xE0 (структура 0x10). Чтение +0x108 ловило ovs (float) как указатель
    // → CA невалиден → PMI-цепь мертва → [RB] failCode=1 ×144 (лог v140),
    // скелет-синтетика, точка аима = ноги+1.5м.
    constexpr uintptr_t KCC_CHAR_ANIM        = 0xF0;   // KCC.ovH : CharacterAnimation (11914: 0x108 «Jbe/MxM»)
    // CharacterAnimation (MonoBehaviour):
    constexpr uintptr_t CA_ANIMATOR          = 0x20;   // CA.animator : Animator
    constexpr uintptr_t CA_MODEL_INFO        = 0x30;   // CA.playerModelInfo : PlayerModelInfo
    constexpr uintptr_t CA_RAGDOLL           = 0x38;   // CA.ragdoll : Ragdoll
    constexpr uintptr_t CA_MF                = 0x88;   // CA.lcx : mn (процедурный слой костей; 11905: ZCk/Mf; 11915: mn @184760)
    // PlayerModelInfo (MonoBehaviour, на characterModel GO):
    constexpr uintptr_t PMI_HEAD             = 0x20;   // head : Transform
    constexpr uintptr_t PMI_R_WEAPON_HOLDER  = 0x28;   // rightWeaponHolder : Transform
    constexpr uintptr_t PMI_L_WEAPON_HOLDER  = 0x30;   // leftWeaponHolder : Transform
    constexpr uintptr_t PMI_EQUIP_HOLDER     = 0x38;   // equipmentHolder : Transform
    constexpr uintptr_t PMI_BODY             = 0x40;   // body : Transform (торс)
    constexpr uintptr_t PMI_HEAD_MODEL       = 0x48;   // headModel : Transform
    constexpr uintptr_t PMI_SMR              = 0x50;   // skinnedMeshRenderer : SkinnedMeshRenderer
    // fW (процедурный слой; 11905: Mf): массив bone-Transform'ов + int[] индексы
    // 11910 дополнительно: JIH HumanBoneConfig[] @0x20, JId Quaternion[] @0x58 (кватернионы костей)
    constexpr uintptr_t MF_ANIMATOR          = 0x10;   // JIW : Animator
    constexpr uintptr_t MF_ROOT              = 0x18;   // JIs : Transform (root)
    constexpr uintptr_t MF_BONES             = 0x48;   // JIK : Transform[] (11905: ZMd)
    constexpr uintptr_t MF_BONE_IDX          = 0x50;   // JIz : int[] (11905: ZMI)
    constexpr uintptr_t WEAPONS              = 0x198;
    constexpr uintptr_t NEXT_CHAT_TIME       = 0x1A0;
    constexpr uintptr_t LLZ                  = 0x1A4;  // private float ZhD (11905: LLz)
    constexpr uintptr_t LOOK_ANGLE           = 0x1A8;  // public float lookAngle (yaw) — подтверждено эталоном look@0x1a8
    constexpr uintptr_t COMBAT               = 0x1B0;  // public Qq combat (11905: co)
    constexpr uintptr_t IS_IN_AIR            = 0x1B8;
    constexpr uintptr_t IS_ON_PLAYER         = 0x1B9;
    constexpr uintptr_t VIOLATION_LEVEL      = 0x1BC;
    constexpr uintptr_t SPEEDHACK_PAUSE_TIME = 0x1C0;
    constexpr uintptr_t SPEEDHACK_DISTANCE   = 0x1C4;
    constexpr uintptr_t LAST_TICK_POSITION   = 0x1C8;  // Vector3 — ИСТОЧНИК ПОЗИЦИИ (как у друга)
    constexpr uintptr_t LAST_SAVED_POSITION  = 0x1D4;
    constexpr uintptr_t LAST_DEATH_POSITION  = 0x1E0;
    constexpr uintptr_t LAST_TICK            = 0x1EC;
    constexpr uintptr_t FLYHACK_PAUSE_TIME   = 0x1F0;
    constexpr uintptr_t FLYHACK_DISTANCE_VERTICAL = 0x1F4;
    constexpr uintptr_t FLYHACK_IN_AIR_SECONDS    = 0x1F8;
    constexpr uintptr_t FLYHACK_DISTANCE_HORIZ    = 0x1FC;
    constexpr uintptr_t LAST_VIOLATION_TYPE  = 0x200;
    constexpr uintptr_t NEXT_TERRAIN_CHECK   = 0x204;
    constexpr uintptr_t RESPAWNING           = 0x208;
    constexpr uintptr_t SUSPECTED_CONTROL    = 0x209;
    constexpr uintptr_t TRIGGERS             = 0x210;
    constexpr uintptr_t PLAYER_FLAGS         = 0x250;  // Sleeping=1, Spectating=2, Muted=4
    constexpr uintptr_t PRIME                = 0x254;
    constexpr uintptr_t KICKED               = 0x255;
    constexpr uintptr_t FOREIGN_CUPBOARD_ZONE_INTRUSION = 0x268;
    constexpr uintptr_t USER_ID              = 0x278;
    constexpr uintptr_t TEAM_NAME            = 0x280;
    constexpr uintptr_t VEHICLE_ID           = 0x288;
    constexpr uintptr_t SEAT_ID              = 0x28C;
    constexpr uintptr_t CLAN_ID              = 0x290;
    constexpr uintptr_t CLAN_TAG             = 0x298;
    constexpr uintptr_t ZIPLINE_ID           = 0x2AC;
    constexpr uintptr_t IS_IMMORTAL          = 0x2B1;

    // ═══ v79: движение/анти-спид + предметная цепочка (сверено по дампу 11910) ═══
    // KCC.speedModifier (public float) — РОДНОЙ множитель скорости персонажа.
    constexpr uintptr_t KCC_SPEED_MODIFIER   = 0x2BC;
    // KCC.crouchSpeed — отдельное поле KCC (не из CharacterSpeedConfig).
    constexpr uintptr_t KCC_CROUCH_SPEED     = 0xA8;
    // Клиентский анти-спид (Rust-порт): speedhackDistance копит «лишнюю»
    // дистанцию, speedhackPauseTime фризит движение при превышении.
    constexpr uintptr_t PM_SPEEDHACK_PAUSE   = 0x1C0;  // float speedhackPauseTime
    constexpr uintptr_t PM_SPEEDHACK_DIST    = 0x1C4;  // float speedhackDistance
    constexpr uintptr_t PM_FLYHACK_PAUSE     = 0x1F0;  // float flyhackPauseTime (прыжки)

    // ═══ v80: МАГИЯ/БИО/ЛОТ (все сверены по dump.cs 1.13.11910) ═══════════
    // PlayerManager+0x180 → AimAssistConfig (ScriptableObject, магнит прицела).
    constexpr uintptr_t PM_AIM_ASSIST        = 0x180;
    constexpr uintptr_t PM_RAYCAST_MGR       = 0x88;   // → RaycastManager (лут-луч)
    constexpr uintptr_t PM_VIOLATION_LEVEL   = 0x1BC;  // float violationLevel
    constexpr uintptr_t PM_FLYHACK_DIST_V    = 0x1F4;  // float flyhackDistanceVertical
    constexpr uintptr_t PM_FLYHACK_AIR_SEC   = 0x1F8;  // float flyhackInAirSeconds
    constexpr uintptr_t PM_FLYHACK_DIST_H    = 0x1FC;  // float flyhackDistanceHorizontal
    // PlayerVitals (PM+0xC8) → био-подсистемы PlayerVitals (свои поля базы):
    constexpr uintptr_t VIT_REGEN            = 0x118;  // StatRegenData m_HealthRegeneration
    constexpr uintptr_t VIT_THIRST           = 0x128;  // StatDepleter m_ThirstDepletion
    constexpr uintptr_t VIT_HUNGER           = 0x130;  // StatDepleter m_HungerDepletion
    constexpr uintptr_t VIT_OXYGEN           = 0x138;  // StatDepleter m_OxygenDepletion
    constexpr uintptr_t VIT_TEMPERATURE      = 0x144;  // float m_Temperature
    constexpr uintptr_t VIT_RAD_LEVEL        = 0x148;  // float m_RadiationLevel
    constexpr uintptr_t VIT_RAD_POISON       = 0x14C;  // float m_RadiationPoison
    namespace depl {                                   // StatDepleter
        constexpr uintptr_t RATE             = 0x10;   // float m_DepletionRate
        constexpr uintptr_t DMG              = 0x14;   // float m_Damage
    }
    namespace regen {                                  // StatRegenData
        constexpr uintptr_t ENABLED          = 0x10;   // bool m_Enabled
        constexpr uintptr_t PAUSE            = 0x14;   // float m_Pause
        constexpr uintptr_t SPEED            = 0x18;   // float m_Speed
    }
    namespace aacfg {                                  // AimAssistConfig
        constexpr uintptr_t DISTANCE         = 0x18;   // float distance
        constexpr uintptr_t INNER_W          = 0x1C;   // Vector2 innerRectSize.x
        constexpr uintptr_t INNER_H          = 0x20;   // Vector2 innerRectSize.y
        constexpr uintptr_t OUTER_W          = 0x24;   // Vector2 outerRectSize.x
        constexpr uintptr_t OUTER_H          = 0x28;   // Vector2 outerRectSize.y
        constexpr uintptr_t TIME_INC         = 0x2C;   // float timeIncreaseValue
        constexpr uintptr_t MOVE_INC         = 0x30;   // float moveIncreaseValue
        constexpr uintptr_t MOVE_DEC         = 0x34;   // float moveDecreaseValue
        constexpr uintptr_t OUTER_SPD        = 0x38;   // float outerMaxSpeed
        constexpr uintptr_t INNER_SPD        = 0x3C;   // float innerMaxSpeed
        constexpr uintptr_t OUTER_ABS        = 0x40;   // float outerMaxAbsoluteSpeed
        constexpr uintptr_t INNER_ABS        = 0x44;   // float innerMaxAbsoluteSpeed
        constexpr uintptr_t SWITCH           = 0x48;   // float targetSwitchDelay
    }
    namespace raym {                                   // RaycastManager
        constexpr uintptr_t RAY_LEN          = 0x38;   // float m_RayLength
        constexpr uintptr_t AIM_RAY_LEN      = 0x3C;   // float m_AimRayLength
    }
    // CharacterSpeedConfig: Gravity @0x34 (для лунной гравитации; 0x18-0x30/0x48 уже в коде).
    constexpr uintptr_t SPEEDCFG_GRAVITY     = 0x34;
    // ── v91: ВЕСЕЛЬЕ — конфиг движения (сверено с дампом 11915) ─────────
    constexpr uintptr_t SPEEDCFG_BACK_FACTOR = 0x2C;  // float BackSpeedFactor (скейтборд: назад как вперёд)
    constexpr uintptr_t SPEEDCFG_LADDER      = 0x3C;  // float SpeedOnLadder (лестница-ракета)
    constexpr uintptr_t SPEEDCFG_SLIDE       = 0x44;  // float SlidingSpeed (вечный слайд)
    constexpr uintptr_t SPEEDCFG_SWIM_ASC    = 0x60;  // float SwimAscendSpeed (рыба-торпеда)
    constexpr uintptr_t SPEEDCFG_WATER_GRAV  = 0x84;  // float WaterGravity (плавучесть)
    // KCC: m_AirControl @0x94 — управление в воздухе (сёрф-режим).
    constexpr uintptr_t KCC_AIR_CONTROL      = 0x94;
    // KCC: клиентская реконсилиация позиции (тянет назад при рассинхроне).
    constexpr uintptr_t KCC_MINOR_CORR_THR   = 0xCC;   // float minorCorrectionThreshold
    constexpr uintptr_t KCC_RECONCILE_THR    = 0xD0;   // float reconciliationThreshold
    // ── v81 АНТИ-ТП ─────────────────────────────────────────────────────
    // KCC: бюджет «минорных коррекций» РАСТЁТ заново каждый кадр
    // (minorCorrectionGrow/Decay @0xC0/0xC4, rttBasedMinorCorrection @0xC8 —
    // при true пороги пересчитываются от RTT и наши 99999 не живут).
    constexpr uintptr_t KCC_MINOR_GROW       = 0xC0;   // float minorCorrectionGrow
    constexpr uintptr_t KCC_MINOR_DECAY      = 0xC4;   // float minorCorrectionDecay
    constexpr uintptr_t KCC_RTTPED           = 0xC8;   // bool rttBasedMinorCorrection
    // PlayerManager: якоря анти-спида (Rust-порт). speedhackDistance —
    // НАКОПИТЕЛЬ «лишней» дистанции: += |pos − lastTickPosition| − лимит.
    // Держим lastTickPosition/lastSavedPosition = текущая позиция → дельта 0.
    constexpr uintptr_t PM_LAST_TICK_POS     = 0x1C8;  // Vector3 lastTickPosition
    constexpr uintptr_t PM_LAST_SAVED_POS    = 0x1D4;  // Vector3 lastSavedPosition
    constexpr uintptr_t PM_LAST_VIOLATION    = 0x200;  // HackType lastViolationType (int)
    // ═══ v93: АНТИ-ЧИТ ЩИТ — паузы/накопители античита (0x1BC..0x1FC) ═══
    // УЖЕ ОБЪЯВЛЕНЫ ВЫШЕ (см. строки ~235-246): PM_VIOLATION_LEVEL,
    // PM_SPEEDHACK_PAUSE/DIST, PM_FLYHACK_PAUSE, PM_FLYHACK_DIST_V/H,
    // PM_FLYHACK_AIR_SEC — типы из дампа (float). Здесь только новое:
    constexpr uintptr_t PM_SUSPECTED_CTRL    = 0x209;  // bool suspectedControl
    // KCC: JbV Move @0x16C — снапшот движения (Position @+0xC = 0x178):
    // реконсиляция сравнивает предикт с ним; равен нашей позиции = нет дрейфа.
    constexpr uintptr_t KCC_JBV_POS          = 0x178;  // Vector3 JbV.Position
    // ═══ v86: КРУТЕЛКА (CS2-стайл спинбот) ═══════════════════════════════
    // Источник вращения тела — мотор: KinematicCharacterMotor cXs @0x15C —
    // ЕДИНСТВЕННЫЙ Quaternion в transient-блоке (11914: после cXf=0x120
    // TransientPosition, cXT=0x12C TransientInitPos, тройка Vector3
    // 0x138/0x144/0x150, затем cXs) = _transientRotation. KCC каждый
    // физ-тик перезаписывает его поворотом от камеры → пишем на 120 Гц.
    // PM.lookAngle @0x1A8 — публичный float (тело/ник-лейбл/визуал тела).
    // Move lql @0x16C — ИНЛАЙН-структура Move (State@0x0/Pose@0x4/
    // Position@0xC=0x178/RealVelocity@0x18=0x184/.../YRotation@+0x2C=0x198,
    // Tick@+0x34=0x1A0 — KCC_JBV_POS=0x178 это и есть Move.Position).
    constexpr uintptr_t PM_LOOKANGLE         = 0x1A8;  // float lookAngle (градусы)
    constexpr uintptr_t KCC_MOVE_LQL         = 0x16C;  // Move lql (инлайн, State@0x0)
    constexpr uintptr_t KCC_MOVE_YROT        = 0x198;  // Move.YRotation (@0x16C+0x2C)
    // ═══ v90: PlayerInput lqW @0x144 — ИНЛАЙН-структура ввода в KCC ══════
    // (dump 11915: public struct PlayerInput — MovementInput@0x0,
    //  LookDirection@0x8, YRotation@0x14, Jump@0x18, Sprint@0x19,
    //  Crouch@0x1A, Aim@0x1B, Ready@0x1C, Tick@0x20, TooClose@0x24;
    //  размер 0x28: 0x144+0x28 = 0x16C = lql — точное прилегание).
    // Это РЕАЛЬНЫЙ текущий ввод, из которого игра строит исходящий Move:
    // Move.YRotation ← PlayerInput.YRotation, поза ← Crouch, прыжок ← Jump.
    // Игра перезаписывает структуру каждый кадр (look-события) → мы пишем
    // на ~1000 Гц (fastLoop) — выигрываем гонку в ~87% кадров.
    constexpr uintptr_t KCC_INPUT            = 0x144;  // PlayerInput lqW (инлайн, 0x28)
    constexpr uintptr_t KCC_INPUT_YROT       = 0x158;  // PlayerInput.YRotation (0x144+0x14)
    constexpr uintptr_t KCC_INPUT_JUMP       = 0x15C;  // PlayerInput.Jump   (0x144+0x18)
    constexpr uintptr_t KCC_INPUT_SPRINT     = 0x15D;  // PlayerInput.Sprint
    constexpr uintptr_t KCC_INPUT_CROUCH     = 0x15E;  // PlayerInput.Crouch
    constexpr uintptr_t KCC_INPUT_TICK       = 0x164;  // PlayerInput.Tick (uint) — каденс ввода
    constexpr uintptr_t KCC_INPUT_LOOKDIR    = 0x14C;  // PlayerInput.LookDirection (Vector3)
    // ═══ v90: СЛОВАРИ ИСТОРИИ (mH<T> = Dictionary<uint,T> + Queue<uint>) ══
    // KCC клиент-предикшн: lqd@0x240 — история ввода (tick→PlayerInput),
    // lqD@0x248/lqR@0x250 — истории Move (tick→Move). Если игра читает
    // исходящий Move из истории — наши записи туда уходят на сервер.
    // Каденс ключей логируем в [PIPE] — по логу видно, живы ли словари.
    constexpr uintptr_t KCC_MH_INPUT         = 0x240;  // mH<PlayerInput> lqd
    constexpr uintptr_t KCC_MH_MOVE_SEND     = 0x248;  // mH<Move> lqD
    constexpr uintptr_t KCC_MH_MOVE_ACK      = 0x250;  // mH<Move> lqR
    // il2cpp managed layout: объект → klass@0x0, monitor@0x8, поля с 0x10.
    // mH<T>: Dictionary @+0x10.
    constexpr uintptr_t MH_DICT              = 0x10;
    // Dictionary<uint,T>: buckets@0x10, entries(массив)@0x18, count@0x20,
    // version@0x24.
    constexpr uintptr_t DICT_ENTRIES         = 0x18;
    constexpr uintptr_t DICT_COUNT           = 0x20;
    constexpr uintptr_t DICT_VERSION         = 0x24;
    // il2cpp Array: bounds@0x10, max_length@0x18, данные с 0x20.
    constexpr uintptr_t ARR_MAXLEN           = 0x18;
    constexpr uintptr_t ARR_DATA             = 0x20;
    // Entry<uint,T>: hashCode(int)@0x0, next(int)@0x4, key(uint)@0x8,
    // value(T)@0x10. Страйд = 0x10 + sizeof(T): PlayerInput 0x38, Move 0x70.
    constexpr uintptr_t ENTRY_VALUE          = 0x10;
    constexpr uint32_t  ENTRY_STRIDE_PI      = 0x38;   // 0x10 + 0x28
    constexpr uint32_t  ENTRY_STRIDE_MOVE    = 0x70;   // 0x10 + 0x60
    // ═══ v87: Move — остальные поля инлайн-снапшота (@0x16C + ...) ═══════
    // (dump 11915: State@0x0, Pose@0x4, Aim@0x8, Position@0xC, RealVelocity
    //  @0x18, MoveDirection@0x24 (Vector2), YRotation@0x2C, DeltaTime@0x30,
    //  Tick@0x34, BaseVelocity@0x38, LadderHostNetId@0x44, IsUnderWater@0x54)
    constexpr uintptr_t KCC_MOVE_STATE       = 0x16C;  // Move.State (MoveState, int)
    constexpr uintptr_t KCC_MOVE_POSE        = 0x170;  // Move.Pose  (Pose, int)
    constexpr uintptr_t KCC_MOVE_AIM         = 0x174;  // Move.Aim   (bool)
    constexpr uintptr_t KCC_MOVE_REALVEL     = 0x184;  // Move.RealVelocity (Vector3)
    constexpr uintptr_t KCC_MOVE_TICK        = 0x1A0;  // Move.Tick  (uint)
    constexpr uintptr_t KCC_MOVE_BASEVEL     = 0x1A4;  // Move.BaseVelocity (Vector3)
    // ═══ v89: KCC-флаги/поля, нужные БХОПУ ═════════════════════════════
    // m_EnableJumping @0x9D — если игра ставит false (зоны/вода), наш Jump=1
    // молча игнорируется. Пинним в 1 пока бхоп включён.
    constexpr uintptr_t KCC_ENABLE_JUMPING   = 0x9D;   // bool m_EnableJumping
    // ═══ v87: СТЕЛС — родное поле видимости (SyncVar) ═══════════════════
    // KCC.visibility @0x2C8: enum { Visible=0, Hidden=1 }, SyncVar-хук @0x2E0.
    constexpr uintptr_t KCC_VISIBILITY       = 0x2C8;  // enum visibility (SyncVar)
    // v81 MAGIC BULLETS: хитбоксы врагов (урон/зона считаются на клиенте).
    constexpr uintptr_t GV_HITBOXES          = 0xA8;   // GenericVitals.m_Hitboxes HitBox[]
    // FPHitscan burst (0x128 config / 0x130 mode / 0x134 minAim уже в коде):
    constexpr uintptr_t FPH_BURST_LEN        = 0x13C;  // int m_BurstLength
    constexpr uintptr_t FPH_BURST_DUR        = 0x140;  // float m_BurstDuration
    constexpr uintptr_t FPH_BURST_PAUSE      = 0x144;  // float m_BurstPause
    // FPBow (0x128 m_MaxDistance): инста-лук + prefab стрелы.
    constexpr uintptr_t FPB_MIN_TIME         = 0x138;  // float m_MinTimeBetweenShots
    constexpr uintptr_t FPB_MIN_AIM          = 0x13C;  // float minAimValueToFire
    constexpr uintptr_t FPB_PREFAB           = 0x150;  // ShaftedProjectile m_ArrowPrefab
    constexpr uintptr_t FPX_PREFAB           = 0x148;  // FPCrossbow → ShaftedProjectile m_ArrowPrefab
    namespace shaft {                                  // ShaftedProjectile (prefab стрелы)
        constexpr uintptr_t MAX_DIST         = 0x88;   // float m_MaxDistance
        constexpr uintptr_t LAUNCH           = 0xA8;   // float m_LaunchSpeed
        constexpr uintptr_t GRAVITY          = 0xAC;   // float gravity
        constexpr uintptr_t AIR_DRAG         = 0xB0;   // float airDrag
        constexpr uintptr_t UW_DRAG          = 0xB4;   // float underwaterDrag
    }
    namespace hitsc {                                  // HitscanWeaponConfig — упадок урона
        constexpr uintptr_t FALLOFF_MAX_X    = 0x1C;   // Vector2 MaxDamageOnDistance
        constexpr uintptr_t FALLOFF_MAX_Y    = 0x20;
        constexpr uintptr_t FALLOFF_MIN_X    = 0x24;   // Vector2 MinDamageOnDistance
        constexpr uintptr_t FALLOFF_MIN_Y    = 0x28;
    }
    // ── v82 TDM PVP ─────────────────────────────────────────────────────
    // GenericVitals.m_DamageMultipliers @0xB0 — float[] ПАРАЛЛЕЛЬНО
    // m_Hitboxes: РЕАЛЬНАЯ таблица множителей урона по частям (v81 патчил
    // только HitBox.m_DamageMultiplier — расчёт читает ЭТОТ массив).
    constexpr uintptr_t GV_DMG_MULTS         = 0xB0;   // float[] m_DamageMultipliers
    // KCC.applySpeed @0xB8 — скорость ПРИМЕНЕНИЯ коррекций реконсиляции
    // (рядом minorCorrectionGrow/Decay). 0 = коррекция «тянет» с нулевой
    // скоростью → серверный откат не двигает мотор.
    constexpr uintptr_t KCC_APPLY_SPEED      = 0xB8;   // float applySpeed
    // KCC.noclip @0x2CC — РОДНОЕ публичное поле (чит-полёт движка).
    constexpr uintptr_t KCC_NOCCLIP          = 0x2CC;  // bool noclip
    // v108 ПАТЧ 11915 → 11920 (сверка dump.cs FPHitscan @407873):
    // в FPHitscan вставлено 8 байт (signalProjectile @0x128 + паддинг),
    // ВСЕ поля после 0x124 уехали на +8.
    constexpr uintptr_t FPH_FIRE_DURATION    = 0x140;  // float m_FireDuration (было 0x138)
    constexpr uintptr_t FPH_SPAWN_TRACER     = 0x188;  // bool spawnTracer (было 0x180)
    namespace hsc {                                    // HitscanWeaponConfig — дальность
        constexpr uintptr_t MAX_DISTANCE     = 0x2C;   // float MaxDistance
        constexpr uintptr_t BULLET_SPEED     = 0x30;   // float BulletSpeed
        constexpr uintptr_t SUPPRESSED       = 0x52;   // bool suppressed (u8, глушитель)
    }
    // ── v83: ПАТЧ 11910 → 11914 (полная сверка по dump.cs 11914) ────────
    // ИТОГ СВЕРКИ: ВСЕ классы (PlayerManager/KCC/KCCM/CM/GenericVitals/
    // PlayerVitals/HitBox/HitBoxRecorderRoot/FP*/ShaftedProjectile/
    // BulletProjectile/AimAssistConfig/RaycastManager/Stat*/Inventory) —
    // БЕЗ СДВИГОВ (только переименования обфускации: fs→ZL, Qq→hB, Jb*→Sb*,
    // Zh*→Kl*, ZM*→Ka*, fZ→ZT, RH*→ze*, uo→iV ...).
    // ЕДИНСТВЕННЫЙ РЕАЛЬНЫЙ СДВИГ — HitscanWeaponConfig: в 11914 вставлены
    // float misfireChance @0x54 и float misfireChanceFalloff @0x58, поэтому
    // указатели конфигов УПЛЫЛИ:
    //   DispersionConfig* 0x58 → 0x60   (!!! в 11910 код читал 0x58 —
    //                                     а это уже misfireChanceFalloff:
    //                                     noSpread/NoRecoil молча умирали)
    //   RecoilConfig*     0x60 → 0x68
    namespace hsc2 {                                   // HitscanWeaponConfig v83
        constexpr uintptr_t DISPERSION_PTR   = 0x60;   // DispersionConfig* (11910: 0x58)
        constexpr uintptr_t RECOIL_PTR       = 0x68;   // RecoilConfig*     (11910: 0x60)
        constexpr uintptr_t MISFIRE          = 0x54;   // float misfireChance (НОВОЕ 11914)
        constexpr uintptr_t MISFIRE_FALL     = 0x58;   // float falloff (НОВОЕ 11914)
        constexpr uintptr_t NO_RELOAD_AIMED  = 0x51;   // bool suppressReloadWhileAimed
        constexpr uintptr_t MOBILITY         = 0x40;   // float mobility
    }
    namespace dispc {                                  // DispersionConfig (без сдвигов)
        constexpr uintptr_t MOVE_SCALE       = 0x30;   // float MoveScale
        constexpr uintptr_t AIM_FACTOR       = 0x34;   // float BaseDispersionAimFactor
        constexpr uintptr_t MOVE_AIM_FACTOR  = 0x38;   // float MoveDispersionAimFactor
        constexpr uintptr_t FIRE_AIM_FACTOR  = 0x3C;   // float FireDispersionAimFactor
    }
    namespace recoc {                                  // RecoilConfig (без сдвигов)
        constexpr uintptr_t RECOIL_TIME      = 0x34;   // float RecoilTime
        constexpr uintptr_t APPLY_SPEED      = 0x40;   // float RecoilApplySpeed
        // ═══ v148: ПОЛЯ КИКА (дамп 11920, класс RecoilConfig) ════════════
        // «Сайлент летит только в присяде» = игра добавляет кик отдачи
        // ПОВЕРХ нашей записи LookDirection (присядка режет кик → летит,
        // стоя кик большой → мимо). Нуль в конфиге = кик не рождается.
        constexpr uintptr_t MIN_RECOIL       = 0x18;   // Vector2 MinRecoil (v,h)
        constexpr uintptr_t MAX_RECOIL       = 0x20;   // Vector2 MaxRecoil (v,h)
        constexpr uintptr_t MIN_SIDE_DELTA   = 0x28;   // float MinSideDelta
        constexpr uintptr_t MAX_SIDE_DELTA   = 0x2C;   // float MaxSideDelta
        constexpr uintptr_t AIM_MULT         = 0x30;   // float RecoilAimMultiplier
    }
    // HitBox: size @0x24 / center @0x30 (Vector3) — BIG HEAD (v83)
    constexpr uintptr_t HB_SIZE             = 0x24;   // Vector3 size
    constexpr uintptr_t HB_CENTER           = 0x30;   // Vector3 center
    // ProtectionValues (ScriptableObject; GenericVitals.m_Protection @0x90):
    // amounts[] — защита по DamageType; density — плотность брони.
    namespace prot {
        constexpr uintptr_t DENSITY          = 0x18;   // float density
        constexpr uintptr_t AMOUNTS          = 0x20;   // float[] amounts
    }
    constexpr uintptr_t GV_PROTECTION       = 0x90;   // GenericVitals.m_Protection
    // EntityVitals — урон от падения (наших виталок): пороги скорости
    constexpr uintptr_t EV_MIN_FALL_SPEED   = 0xC0;   // float m_MinFallSpeed
    constexpr uintptr_t EV_MAX_FALL_SPEED   = 0xC4;   // float m_MaxFallSpeed
    // CharacterSpeedConfig — выносливость прыжков (v83)
    constexpr uintptr_t SPEEDCFG_JUMP_END_MAX  = 0x90;   // float JumpEnduranceMax
    constexpr uintptr_t SPEEDCFG_JUMP_END_COST = 0x94;   // float JumpEnduranceCostPerJump
    constexpr uintptr_t SPEEDCFG_JUMP_END_REGEN = 0x98;  // float JumpEnduranceRegenRate (v88: бхоп)
    constexpr uintptr_t SPEEDCFG_JUMP_END_RPAUSE = 0x9C; // float JumpEnduranceRegenPause (v89: пауза перед регеном — давит интервал прыжков)
    // v89: КАНДИДАТЫ на «текущую выносливость прыжка» (обфусцированные поля
    // KCC — дамп не даёт имён). [BHOP]-лог печатает их раз в 5с: какое-то из
    // них ПАДАЕТ после прыжка и РАСТЁТ на земле — это и есть пул.
    constexpr uintptr_t KCC_F_20C = 0x20C;   // float lqq
    constexpr uintptr_t KCC_F_210 = 0x210;   // float lqv
    constexpr uintptr_t KCC_F_224 = 0x224;   // float lqs
    constexpr uintptr_t KCC_F_228 = 0x228;   // float lqB
    constexpr uintptr_t MOTOR_F_27C = 0x27C; // int   ceE (мотор)
    constexpr uintptr_t MOTOR_F_284 = 0x284; // float cew (мотор)
    // ShaftedProjectile — добавка v83 (взрыв/пробитие, сверено 11914):
    namespace shaft2 {
        constexpr uintptr_t MAX_DAMAGE       = 0xC0;   // float m_MaxDamage
        constexpr uintptr_t EXPLOSION_DMG    = 0xD4;   // float explosionMaxDamage
        constexpr uintptr_t MIN_RADIUS       = 0xD8;   // float m_MinDamageRadius
        constexpr uintptr_t MAX_RADIUS       = 0xDC;   // float m_MaxDamageRadius
        constexpr uintptr_t PENETR_THR       = 0xE0;   // float m_PenetrationThreeshold
        constexpr uintptr_t PENETR_OFF       = 0xE4;   // float m_PenetrationOffset
        constexpr uintptr_t STOP_SPEED       = 0xF0;   // float m_StopSpeed
    }
    // FPBow: мгновенное натяжение (v83)
    constexpr uintptr_t FPB_AIM_SPEED       = 0x144;  // float aimSpeed
    constexpr uintptr_t FPB_AIM_POWER       = 0x148;  // float aimPower
    constexpr uintptr_t FPS_AIM_SPEED       = 0x14C;  // FPSnowball aimSpeed
    // FPRocketLauncher: m_RocketPrefab @0x148 (ShaftedProjectile)
    constexpr uintptr_t FPR_PREFAB          = 0x148;
    // ── v84: MEGAFIX (дамп 11914 пересверен; разбор живого лога v83) ────
    // KCC.decaySpeed @0xBC — скорость ЗАТУХАНИЯ коррекций (applySpeed@0xB8
    // уже гасился; затухание — вторая половина той же тяги).
    constexpr uintptr_t KCC_DECAY_SPEED      = 0xBC;   // float decaySpeed
    // Geg — РАНТАЙМ-ассист прицела (PlayerManager.<LWx> @0x238). Внутри —
    // AimSensorData (ИНЛАЙН-структура): Collider* @+0x0, Position @+0x18,
    // Direction @+0x24. Это ТОЧКА, к которой родной магнит тянет прицел:
    // пишем туда позицию ГОЛОВЫ цели (120 Гц) → прицел реально стоит на
    // голове → хедшоты НАСТОЯЩИЕ (сервер видит легальный хит в голову).
    // Дамп 11915: class Geg @336047 (poU AimTarget @0x60, pot AimSensorData
    // @0x68, poX AimTarget @0x98, poe AimSensorData @0xA0).
    // ═══ v94 ФИКС «магик булес не ворк»: в 11914 класс назывался zGH,
    // код ждал именно "zGH" → после апдейта 11915 (переименование zGH→Geg)
    // проверка класса валила магнит В ТИХУЮ. Теперь принимаем ОБА имени.
    // + ВТОРИЧНЫЙ сенсор: в 11914 Xas был @0x98, в 11915 там AimTarget poX,
    // а AimSensorData poe переехал на 0xA0 (писать в 0x98 = писать в чужой
    // AimTarget = мусор в памяти игры).
    constexpr uintptr_t PM_ASSIST_RUNTIME    = 0x238;  // Geg <LWx>k__BackingField
    namespace assist {                                  // Geg (11915) / zGH (11914)
        constexpr uintptr_t SENSOR_PRIMARY   = 0x68;   // AimSensorData pot/XaG (инлайн)
        constexpr uintptr_t SENSOR_SECONDARY = 0xA0;   // v94: AimSensorData poe @0xA0 (было 0x98 = AimTarget!)
        // поля AimSensorData (смещение ВНУТРИ структуры):
        constexpr uintptr_t ASD_COLLIDER     = 0x00;   // Collider* Collider
        constexpr uintptr_t ASD_POSITION     = 0x18;   // Vector3 Position — точка магнита
        constexpr uintptr_t ASD_DIRECTION    = 0x24;   // Vector3 Direction
        // v96.0: остальные поля Geg (дамп 11915, class Geg @336047)
        constexpr uintptr_t GEG_PM           = 0x10;   // readonly PlayerManager poG
        constexpr uintptr_t GEG_CONFIG       = 0x18;   // readonly AimAssistConfig poj
        constexpr uintptr_t GEG_CAMERA       = 0x28;   // Camera poo
        constexpr uintptr_t GEG_RAYCAST_HIT  = 0x30;   // RaycastHit pow
        constexpr uintptr_t GEG_AIM_TARGET_P = 0x60;   // AimTarget poU (первичный)
    }

    // ═══ v96.0: AimAssistConfig (ScriptableObject) — сила родного магнита ═
    // PM+0x180 aimAssistConfig / Geg.poj. Именно этот конфиг задаёт, КАК
    // БЫСТРО и В КАКОЙ ЗОНЕ ассист доводит прицел до цели-сенсора.
    namespace aac {                                     // AimAssistConfig
        constexpr uintptr_t DISTANCE     = 0x18;   // float distance — макс. дальность ассиста
        constexpr uintptr_t INNER_RECT   = 0x1C;   // Vector2 innerRectSize
        constexpr uintptr_t OUTER_RECT   = 0x24;   // Vector2 outerRectSize
        constexpr uintptr_t TIME_INC     = 0x2C;   // float timeIncreaseValue
        constexpr uintptr_t MOVE_INC     = 0x30;   // float moveIncreaseValue
        constexpr uintptr_t MOVE_DEC     = 0x34;   // float moveDecreaseValue
        constexpr uintptr_t OUTER_SPEED  = 0x38;   // float outerMaxSpeed
        constexpr uintptr_t INNER_SPEED  = 0x3C;   // float innerMaxSpeed
        constexpr uintptr_t OUTER_ABS    = 0x40;   // float outerMaxAbsoluteSpeed
        constexpr uintptr_t INNER_ABS    = 0x44;   // float innerMaxAbsoluteSpeed
        constexpr uintptr_t SWITCH_DELAY = 0x48;   // float targetSwitchDelay
    }

    // ═══ v96.0: FPHitscan (оружие) — трейсер/конфиг/разброс ═══════════════
    // class FPHitscan : FPWeaponBase @407873 (дамп 11920).
    // v108 ПАТЧ 11915 → 11920: поля после 0x124 уехали на +8 —
    // ЭТО БЫЛ КОРЕНЬ «ТРЕЙСЕРЫ ПРОПАЛИ»: старые RECOIL_LASTH/LASTDIR
    // (0x208/0x20C) читали _weaponConfig-указатель инлайн-структуры
    // WeaponRecoil — старший dword = 0x7A = 122 = константа → поля
    // «не меняются» → 0 выстрелов → трейсеры/хит-звуки стояли (лог:
    // lastH=-0.000 lastDir=122).
    namespace hs {
        constexpr uintptr_t SIGNAL_PROJ  = 0x128;  // FlareSignalProjectile signalProjectile (новое 11920)
        constexpr uintptr_t CONFIG        = 0x130;  // HitscanWeaponConfig config (было 0x128)
        constexpr uintptr_t FIRE_MODE     = 0x138;  // bJr.FireMode m_FireMode
        constexpr uintptr_t MIN_AIM_FIRE  = 0x13C;  // float m_MinAimValueToFire
        constexpr uintptr_t MUZZLE_FLASH  = 0x178;  // ParticleSystem m_MuzzleFlash (было 0x170)
        constexpr uintptr_t TRACER        = 0x180;  // BulletProjectile m_Tracer (было 0x178)
        constexpr uintptr_t SPAWN_TRACER  = 0x188;  // bool spawnTracer — ИГРА САМА РИСУЕТ ТРЕЙСЕР (было 0x180)
        constexpr uintptr_t TRACER_OFFSET = 0x18C;  // Vector3 m_TracerOffset (было 0x184)
        constexpr uintptr_t WEAPON_ROOT   = 0x1B0;  // Transform m_WeaponRoot (было 0x1A8)
        constexpr uintptr_t RECOIL        = 0x200;  // struct WeaponRecoil KIr (инлайн; было 0x1F8)
        constexpr uintptr_t RECOIL_LASTH  = 0x210;  // WeaponRecoil._lastHorizontal (float) — меняется НА ВЫСТРЕЛ (было 0x208)
        constexpr uintptr_t RECOIL_LASTDIR= 0x214;  // WeaponRecoil._lastDirection (int ±1) (было 0x20C)
        // v108: CAND-кандидаты v96 НЕ АКТУАЛЬНЫ в 11920 (детектор v4 их
        // не использует; семантика новых полей KIJ/KIL/KIH/KIX/KIs/KIY
        // не калибровалась — при нужде сверять по dump @407905).
        constexpr uintptr_t CAND_P1       = 0x224;  // float KIH
        constexpr uintptr_t CAND_P2       = 0x228;  // float KIX
        constexpr uintptr_t CAND_I1       = 0x230;  // int KIs
        constexpr uintptr_t CAND_I2       = 0x238;  // int KIY
        constexpr uintptr_t CAND_I3       = 0x244;  // KIf хвост
        constexpr uintptr_t CAND_I4       = 0x24C;  // KIT-зона
        constexpr uintptr_t CAND_F3       = 0x250;  // KIv
    }

    // ═══ v96.0: HitscanWeaponConfig — честная баллистика для предикшна ═══
    namespace hwc {
        constexpr uintptr_t DAMAGE       = 0x18;   // float damage
        constexpr uintptr_t MAX_DIST     = 0x2C;   // float MaxDistance
        constexpr uintptr_t BULLET_SPEED = 0x30;   // float BulletSpeed — РЕАЛЬНАЯ скорость пули
        constexpr uintptr_t FIRE_RATE    = 0x34;   // float fireRate
        constexpr uintptr_t SHOTS_PER    = 0x38;   // int projectilesPerShot
        constexpr uintptr_t BASE_DISP    = 0x3C;   // float BaseDispersion
        constexpr uintptr_t MISFIRE      = 0x54;   // float misfireChance (v137: → 0)
        constexpr uintptr_t DISPERSION   = 0x60;   // DispersionConfig dispersionConfig
        constexpr uintptr_t RECOIL_CFG   = 0x68;   // RecoilConfig recoilConfig
    }

    // ═══ v96.0: DispersionConfig — разброс (для NO SPREAD) ═══════════════
    namespace disp {
        constexpr uintptr_t MIN_FIRE     = 0x18;   // float minFireDispersion
        constexpr uintptr_t MAX_FIRE     = 0x1C;   // float maxFireDispersion
        constexpr uintptr_t MIN_DISP     = 0x20;   // float minDispersion
        constexpr uintptr_t MAX_DISP     = 0x24;   // float maxDispersion
        constexpr uintptr_t INC_PER_SHOT = 0x28;   // float dispersionIncreasePerShot
    }

    // ═══ v137: DLP2 — цепи LookDirection (фаер-низ CDD 11920) ═════════════
    // CDD (RVA 0x6561E24, дизасм v134) читает [this+0xC8]→brc, затем
    // [brc+0x140]→brI, направление: brI+0x20 (x) / +0x24 (y) / +0x28 (z).
    // ТРИ маршрута до brc (дедуп): [pm+0x78], [[pm+0x90]+0x40],
    // [[[pm+0x90]+0x50]+0xC8]. Запись 12Б подряд @brI+0x20.
    namespace dlp2 {
        constexpr uintptr_t PM_FIRE_COMP        = 0x78;   // [pm+0x78] → brc (маршрут 1)
        constexpr uintptr_t PM_FP_MANAGER       = 0x90;   // [pm+0x90] → FPManager
        constexpr uintptr_t FPMGR_BRC           = 0x40;   // [fpMgr+0x40] → brc (маршрут 2)
        constexpr uintptr_t FPMGR_WEAPON        = 0x50;   // [fpMgr+0x50] → оружие (маршрут 3)
        constexpr uintptr_t WEAPON_BRC          = 0xC8;   // [weapon+0xC8] → brc (маршрут 3, = CDD this)
        constexpr uintptr_t BRC_LOOKDIR         = 0x140;  // [brc+0x140] → brI
        constexpr uintptr_t BRC_MANAGER         = 0x0D0;  // brc.manager → PlayerManager (обратный гард, v147)
        constexpr uintptr_t BRI_XYZ             = 0x20;   // Vector3 LookDirection (x/y/z подряд, 12Б)
        // окно/такт DLP2 (v134-v136, юзером подтверждено):
        // v139: «не все пули попадают — некоторые летят по центру» (репорт).
        // Физика гонки: игру перезаписывает MouseLook каждый кадр, окно
        // протечки = такт райтера (после записи игры поле наше только
        // через ≤TICK_US). 300мкс давало ~3-4% протечек; 200мкс база +
        // ХОТ 70мкс при спрее (выстрел < 280мс назад) сжимают протечку
        // до <1% (менее 1 пули на 100-200). probe v138=100% — смещённая
        // выборка (читается сразу после НАШЕЙ записи), потому и не видел.
        constexpr uint32_t  TICK_US             = 200;    // калибр райтера (обычный холд)
        constexpr uint32_t  HOT_US              = 70;     // v139: такт при спрее
        constexpr uint32_t  HOT_AFTER_MS        = 280;    // v139: «спрей» = выстрел < N мс назад
        constexpr uint32_t  WINDOW_ACTIVE_MS    = 600;    // окно продлевается публикацией
        constexpr uint32_t  GRACE_MS            = 60;     // грейс после снятия цели
        constexpr float     PROBE_OURS_DEG      = 1.8f;   // порог «полё наше»
        // FPS-анлок: icall-кэш слоты Application.get/set_targetFrameRate
        // (дизасм v137: шимы резолвят нативную имплементацию через GOT-слот
        // в .bss libil2cpp; после первого вызова игры там лежит указатель).
        constexpr uintptr_t ICALL_GET_TFR_SLOT  = 0x1A534BD0;
        constexpr uintptr_t ICALL_SET_TFR_SLOT  = 0x1A534BD8;
        constexpr uintptr_t SHIM_SET_TFR_RVA    = 0xC7D15AC; // фингерпринт шима
        constexpr uintptr_t EXEC_SEG_FILE_OFF   = 0x4F9D8D0; // R E LOAD: off→vaddr +0x8000 (файл-смещение сегмента для base= rowStart - off)
    }

    // ═══ v96.0: ВИДИМОСТЬ — серверная подписка (interest management) ═════
    // PM+0x158 playerNetworkSubscriptionController : qA : NetworkBehaviour.
    // isSubscribedSync — SyncVar: сервер говорит, получаем ли мы обновления
    // этого игрока (в зоне интереса = «сервер его нам рисует»).
    constexpr uintptr_t PM_SUBSCRIPTION     = 0x158;  // qA playerNetworkSubscriptionController
    namespace sub {
        constexpr uintptr_t IS_SUBSCRIBED   = 0x68;  // bool isSubscribedSync
        constexpr uintptr_t IS_PLUS         = 0x69;  // bool isPlusSubscribedSync
    }
    // v85: FPWeaponBase.useAimAssist (public bool) — ГЛАВНЫЙ выключатель
    // нативного aim-ассиста; без true игра игнорирует AimAssistConfig/zGH.
    constexpr uintptr_t FPWB_USE_AIM_ASSIST  = 0xF8;  // bool useAimAssist
    // FPManager+0x58 → активный FPWeaponBase (фолбэк +0x50 _currentWeapon).
    constexpr uintptr_t HELD_FP_WEAPON       = 0x58;
    // FPObject.<ZYx>k__BackingField → Item (активный предмет во стволе).
    constexpr uintptr_t FPOBJ_ITEM           = 0x40;
    // PlayerInventory._playerInventoryClient (RkO, NetworkBehaviour).
    constexpr uintptr_t INV_CLIENT           = 0x28;
    // RkO.Cells : List<Rky> — ячейки инвентаря.
    constexpr uintptr_t INV_CELLS            = 0x80;
    // Rky.<ZXy>k__BackingField → Item (ячейка → предмет).
    constexpr uintptr_t CELL_ITEM            = 0x10;

    // ─── NetworkBehaviour / Mirror (для netId) ──────────────────────────────
    constexpr uintptr_t NET_IDENTITY         = 0x40;  // NetworkBehaviour.netIdentity

    // ═══ v85: КРУТЕЛКА (свободная камера) ══════════════════════════════════
    // PlayerManager.mouseLook @0x70 → MouseLook (лэйаут #1 @44107,
    // подтверждён заметками v59: Quaternion @0x48). Патчим:
    //   _clampPitch @0x38 (bool) → 0 — кламп вертикали выключен;
    //   _minPitchAngle @0x3C → -179, _maxPitchAngle @0x40 → +179
    //   (дубль-страховка). Итог: камера крутится без ограничений.
    constexpr uintptr_t MOUSE_CLAMP_PITCH    = 0x38;  // bool _clampPitch
    constexpr uintptr_t NET_ID               = 0x58;  // NetworkIdentity.<netId>k__BackingField

    // ─── MouseLook (PM+0x70): вектор взгляда pitch/yaw ───────────────────
    // 1.13.11905: <usD> → <Qiv>, оффсет тот же 0x88.
    // Лог v37: у ПРОТУХШЕГО PM этот Vector2 замирает (29с при вращающем
    // юзере) — по нему PlayerCache детектит мёртвый адрес локала.
    constexpr uintptr_t MOUSE_LOOK_ANGLES    = 0x88;  // Vector2 <Qiv>k__BackingField

    // ─── v59: Oxide_MouseLook / PlayerManager — цели memory-аима ──────────
    // dump 1.13.11910 Oxide_MouseLook: m_Sensitivity@0x34, Zay(Vector2)@0x4C,
    // ZaO(Vector2)@0x70, <ZvT>k__BackingField(Vector2)@0x88.
    // PlayerManager: ZhD (private float)@0x1A4, lookAngle (yaw)@0x1A8.
    // Лог v58: ZvT@0x88 МЁРТВ (углы стоят при живой камере), lookAngle@0x1A8
    // живой (совпадает с камерой). v59 пишет весь комплекс + верификацию.
    constexpr uintptr_t MOUSE_SENSITIVITY    = 0x34;  // float m_Sensitivity
    constexpr uintptr_t MOUSE_LOOK_ZAY       = 0x4C;  // Vector2 Zay (абс. углы?)
    constexpr uintptr_t MOUSE_LOOK_ZAO       = 0x70;  // Vector2 ZaO (дельта-вход?)
    constexpr uintptr_t LOOK_PITCH           = 0x1A4; // float ZhD (гипотеза pitch)

    // ─── wK nicklabel (PM+0x130) → имя/тима ────────────────────────────────
    constexpr uintptr_t NICKLABEL_NICKNAME   = 0x38;  // UnityEngine.UI.Text nickname
    constexpr uintptr_t NICKLABEL_FRIEND     = 0x90;  // bool isFriend
    constexpr uintptr_t NICKLABEL_TEAMMATE   = 0x91;  // bool isTeammate
    // v96.2 ФИКС «мусорное имя '\uFFFDAn' в [BULLET]»: v96.1 ставил 0xD8,
    // пересчитав поля через «+0x10» вручную — НО offset'ы в dump.cs уже
    // АБСОЛЮТНЫЕ (включают 0x10-заголовок объекта; так же читаются PM-поля).
    // Прямая цитата dump 11915 (public class Text : MaskableGraphic):
    //   private FontData m_FontData;      // 0xD8   ← читали ЭТО как строку
    //   protected string m_Text;          // 0xE0   ← НАСТОЯЩЕЕ имя
    //   private TextGenerator m_TextCache;// 0xE8   ← источник «цифр букв» v96.0
    constexpr uintptr_t UI_TEXT_TEXT         = 0xE0;  // Text.m_Text (string)
    constexpr uintptr_t NICKLABEL_PLAYER_ID  = 0x40;  // oh.playerId : Text (цифровой ID — фолбэк имени)

    // ─── v15: KCC / CharacterMovement (CMF) — РЕАЛЬНАЯ ПОЗИЦИЯ ПЕРСОНАЖА ───
    // PM+0xB0 kccReference : InterfaceReference<fs> (fs = интерфейс KCC).
    // v80 КОРЕНЬ-ФИКС: в дампе поля обёртки показаны как 0x0 (Il2CppDumper
    // не резолвит layout этого класса). РАНТАЙМ-диагностика PlayerCache
    // ([KCC] comp=... mine=1 — позиции сходятся с глазом) читает КОМПОНЕНТ
    // по kref+0x10. v79 ошибочно брал +0x20 → мусор → класс "KCC" не
    // совпадал → СПИД/ПРЫЖОК МОЛЧА НЕ ПРИМЕНЯЛИСЬ. Основной путь — 0x10,
    // остальные — фолбэк-пробы с проверкой класс-имени и back-pointer
    // KCC.player@0x78 == локал.
    constexpr uintptr_t KCC_REF_PRIMARY      = 0x10;  // InterfaceReference._component (v80)
    constexpr uintptr_t KCC_REF_COMPONENT    = 0x20;  // ЛЕГАСИ: фолбэк-проба
    constexpr uintptr_t BCC_CHAR_MOVEMENT    = 0x100; // <nIt>k__BackingField (сверено 11910)

    namespace cm {
        constexpr uintptr_t TRANSIENT_POSITION = 0x58;  // Vector3 BeU (11905: nvQ)
        constexpr uintptr_t TRANSIENT_VELOCITY = 0x74;  // Vector3 Beg (11905: nvo)
        constexpr uintptr_t TRANSIENT_ROTATION = 0x80;  // BeJ (11905: nvT; в 11910 тип аннотирован Vector3)
        constexpr uintptr_t VEL_BK             = 0x9C;  // <BeW>k__BackingField (11905: nva)
        constexpr uintptr_t POS_BK             = 0xA8;  // <Bes>k__BackingField (11905: nvL)
    }

    // ─── v17: KinematicCharacterMotor (ассет KinematicCharacterController) ──
    // v15/v16 ошиблись классом: transientPosition искали в CharacterMovement
    // (CMF), но comp за kccReference — это KCC ИГРЫ (HyperHug...Features.Player,
    // наследник NetworkBehaviour, реализует интерфейс My). Поля KCC выше
    // (namespace kcc). KinematicCharacterMotor — компонент НА ТОМ ЖЕ объекте
    // персонажа, кэширует живое состояние симуляции (каждый тик, лок+удалённые):
    namespace kccm {
        constexpr uintptr_t BASE_TRANSFORM      = 0x118; // Transform WNf (корень персонажа!; 11905: VFj)
        constexpr uintptr_t TRANSIENT_POSITION  = 0x120; // Vector3 WNa — _transientPosition (11905: VFp)
        constexpr uintptr_t TRANSIENT_INIT_POS  = 0x12C; // Vector3 WNv (11905: VFF)
        // v86: cXs @0x15C — ЕДИНСТВЕННЫЙ Quaternion transient-блока =
        // _transientRotation (источник YRotation в исходящем Move → крутилка).
        constexpr uintptr_t TRANSIENT_ROTATION  = 0x15C; // Quaternion cXs (11914)
        constexpr uintptr_t CONTROLLER          = 0x1D0; // RxI CharacterController (11905: DPx)
        constexpr uintptr_t INITIAL_TICK_POS    = 0x1E0; // Vector3
        constexpr uintptr_t LAST_INTERP_POS     = 0x1EC; // Vector3 — интерполированная (рендер)
        constexpr uintptr_t BASE_VELOCITY       = 0x210; // Vector3
    }

    // ─── PlayerVitals → GenericVitals (PM+0xC8) ──────────────────────────
    constexpr uintptr_t GENERIC_VITALS_CURRENT = 0xB8; // protected float Zvr (current HP; 11905: Qiw) — сверно 11910

    // ─── aO<PM> (activePlayerList) → cz<G> внутренний контейнер ══ v39 ══
    // 1.13.11905: класс KA существует (generic-поля по-прежнему неразрешённые
    // в дампе, оффсеты 0x0) — разбор контейнера ненадёжен, основной источник
    // списка = clientPlayerList (List<PM>) и GCB-статик <QCF>.
    // Оффсеты ниже оставлены как фолбэк (эмпирика 11895).
    constexpr uintptr_t A0_CZ                = 0x20;  // KA.RXd : jy<n> (было aO.zHb : cz<G>)
    constexpr uintptr_t CZ_COUNT             = 0x10;  // jy.zZi : int
    constexpr uintptr_t CZ_ITEMS             = 0x18;  // jy.zZj : G[]

    // ─── GameControllerBase statics (локальный игрок/камера) ══ v39 ══════
    // 11910: <ZCf> (PlayerManager, LOCAL), <ZCM> (CameraManager) —
    // оффсеты статиков не изменились (сверено v57 по дампу 11910).
    constexpr uintptr_t GCB_LOCAL_PLAYER     = 0x10;  // <ZCf> PlayerManager = LOCAL
    constexpr uintptr_t GCB_CAMERA_MANAGER   = 0x38;  // <ZCM> CameraManager
    constexpr uintptr_t CAMMGR_CAMERA        = 0x20;  // CameraManager.m_Camera

    // ─── FPManager (PM+0x90) — кандидаты на текущий FOV ══ v39 ══════════
    // 11910: <ZYn>/<ZYe>/<ZYI> (11905: <Qjn>/<Qjf>/<QjM>), оффсеты те же.
    constexpr uintptr_t FP_FOV_A             = 0xA4;  // <ZYn>k__BackingField
    constexpr uintptr_t FP_FOV_B             = 0xA8;  // <ZYe>k__BackingField
    constexpr uintptr_t FP_FOV_C             = 0xAC;  // <ZYI>k__BackingField

    // ============================================================
    // Смещения для скелета
    // ============================================================
    constexpr uintptr_t PLAYERMODEL_BONE_TRANSFORMS = 0x20;
    constexpr uintptr_t PLAYERMODEL_BONE_COUNT      = 0x24;
}

namespace entity {

    // 11910: класс RHR (11905: DqD), Entity=RHA @0x68 — сверно 1:1 (v57).
    constexpr uintptr_t ENTITY_PTR           = 0x68;
    constexpr uintptr_t BOUNDS               = 0x70;

    constexpr uintptr_t DISPLAY_NAME         = 0x88;
    constexpr uintptr_t KILL_EXP             = 0x90;
    constexpr uintptr_t HEALTH               = 0x98;
    constexpr uintptr_t CHANGE_HEALTH        = 0xA0;
    constexpr uintptr_t IS_GROUNDED          = 0xA8;
    constexpr uintptr_t VELOCITY             = 0xB0;
    constexpr uintptr_t LAND                 = 0xB8;
    constexpr uintptr_t DEATH                = 0xC0;
    constexpr uintptr_t RESPAWN              = 0xC8;

    constexpr uintptr_t NZB_VALUE_OFFSET     = 0x0;
    constexpr size_t    NZB_VALUE_SIZE       = 4;

    constexpr uintptr_t NZH_VALUE_OFFSET     = 0x0;
    constexpr size_t    NZH_VALUE_SIZE       = 12;

    constexpr uintptr_t GENERIC_VITALS_MAX_HEALTH = 0x88;  // float m_MaxHealth
    constexpr uintptr_t GENERIC_VITALS_PROTECTION = 0x90;
    constexpr uintptr_t VITALS_ENTITY_PTR    = 0xF8;
}

// ═══ v79: предметная цепочка (дамп 11910, сверно) ═══════════════════════════
// Item → ItemData → id/shortname. Раньше тут читали «инвентарь+0x20 как belt»
// — по факту это был PlayerInventoryData/клиент, а id брали из байтов указателя.
namespace invitem {
    constexpr uintptr_t ITEM_ITEMDATA        = 0x20;  // Item.<ZPZ> ItemData* (ScriptableObject)
    constexpr uintptr_t ITEMDATA_ID          = 0x58;  // ItemData.m_Id : int
    constexpr uintptr_t ITEMDATA_SHORTNAME   = 0x20;  // ItemData.m_ShortName : string
    constexpr uintptr_t ITEMDATA_GROUP       = 0x30;  // ItemData.group : ItemGroupType
    // v84: Item.<KQH>k__BackingField int — кол-во в стэке (конструктор
    // Item(ItemData, int currentInStack, …) — сверен по dump.cs 11914).
    // Гранаты: заморозка счётца = бесконечные броски.
    constexpr uintptr_t ITEM_STACK_COUNT     = 0x30;  // int currentInStack
}

namespace sleeper {
    // ─── v39: класс DisconnectedSleeper, сверно с dump.cs 1.13.11910 (v57) ──
    // Раскладка с 11905 НЕ изменилась (sleeper-поля 1:1).
    constexpr uintptr_t ANIMATOR             = 0x68;
    constexpr uintptr_t NICK_LABEL           = 0x70;
    constexpr uintptr_t DISPLAY_NAME_PROVIDER = 0x78;
    constexpr uintptr_t PLAYER_MODEL_INFO    = 0x80;
    constexpr uintptr_t ENTITY_EVENT_HANDLER = 0x88;
    constexpr uintptr_t VITALS               = 0x90;
    constexpr uintptr_t BACKPACK_PREFAB      = 0x98;
    constexpr uintptr_t HIT_BOX              = 0xA0;
    constexpr uintptr_t BODY_COLLIDER        = 0xA8;
    constexpr uintptr_t KCC_COLLIDER         = 0xB0;
    constexpr uintptr_t SPAWN_POINT          = 0xB8;
    constexpr uintptr_t SERVER_COLLIDER      = 0xC0;
    constexpr uintptr_t RIGIDBODY            = 0xC8;
    constexpr uintptr_t MODEL_TRANSFORM      = 0xD8;
    constexpr uintptr_t MIN_OFFSET           = 0xE0;
    constexpr uintptr_t FREE_OFFSET          = 0xEC;
    constexpr uintptr_t LOOT_OBJECT          = 0xF8;
    constexpr uintptr_t SPEED_CONFIG         = 0x100;
    constexpr uintptr_t SNORING_SOURCE       = 0x108; // AudioSource _snoringSource (введено в 11905)
    constexpr uintptr_t USER_ID              = 0x110; 
    constexpr uintptr_t NICK                 = 0x118; 
    constexpr uintptr_t IS_IMMORTAL          = 0x120; 
    constexpr uintptr_t HEALTH               = 0x124; 
    constexpr uintptr_t IS_STABLE            = 0x128; 
    constexpr uintptr_t HAS_SPACE            = 0x129; 
    constexpr uintptr_t CLAN_ID              = 0x130; 
    constexpr uintptr_t CLAN_TAG             = 0x138; 
    constexpr uintptr_t SLEEPER_EQUIP        = 0x140; // SyncList<EquipPiece>
}

namespace model {
    constexpr uintptr_t HEAD                 = 0x20;
    constexpr uintptr_t RIGHT_WEAPON_HOLDER  = 0x28;
    constexpr uintptr_t LEFT_WEAPON_HOLDER   = 0x30;
    constexpr uintptr_t EQUIPMENT_HOLDER     = 0x38;
    constexpr uintptr_t BODY                 = 0x40;
    constexpr uintptr_t HEAD_MODEL           = 0x48;
    constexpr uintptr_t SKINNED_RENDERER     = 0x50;
    constexpr uintptr_t HEAD_RENDERER        = 0x58;
    constexpr uintptr_t CHARACTER_ANIMATION  = 0x60;

    constexpr uintptr_t FP_ANIMATOR          = 0x20;
    constexpr uintptr_t FP_EQUIPMENT_HOLDER  = 0x28;
    constexpr uintptr_t FP_SKINNED_RENDERER  = 0x30;
}

namespace kcc {
    constexpr uintptr_t MOTOR                = 0x68;
    constexpr uintptr_t HIT_BOX_RECORDER     = 0x70;
    constexpr uintptr_t PLAYER               = 0x78;
    constexpr uintptr_t SPEED_CONFIG         = 0x80;
    constexpr uintptr_t HEAD                 = 0x88;
    constexpr uintptr_t LOOK_HEIGHT_OFFSET   = 0x90;
    constexpr uintptr_t NORMAL_HEIGHT        = 0xA0;
    constexpr uintptr_t CROUCH_HEIGHT        = 0xA4;
    // v17: туториальный вариант SingleKcc (тот же My, другой лейаут)
    constexpr uintptr_t SKCC_MOTOR           = 0x70;  // <Motor>k__BackingField
    constexpr uintptr_t SKCC_PLAYER          = 0x80;  // player (PlayerManager)
    constexpr uintptr_t SKCC_HEAD            = 0x90;  // head (Transform)
}

// ─── v18: HitBoxRecorderRoot / HitBox — АНИМИРОВАННЫЕ хитбоксы (скелет) ─────
// KCC (comp) @0x70 → HitBoxRecorderRoot : NetworkBehaviour:
//   protected HitBox[] hitBoxes @0x68.
// HitBox : MonoBehaviour (на GO кости!): Collider m_Collider @0x50,
//   HitArea m_HitArea @0x68 (All=0, Head=1, Chest=2, Leg=3, Foot=4, Hand=5),
//   int id @0x6C, Bounds LSm @0x88 (фолбэк: возможные мировые bounds).
// Коллайдеры следуют за анимацией → скелет повторяет присед/бег.
namespace hitbox {
    // 1.13.11905: сверно по HitBoxRecorderRoot / HitBox — БЕЗ СДВИГОВ.
    // v81: сверено по HitBox @dump.cs:393450 (11910) — без сдвигов.
    constexpr uintptr_t HBREC_ARRAY          = 0x68;  // HitBox[] hitBoxes
    constexpr uintptr_t HB_DMG_MULT          = 0x20;  // float m_DamageMultiplier (v81)
    constexpr uintptr_t HB_COLLIDER          = 0x50;  // Collider m_Collider
    constexpr uintptr_t HB_AREA              = 0x68;  // HitArea m_HitArea
    constexpr uintptr_t HB_ID                = 0x6C;  // int id
    constexpr uintptr_t HB_BOUNDS            = 0x88;  // Bounds Zqu (11905: LSm) (center)
}

// ═══ v108: СЕРВЕРНАЯ ИСТОРИЯ ХИТБОКСОВ — анимированный скелет ═══════════
// Сверено по dump.cs 11920: HitBoxRecorderRoot @195293, vP @195146,
// Capture3DRotated @195272, KCC @188100 (player@0x78 — гвард жив).
// HitBoxRecorderRoot : NetworkBehaviour — РЕПЛИЦИРУЕТСЯ на клиент:
//   KCC.hitBoxRecorderRoot @0x70 → root
//   root.oge[] @0x98 : vP[] (по одному на HitBox, кольцевая история)
//   vP.oVk @0x10 : HitBox (→ m_HitArea @0x68 — тип точки)
//   vP.oVi @0x20 : Capture3DRotated[] (Position @0x0 = МИРОВАЯ точка!)
// Решает «скелет не анимированый» без transform-цепей (NT мертвы).
namespace hbr {                                        // HitBoxRecorderRoot
    constexpr uintptr_t ROOT_HITBOXES   = 0x68;        // HitBox[] hitBoxes
    constexpr uintptr_t ROOT_HISTORY    = 0x98;        // vP[] oge
}
namespace hbp {                                        // vP (история хитбокса)
    constexpr uintptr_t P_HITBOX        = 0x10;        // HitBox oVk
    constexpr uintptr_t P_CAPTURES      = 0x20;        // Capture3DRotated[] oVi
    constexpr uintptr_t P_HEAD          = 0x28;        // int oVF
    constexpr uintptr_t P_TAIL          = 0x2C;        // int ogq
}
namespace cap {                                        // Capture3DRotated
    constexpr size_t     CAP_STRIDE     = 0x40;         // sizeof (выравн. до 8)
    constexpr uintptr_t  C_POSITION     = 0x00;         // Vector3 Position (МИР!)
    constexpr uintptr_t  C_ROTATION     = 0x0C;         // Quaternion Rotation
    constexpr uintptr_t  C_REMOTETIME   = 0x20;         // double RemoteTime
    constexpr uintptr_t  C_HEIGHT       = 0x2C;         // float Height
    constexpr uintptr_t  C_CENTER       = 0x30;         // Vector3 Center
}
constexpr uintptr_t KCC_HITBOX_REC       = 0x70;       // KCC.hitBoxRecorderRoot

namespace camera {
    // FPManager offsets (из дампа)
    constexpr uintptr_t WORLD_CAMERA         = 0x20;  // public Camera m_WorldCamera ← КЛЮЧЕВОЙ для view matrix
    constexpr uintptr_t FP_RENDER_CONTROLLER = 0x28;
    constexpr uintptr_t FOV_SET_SPEED        = 0x30;
    constexpr uintptr_t AIM_SPEED_MULTIPLIER = 0x34;
    constexpr uintptr_t WEAPON_MANAGER       = 0x38;
    constexpr uintptr_t EVENT_HANDLER        = 0x40;
    constexpr uintptr_t RAYCAST_MANAGER      = 0x48;
    constexpr uintptr_t CURRENT_WEAPON       = 0x50;  // FPObject _currentWeapon
    constexpr uintptr_t FP_WEAPON_BASE       = 0x58;  // FPWeaponBase ZMO (11905: TME)

    // FPManager методы (для hook'а и invoke) — RVAs 1.13.11910 (сверены):
    constexpr uintptr_t RVA_AWAKE            = 0x63d7578;   // private void Awake()
    constexpr uintptr_t RVA_LATE_UPDATE       = 0x63dd90c;   // private void LateUpdate()
    // public Vector2 UjM() — возвращает текущий lookAngle (yaw/pitch) (11905: cGm())
    constexpr uintptr_t RVA_GET_LOOK         = 0x63d8700;
    // public void UjY(Vector2) — устанавливает lookAngle (11905: cGK())
    constexpr uintptr_t RVA_SET_LOOK         = 0x63d8c60;

    // MouseLook (TypeDef 801) — сверно 11910, БЕЗ СДВИГОВ:
    // _lateralSensitivity 0x28, _verticalSensitivity 0x2C, _smoothTime 0x34,
    // _minPitchAngle 0x3C, _maxPitchAngle 0x40, BeM (Quaternion; 11905: nvX) 0x48.
    constexpr uintptr_t MOUSE_LATERAL_SENS   = 0x28;
    constexpr uintptr_t MOUSE_VERTICAL_SENS  = 0x2C;
    constexpr uintptr_t MOUSE_SMOOTH_TIME    = 0x34;
    constexpr uintptr_t MOUSE_MIN_PITCH      = 0x3C;
    constexpr uintptr_t MOUSE_MAX_PITCH      = 0x40;
    constexpr uintptr_t MOUSE_CURRENT_QUAT   = 0x48;
}

// ─── UnityEngine.Camera (внутренние смещения для матриц) ─────────────────────
// В Unity 2022+ il2cpp Camera имеет кэшированные матрицы:
//   worldToCameraMatrix (~0xDC) — но точное смещение зависит от версии движка
// Лучший способ — вызвать get_main() и затем get_worldToCameraMatrix() через
// il2cpp_runtime_invoke. Здесь — заглушки для прямого чтения (проверь в dump.cs
// класс Camera если нужны точные смещения).
namespace unity_camera {
    constexpr uintptr_t TRANSFORM             = 0x1C;   // Transform (для позиции)
    constexpr uintptr_t PROJECTION_MATRIX     = 0xDC;   // Matrix4x4 (16 float) — TODO verify
    constexpr uintptr_t WORLD_TO_CAMERA_MATRIX = 0x11C; // Matrix4x4 (16 float) — TODO verify
    constexpr uintptr_t PIXEL_RECT           = 0x130;   // Rect (x,y,w,h)
    constexpr uintptr_t FIELD_OF_VIEW        = 0x58;    // float
}

// ─── BulletProjectile (для aimbot bullet prediction) ─────────────────────────
namespace bullet {
    // Поля (из дампа 1.13.11910, класс BulletProjectile) — БЕЗ СДВИГОВ.
    // 11910: nw*→Bt*. ВНИМАНИЕ: 0x68 = TrailRenderer[] (в 11904 ошибочно помечен как float SPEED_FACTOR).
    constexpr uintptr_t SLOWDOWN             = 0x20;   // float slowdown
    constexpr uintptr_t MIN_SPEED            = 0x24;   // float minSpeed
    constexpr uintptr_t LINE_RENDERER        = 0x28;
    constexpr uintptr_t TRACE_SIZE           = 0x30;
    constexpr uintptr_t TRACE_FACTOR         = 0x34;
    constexpr uintptr_t MIN_WIDTH            = 0x38;
    constexpr uintptr_t MAX_WIDTH            = 0x3c;
    constexpr uintptr_t CXV                  = 0x40;   // private float Bte (11905: nwn)
    constexpr uintptr_t CXA                  = 0x44;   // private float BtI (11905: nwf)
    constexpr uintptr_t CXN                  = 0x48;   // Vector3 Btb (стартовая позиция?; 11905: nwM)
    constexpr uintptr_t CXA_VEC              = 0x54;   // Vector3 BtU (стартовая дельта?; 11905: nwk)
    constexpr uintptr_t CXV_INT              = 0x60;   // int Btl (11905: nwy)
    constexpr uintptr_t CXD_FLOAT            = 0x64;   // float BtD (11905: nwQ)
    constexpr uintptr_t NWV_TRAILS         = 0x68;   // TrailRenderer[] Btm (11905: nwV)
    constexpr uintptr_t CZL                  = 0x70;   // float BtB (11905: nwu)
    constexpr uintptr_t CURRENT_POSITION     = 0x74;   // Vector3 Btg (текущая позиция пули; 11905: nwq)
    constexpr uintptr_t IS_ACTIVE           = 0x80;   // bool BtJ (активна ли пуля; 11905: nwl)
    constexpr uintptr_t HIT_BOX              = 0x88;   // Transform BtV (цель; 11905: nwo)
    constexpr uintptr_t DESTINATION         = 0x90;   // Vector3 BtE (куда летит; 11905: nwT)
    constexpr uintptr_t VELOCITY             = 0x9C;   // Vector3 BtZ (текущая скорость; 11905: nwN)
    constexpr uintptr_t ACCELERATION         = 0xA8;   // Vector3 BtW (ускорение; 11905: nwZ)

    // Методы (для hook'а SilentAim) — RVAs 1.13.11910 (сверены):
    constexpr uintptr_t RVA_FIRE             = 0x707644c;  // public void Fire(start, rotation, destination, speed, hitBox, acceleration)
    constexpr uintptr_t RVA_MOVE             = 0x7075f48;  // private void Move(float deltaTime)
    constexpr uintptr_t RVA_LATE_UPDATE      = 0x7075f04;  // private void LateUpdate() [bullet]
    constexpr uintptr_t RVA_INITIALIZE       = 0x7075d04;  // private Vector3 Ix() (11905: rCw(); кандидат по порядку)
}

// ─── PlayerModelInfo (для skeleton ESP) ────────────────────────────────────────
namespace model_info {
    // Поля (из дампа 1.13.11910) — БЕЗ СДВИГОВ:
    constexpr uintptr_t HEAD                 = 0x20;   // Transform
    constexpr uintptr_t RIGHT_WEAPON_HOLDER  = 0x28;
    constexpr uintptr_t LEFT_WEAPON_HOLDER   = 0x30;
    constexpr uintptr_t EQUIPMENT_HOLDER     = 0x38;
    constexpr uintptr_t BODY                 = 0x40;   // Transform (центр тела)
    constexpr uintptr_t HEAD_MODEL           = 0x48;
    constexpr uintptr_t SKINNED_RENDERER     = 0x50;
    constexpr uintptr_t HEAD_RENDERER        = 0x58;
    constexpr uintptr_t CHARACTER_ANIMATION  = 0x60;
    constexpr uintptr_t LOD_GROUPS           = 0x68;

    // Геттеры Transform (11910): Qgu()=head-кандидат (Slot 4), Qgn()=body-кандидат
    // (Slot 6), oBX()=rightWeaponHolder-кандидат — соответствие слотам устойчиво
    // между версиями (v53/v57).
    constexpr uintptr_t RVA_GET_HEAD         = 0x7584104;  // Qgu() — Slot 4, кандидат head
    constexpr uintptr_t RVA_GET_RIGHT_HOLDER = 0x75840b8;  // oBX() — кандидат rightWeaponHolder
    constexpr uintptr_t RVA_GET_BODY         = 0x7584090;  // Qgn() — Slot 6, кандидат body
}

namespace inventory {

    // PlayerInventory — сверно 11905, БЕЗ СДВИГОВ:
    constexpr uintptr_t INVENTORY_DATA       = 0x20;
    constexpr uintptr_t INVENTORY_CLIENT     = 0x28;
    constexpr uintptr_t INVENTORY_SERVER     = 0x30;

    // ─── v39: ItemHolder = класс Rky (11905: DlK), раскладка 11910 та же ──
    // 11910: Item @0x10, int(slot?) @0x18, Inventory @0x20, container(string) @0x28,
    // ContainerKind @0x30, строки @0x38..0x50, bool-флаги @0x58..0x5B,
    // ItemFilterConfig @0x60, Action @0x68.
    constexpr uintptr_t ITEM_HOLDER_ITEM     = 0x10;  // <ZXy> Item (11905: <QYD>)
    constexpr uintptr_t ITEM_HOLDER_SLOT     = 0x18;  // <ZXC> int (slot/amount; 11905: <QYr>)
    constexpr uintptr_t ITEM_HOLDER_INVENTORY= 0x20;  // <ZXX> Inventory (бывш. CONTAINER 0x30; 11905: <QYR>)
    constexpr uintptr_t ITEM_HOLDER_CONTAINER= 0x28;  // string container (имя контейнера)
    constexpr uintptr_t ITEM_HOLDER_KIND     = 0x30;  // ContainerKind ZXP (11905: QYS)
    constexpr uintptr_t ITEM_HOLDER_FILTER   = 0x60;  // ItemFilterConfig ZPu (11905: QYs; было 0x28)
    // Легаси-имена (оставлены для совместимости, значения пересмотрены):
    constexpr uintptr_t ITEM_HOLDER_UPDATED  = 0x10;  // легаси: поле Updated в 11905 отсутствует
    constexpr uintptr_t ITEM_HOLDER_CATEGORY = 0x38;  // string ZXO (11905: QYO)
    constexpr uintptr_t ITEM_HOLDER_REQ_ITEM = 0x40;  // string ZXh (11905: QYg)
}

namespace loot {
    // ─── v39: класс LootObject, сверно с dump.cs 1.13.11910 ──────────────
    // (в 11905 удалялось поле itemHolders @0xC0 → capacity..panelName были -8;
    //  в 11910 раскладка НЕ изменилась, сверено 1:1)
    constexpr uintptr_t INVENTORY            = 0xA0;
    constexpr uintptr_t IS_LOOTABLE          = 0xA8;
    constexpr uintptr_t DESTROY_ON_EMPTY     = 0xA9;
    constexpr uintptr_t IS_NEW               = 0xAA;
    constexpr uintptr_t DESTROY_OBJECT       = 0xB0;
    constexpr uintptr_t NET_DESTROY_OBJECT   = 0xB8;
    constexpr uintptr_t CAPACITY             = 0xC0;  // int m_Capacity (сдвиг -8 введён в 11905)
    constexpr uintptr_t COVER_TRANSFORM      = 0xC8;  // Transform m_Cover
    constexpr uintptr_t OPEN_SPEED           = 0xD0;
    constexpr uintptr_t CLOSED_ROTATION      = 0xD4;
    constexpr uintptr_t OPEN_ROTATION        = 0xD8;
    constexpr uintptr_t PANEL_NAME           = 0xE0;  // string panelName
    constexpr uintptr_t CONTAINER_SOUND_KEY  = 0xE8;  // string m_ContainerSoundKey (введён в 11905)
    constexpr uintptr_t ONLY_GIVE            = 0xF0;
    constexpr uintptr_t BUILDING_PIECE       = 0xF8;
    constexpr uintptr_t DROP_ON_DESTROY      = 0x100;
    constexpr uintptr_t LOOT_BAG             = 0x108;
    // ВНИМАНИЕ: itemHolders из LootObject УДАЛЕНЫ в 11905.
    // Список предметов теперь через Inventory (LootObject+0xA0) — требуется реверс.

    constexpr int NORMAL_CRATE               = 1001;
    constexpr int MILITARY_CRATE             = 1002;
    constexpr int ELITE_CRATE                = 1003;
    constexpr int CAR_LOOT                   = 1004;
    constexpr int TOOLBOX                    = 1005;
    constexpr int LOOT_BAG_ID                = 1006;
    constexpr int CORPSE                     = 1007;
    constexpr int STASH                      = 1008;
    constexpr int SUPPLY_DROP                = 1009;
}

namespace item_ids {

    constexpr int32_t STONE_ORE          = 2001;
    constexpr int32_t SULFUR_ORE         = 2002;
    constexpr int32_t METAL_ORE          = 2003;
    constexpr int32_t WOOD_TREE          = 2004;
    constexpr int32_t SCRAP_PILE         = 2005;
    constexpr int32_t HEMP_PLANT         = 2006;
}

} // namespace offsets